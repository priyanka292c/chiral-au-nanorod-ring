# Cover Letter for Submission to the *Journal of the Optical Society of America B* (JOSA B)
**Optica Publishing Group**

**Date:** 16 October 2026

**To:**  
Prof. Kurt Busch, Editor-in-Chief  
Editorial Board, *Journal of the Optical Society of America B* (JOSA B)  
Optica Publishing Group, 2010 Massachusetts Ave. NW, Washington, DC 20036, USA  

**Subject:** Submission of Original Research Article to JOSA B  
**Topic:** Nanophotonics, Plasmonics, Chiroptics, and Optical Forces  

**Title of Manuscript:**  
*"Helicity-Selective Multipolar Interference Governs Optical Force and Torque in Structurally Chiral Plasmonic Nanorod Rings"*

**Authors:**  
1. **Priyanka**  
   Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India  
   E-mail: `priyanka292c@gmail.com` | ORCID: 0009-0002-3982-1407  

2. **Dr. Ram Soorat** *(Corresponding Author)*  
   School of Technology, Woxsen University, Hyderabad 502345, Telangana, India  
   E-mail: `rsoorat@gmail.com` | ORCID: 0000-0002-9876-5432  

---

### Scientific Context and Motivation
Chiral plasmonic nanostructures exhibit remarkable enantiospecific near-field localization and circular dichroism. However, converting three-dimensional structural chirality into deterministic mechanical actuation—specifically, controllable optical radiation forces and mechanical torques—remains an elusive objective in nanoscale optomechanics. Conventional approaches often invoke complex wavefront shaping or paraxial approximations, leaving the electrodynamic interplay between 3D structural chirality ($D_{6h} \to C_6$ symmetry breaking), multipolar interference, and optical momentum conservation incompletely formulated.

In this work, we demonstrate that a structurally chiral plasmonic oligomer (a twisted ring of six gold nanorods, $N = 6$, $l = 100\,$nm, $d = 35\,$nm, $R_c = 120\,$nm, twist pitch $\Delta z = 12\,$nm, minimum gap $18.5\,$nm) governs both optical force and torque via helicity-selective multipolar interference. Using rigorous finite-difference time-domain (FDTD) electrodynamics, the Coupled Dipole Approximation (CDA), the Boundary Element Method (MNPBEM), and Cartesian/spherical multipolar expansions, we formulate and verify the exact causal pathway linking geometric chirality to asymmetric momentum transfer.

---

### Key Scientific Findings and Novel Contributions
1. **Multipolar Co-Resonance & Near-Kerker Scattering:**  
   Out-of-plane helical twisting activates a collective magnetic-dipole (MD) mode ($P_\mathrm{MD} / P_\mathrm{ED} \approx 0.47$) co-resonant with the electric-dipole (ED) mode at $\lambda = 800\,$nm. Under matched optical helicity (LCP illumination on the left-handed enantiomer), an ED–MD relative phase difference of $\Delta\phi \approx 14.2^\circ$ establishes a generalized Kerker-like condition with destructive backward and constructive forward interference, yielding an asymmetric forward scattering ratio of $\eta_\mathrm{fwd} \approx 0.73$ and $g_\mathrm{eff} \approx +0.46$.

2. **Helicity-Controlled Radiation-Pressure Modulation:**  
   Strong forward momentum recoil induces a 50.1% helicity-dependent force contrast, suppressing longitudinal radiation pressure under LCP illumination down to $F_z = +58.3\,$fN compared to $+116.8\,$fN under RCP (and $+48.2\,$fN for the planar achiral control). Far-field momentum balance agrees with near-field Maxwell stress tensor (MST) integration within $0.85\%$.

3. **Helicity-Controlled Optical Torque Amplification:**  
   Helical asymmetry breaks spatial parity, generating a total axial torque of $\tau_z = +36.2\,\mathrm{zN\cdot m}$ under LCP versus $-25.0\,\mathrm{zN\cdot m}$ under RCP. Spectral and multipolar decomposition confirms that this response is dominated by chiral scattering ($\tau_\mathrm{scat} \approx +33.8\,\mathrm{zN\cdot m}$), contributing $93.5\%$ of total torque and $92.3\%$ of net helicity contrast, yielding an $\approx 18.9$-fold torque amplification relative to the planar achiral geometry ($\tau_z \approx \pm 1.92\,\mathrm{zN\cdot m}$).

4. **Rigorous Cross-Validation and Structural Robustness:**  
   Results are independently verified across three distinct numerical methodologies (FDTD, CDA, and MNPBEM within $3.2\%$), supported by multi-wavelength mesh-convergence tests, and validated through a 500-sample Monte Carlo disorder study confirming robustness against realistic experimental fabrication imperfections.

---

### Suggested Expert Reviewers
1. **Prof. Alexander O. Govorov** (Ohio University, USA) — `govorov@ohio.edu`  
   *Expertise:* Chiral plasmonics, circular dichroism electrodynamic theory, and coupled-dipole models.
2. **Prof. Harald Giessen** (University of Stuttgart, Germany) — `giessen@physik.uni-stuttgart.de`  
   *Expertise:* 3D chiral plasmonic oligomers, helical metamaterials, and near-field chiral optics.
3. **Prof. Ventsislav K. Valev** (University of Bath, UK) — `v.k.valev@bath.ac.uk`  
   *Expertise:* Chiroptical phenomena, multipolar scattering, and optical torques in nanostructures.
4. **Prof. Cyriaque Genet** (University of Strasbourg & CNRS, France) — `genet@unistra.fr`  
   *Expertise:* Chiral optomechanics, optical forces on chiral dipoles, and angular momentum transfer.

---

### Formal Declarations
- **Originality:** This manuscript is an original work that has not been published previously and is not under consideration elsewhere.
- **Author Approval:** All named authors have reviewed and approved the manuscript contents.
- **Reference Integrity:** All citations correspond to peer-reviewed Versions of Record with resolving DOIs; zero unverified preprints exist in the manuscript.
- **AI Policy Compliance & Author Consent:** Both authors provide full consent and declare compliance with Optica Publishing Group's Artificial Intelligence Policy. AI-assisted technologies were utilized solely for stylistic language refinement, typography template formatting, and build-script assistance under direct author supervision. All models, derivations, calculations, simulations, interpretations, and conclusions remain the original work and intellectual responsibility of the human authors.
