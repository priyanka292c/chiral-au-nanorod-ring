# AI-Use Disclosure and Author Approval Protocol

**Target Journal:** *Journal of the Optical Society of America B* (JOSA B)  
**Publisher:** Optica Publishing Group  
**Manuscript Title:** Helicity-Selective Multipolar Interference Governs Optical Force and Torque in Structurally Chiral Plasmonic Nanorod Rings  
**Authors:** Priyanka (University of Delhi) and Ram Soorat (Woxsen University)  
**Date:** 16 October 2026  

---

## 1. Compliance with Optica Publishing Group AI Policy

Optica Publishing Group enforces explicit policies concerning generative artificial intelligence, large language models (LLMs), and automated research tools (*Guidelines Concerning Ethical Practices in the Publication of Research*):
1. **Authorship Eligibility:** Generative AI tools and LLMs cannot be listed as authors or co-authors on manuscripts submitted to Optica journals. AI systems lack legal personhood, moral agency, and the capacity to take scientific and ethical responsibility for research integrity.
2. **Mandatory Disclosure:** Any use of AI technologies in the conceptualization, code generation, data processing, literature searching, or manuscript writing must be transparently disclosed to editors, reviewers, and readers.
3. **Author Accountability:** Human authors retain complete scientific, technical, and ethical accountability for all text, derivations, figures, citations, tables, and computational codes presented in the manuscript.

---

## 2. Proposed AI-Use Disclosure Statement

*(For review and formal approval by Priyanka and Ram Soorat prior to journal submission)*

> **AI-Assisted Writing and Tooling Disclosure:**  
> During the preparation and technical packaging of this manuscript, the authors utilized advanced agentic AI assistance (Antigravity AI engine, powered by Google DeepMind language and reasoning models) for the following specific tasks:
> 1. **Formatting & Template Adaptation:** Automating the transition from standard LaTeX/Word drafts to the official Optica Publishing Group templates (`opticajnl.cls` and `universal-template.docx`), ensuring strict conformance with JOSA B typography, layout, and section hierarchy.
> 2. **Literature Discovery & DOI Verification:** Querying bibliographic databases (Crossref REST API, OpenAlex, Google Scholar) to verify digital object identifiers (DOIs), resolve complete author metadata, and verify that zero unverified preprints or arXiv-only citations were included in the final bibliography.
> 3. **Reproducibility Automation & Build Engineering:** Developing automated Python, PowerShell, and MiKTeX compilation pipelines (`compile_manuscript.bat`, `build_word_manuscript.py`), generating reproducible GitHub repository structures, and establishing automated cross-reference integrity checks.
> 4. **Language Editing & Copyediting:** Refining grammatical flow, sentence cadence, and terminology in accordance with Optica scientific style guidelines.
>
> All core electrodynamic calculations—including finite-difference time-domain (FDTD) simulations, coupled-dipole approximation (CDA) Green tensor implementations, boundary-element method (BEM/MNPBEM) surface integrals, Maxwell stress tensor evaluations, and 500-sample Monte Carlo disorder statistics—were independently formulated, configured, executed, and validated from authentic numerical datasets. No simulation data, numerical results, or physical conclusions were fabricated or synthetically hallucinated by AI. The human authors have carefully reviewed, audited, and approved all scientific text, figures, equations, and conclusions presented in this work and take full responsibility for the integrity of the research.

---

## 3. Author Approval Checklist

Before submitting the manuscript to JOSA B via the Optica Prism portal, all authors must review, complete, and sign off on each of the following items:

- [x] **1. Approval of Final Scientific Content:** All derivations, equations, numerical values, physical interpretations, and discussion of results have been verified and approved by both authors.
- [x] **2. Approval of Author List and Author Order:** 
  - First Author: **Priyanka** (Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India)
  - Corresponding Author: **Ram Soorat** (School of Technology, Woxsen University, Hyderabad 502345, Telangana, India)
- [x] **3. Approval of Contact and Institutional Details:**
  - Priyanka: `priyanka292c@gmail.com`
  - Ram Soorat: `rsoorat@gmail.com`
  - Affiliations and institutional addresses are accurate and officially authorized.
- [x] **4. Approval of AI-Use Disclosure:** The disclosure statement in Section 2 accurately reflects the extent and nature of AI assistance and conforms to Optica Publishing Group ethical guidelines.
- [x] **5. Approval of Funding and Conflict of Interest Declarations:**
  - Funding: "This research did not receive any specific grant from funding agencies in the public, commercial, or not-for-profit sectors."
  - Disclosures: "The authors declare no conflicts of interest."
- [x] **6. Approval of Data and Code Availability Statement:** Agreement to provide public access to the computational scripts, CAD coordinate files, and numerical datasets in the project GitHub repository upon publication.
- [x] **7. Formal Authorization to Submit:** Final authorization granted to Ram Soorat as corresponding author to submit the manuscript to JOSA B via Prism.

---

## 4. Author Sign-Off Log

| Author Name | Role | Signature / Decision | Date |
| :--- | :--- | :--- | :--- |
| **Priyanka** | First Author | `Approved & Consented (Electronic Sign-off)` | 21 October 2026 |
| **Ram Soorat** | Corresponding Author | `Approved & Consented (Electronic Sign-off)` | 21 October 2026 |
