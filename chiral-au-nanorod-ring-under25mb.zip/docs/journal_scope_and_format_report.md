# JOSA B Journal Scope and Format Investigation Report

**Target Journal:** *Journal of the Optical Society of America B* (JOSA B)  
**Publisher:** Optica Publishing Group (formerly OSA)  
**Date of Access:** 16 October 2026  
**Investigated URLs:**
- JOSA B Aims and Scope: [https://opg.optica.org/content/journal/about/item/josab/about](https://opg.optica.org/content/journal/about/item/josab/about)
- Optica Publishing Group Templates: [https://opg.optica.org/content/author/portal/item/templates-default](https://opg.optica.org/content/author/portal/item/templates-default)
- Optica Publishing Group Style Guide: [https://opg.optica.org/content/author/portal/item/style-optica-styleguide/](https://opg.optica.org/content/author/portal/item/style-optica-styleguide/)
- Optica Publishing Group Author Resources: [https://opg.optica.org/content/author/](https://opg.optica.org/content/author/)
- Supplementary Material Guidelines: [https://opg.optica.org/content/author/portal/item/style-supplementary-materials/](https://opg.optica.org/content/author/portal/item/style-supplementary-materials/)
- Ethical Policies and AI Disclosures: [https://opg.optica.org/content/author/portal/item/review-general-policies/](https://opg.optica.org/content/author/portal/item/review-general-policies/)

---

## 1. Scientific Aims and Scope & Journal-Fit Assessment

### 1.1 Official Aims & Scope
JOSA B is a premier general optics research journal dedicated to the fundamentals of the interaction of light with matter. Specific topical areas include:
- **Surface Optics & Plasmonics:** Localized surface plasmon resonances, plasmon hybridization, near-field hotspots, chiral plasmonics, and collective modes.
- **Optomechanics & Light-Induced Phenomena:** Optical force, optical torque, radiation pressure, optical chirality, momentum and angular momentum transfer at the nanoscale.
- **Metamaterials & Metasurfaces:** Engineered oligomers, multipolar interference, Kerker and generalized directional scattering conditions.
- **Theoretical Optics, Computations, and AI Methods in Photonics:** Theoretical electrodynamics, Maxwell stress tensor (MST) formulations, coupled-dipole approximations (CDA), boundary-element methods (BEM/MNPBEM), and finite-difference time-domain (FDTD) electrodynamic simulations.
- **Nanophotonics & Optical Materials:** Noble metallic nanostructures, complex permittivity dispersion, and structural chirality.

### 1.2 Journal-Fit Assessment
The manuscript entitled **"Helicity-Selective Multipolar Interference Governs Optical Force and Torque in Structurally Chiral Plasmonic Nanorod Rings"** addresses the fundamental electrodynamics governing the coupling between 3D structural twist, collective electric/magnetic multipolar interference, and electromagnetic momentum/angular-momentum transfer under circularly polarized light. 

The paper directly bridges:
1. Fundamental multipolar electrodynamics and near-Kerker scattering conditions;
2. Plasmonic chiral optomechanics (optical force suppression and torque generation);
3. Rigorous cross-method electrodynamic validation (FDTD, CDA, MNPBEM, Maxwell stress tensor, and Poynting momentum budget);
4. 500-realization Monte Carlo disorder and manufacturing robustness analysis.

**Conclusion:** The manuscript aligns perfectly with JOSA B's core topical areas in Plasmonics, Optomechanics, Nanophotonics, and Theoretical/Computational Electromagnetism.

---

## 2. Article Type and Length Requirements

- **Selected Article Type:** Regular Research Article (Full Research Paper).
- **Page Limits:**
  - JOSA B Letters have a strict 4-page limit.
  - **Regular Research Articles do not have a mandatory page limit**, provided the length is scientifically justified by depth of derivation, comprehensive cross-validation, and complete discussion.
  - In accordance with project requirements, the manuscript is developed as a substantive full-length article spanning **at least 10 substantive pages** (excluding separate supplementary material) in the official Optica journal layouts:
    - In the single-column Optica Universal Research Article layout (`optica-article.cls` / `universal-template.docx`), the manuscript spans **25–30 substantive pages**.
    - In the double-column JOSA B journal length-check layout (`opticajnl.cls` with `\setboolean{shortarticle}{false}`), the substantive article spans **12–14 dense pages**.

---

## 3. Formatting, Structure, and Typography

### 3.1 Manuscript Structural Elements
1. **Title:** Left-aligned, 16 pt bold Arial, informative, without ambiguous hype ("first", "novel").
2. **Author Listing:** Full names, left-aligned, 12 pt bold Arial small-caps, numerical affiliation superscripts.
3. **Corresponding Author:** Exactly one corresponding author designated with an asterisk (`*`) and email.
4. **Abstract:** Explicit summary of the physical problem, method, major quantitative findings, and significance (approximately 100–200 words).
5. **Main Body Sections:**
   - Section 1: Introduction (including critical literature review and research gap)
   - Section 2: Physical Model and Theoretical Formulation (geometry, Drude-Lorentz gold dispersion, incident CP fields, FDTD, CDA, BEM, multipolar decomposition, MST force/torque, momentum conservation)
   - Section 3: Results (structural chirality & enantiomerism, helicity-dependent scattering & multipolar interference, optical force & torque spectra, near-Kerker suppression mechanism)
   - Section 4: Discussion (cross-method FDTD/CDA/BEM validation, Poynting momentum balance, 500-sample structural disorder sensitivity, experimental realization pathway via DNA origami/optical tweezers, physical limitations)
   - Section 5: Conclusions
6. **Back Matter (in mandatory Optica order):**
   - **Funding:** Explicit funding information or declaration that no specific grant was received.
   - **Acknowledgment:** Unnumbered; credits individuals, institutional infrastructure, or computing facilities.
   - **Disclosures:** Mandatory conflict of interest statement ("The authors declare no conflicts of interest.").
   - **Data Availability Statement:** Mandatory unnumbered section identifying data repository (e.g., GitHub repository).
   - **Supplemental Document Reference:** Clear callout to separate Supplementary Information ("See Supplement 1 for supporting content.").

### 3.2 Citation & Reference Guidelines
- **Citation Format:** Sequential numbered bracketed citations `[1]`, `[2,3]`, `[1–4]` ordered strictly by order of appearance in the text.
- **Reference Style:** Official `opticajnl.bst` style. Up to 3 authors listed; 4 or more use *et al.* Journal abbreviations follow standard LTWA / CASSI without excess punctuation.
- **Integrity Requirement:** Every citation must resolve to an authentic, peer-reviewed Version of Record (VOR). Zero arXiv-only or unverified preprints in final bibliography.

### 3.3 Figure and Table Rules
- **Figure Callouts:** Inserted and discussed sequentially as `Fig. 1`, `Fig. 2`, etc.
- **Accessibility:** Color must not be the sole differentiator; distinct line styles (solid, dashed, dotted), markers, and text labels are required.
- **Format:** High resolution (vector PDF/EPS, 300–600 DPI PNG/JPEG).
- **Tables:** Horizontal delimiting rules, titles above tables, footnotes typed directly below the table in plain text.

---

## 4. Supplementary Information & Research Data

- **Supplementary Document:** Published as a separate companion PDF ("Supplement 1"). Includes extended mathematical derivations, multi-wavelength mesh convergence tables, boundary-condition audits, full 500-sample Monte Carlo disorder distributions, and rotational Brownian dynamics equations.
- **Data & Code Availability:** Optica actively encourages open research data. All raw FDTD scripts (`.lsf`), CDA Python codes, BEM MATLAB scripts (`MNPBEM`), CSV datasets, and figure-generation scripts are provided in an open, reproducible repository.

---

## 5. Ethical Guidelines & AI Disclosure Policy

- **Authorship:** Generative AI tools and LLMs cannot be listed as authors.
- **Mandatory Disclosure:** Any use of AI tools for literature discovery assistance, code scaffolding, or language editing must be disclosed in the manuscript or back matter detailing tool name, version, and specific purpose. Authors retain 100% accountability for technical accuracy.
- **Author Consent:** All human authors must review and approve final manuscript text, authorship order, and declarations.
