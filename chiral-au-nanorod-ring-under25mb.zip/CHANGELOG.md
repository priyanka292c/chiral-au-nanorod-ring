# Changelog

All notable changes and milestones for the JOSA B chiral plasmonic optomechanics manuscript project will be documented in this file.

## [v1.0.0] - 2026-10-16
### Added
- Complete JOSA B manuscript in official Optica two-column LaTeX layout (`opticajnl.cls`, 23 pages, 0 errors).
- Official Supplementary Information in LaTeX (`supplementary_information.tex`, 17 pages, 0 errors).
- Editable Microsoft Word manuscript (`main.docx`) matching Optica's `universal-template.docx` with native tables and embedded figures.
- 100% verified literature database (`references.bib`, 84 items with authentic resolving DOIs, zero arXiv preprints).
- Reference deliverables: `doi_verification_report.md`, `verified_references.csv`, `literature_candidates.csv`, `rejected_references.csv`, `citation_claim_matrix.csv`.
- Full-wave FDTD simulation scripts, CDA electrodynamics solver, and MNPBEM boundary element validation scripts.
- Multi-wavelength mesh convergence datasets (0.25 nm to 1.0 nm Yee cells) and 500-sample Monte Carlo disorder statistics.
- Continuous Integration workflow (`.github/workflows/ci.yml`).
- Complete documentation: `journal_scope_and_format_report.md`, `scientific_audit.md`, `ai_use_disclosure.md`, `cover_letter_josab.md`.
