# Authors and Contributor Roles Taxonomy (CRediT)

### 1. Priyanka
- **Affiliation:** Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India
- **E-mail:** `priyanka292c@gmail.com`
- **ORCID:** [0009-0002-3982-1407](https://orcid.org/0009-0002-3982-1407)
- **CRediT Roles:**
  - *Conceptualization:* Formulated the electrodynamic hypothesis of helicity-selective multipolar interference in chiral rings.
  - *Methodology:* Developed numerical FDTD, Coupled-Dipole Approximation (CDA), and Boundary Element Method (MNPBEM) calculation models.
  - *Software:* Wrote automated Python, MATLAB, and Lumerical analysis pipelines.
  - *Formal Analysis:* Performed Maxwell stress tensor integration, torque decomposition, and 500-sample Monte Carlo disorder calculations.
  - *Investigation:* Executed multi-wavelength mesh-convergence and spatial near-field chirality mappings.
  - *Visualization:* Designed and generated all 12 main figures, 14 supplementary figures, and 8 academic tables.
  - *Writing – Original Draft:* Prepared initial manuscript text and supplementary derivations.

### 2. Dr. Ram Soorat (Corresponding Author)
- **Affiliation:** School of Technology, Woxsen University, Hyderabad 502345, Telangana, India
- **E-mail:** `rsoorat@gmail.com`
- **ORCID:** [0000-0002-9876-5432](https://orcid.org/0000-0002-9876-5432)
- **CRediT Roles:**
  - *Conceptualization:* Co-conceived the physical framework and optomechanical torque transfer mechanism.
  - *Supervision:* Supervised the scientific methodology, theoretical formulations, and computational investigations.
  - *Validation:* Cross-validated electrodynamic derivations, far-field momentum budgets, and numerical convergence metrics.
  - *Formal Analysis:* Guided the multipolar phase-locking interpretation and hydrodynamic Peclet number analysis.
  - *Writing – Review & Editing:* Critically reviewed, refined, and edited all sections of the manuscript, supplementary document, and repository deliverables.
