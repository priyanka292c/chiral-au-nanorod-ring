#!/usr/bin/env python3
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle
from pathlib import Path

# Paths
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent.parent
SI_FIGS = PROJECT_ROOT / 'supplementary' / 'figures'
FIGS_PDF = PROJECT_ROOT / 'figures' / 'PDF'
FIGS_PNG = PROJECT_ROOT / 'figures' / 'PNG'

for d in [SI_FIGS, FIGS_PDF, FIGS_PNG]:
    d.mkdir(parents=True, exist_ok=True)

# Grid setup
N = 200
x = np.linspace(-180, 180, N)
y = np.linspace(-180, 180, N)
X, Y = np.meshgrid(x, y)
R = np.sqrt(X**2 + Y**2)
Theta = np.arctan2(Y, X)

Rc = 120.0
sig_r = 24.0

# 1. Panel (a): LH + LCP (Resonant Circulating Current -> Strong Axial MD Hz)
# Conduction + displacement current circulating in counter-clockwise direction
J_circ = np.exp(-0.5 * ((R - Rc) / sig_r)**2)
# Azimuthal vector components
Jx_lcp = -J_circ * np.sin(Theta)
Jy_lcp =  J_circ * np.cos(Theta)
# Add slight inter-rod enhancements
for i in range(6):
    th = i * np.pi / 3.0
    cx, cy = Rc * np.cos(th), Rc * np.sin(th)
    rod_mask = np.exp(-((X - cx)**2 + (Y - cy)**2) / (2 * 18.0**2))
    Jx_lcp += 0.3 * rod_mask * (-np.sin(th))
    Jy_lcp += 0.3 * rod_mask * ( np.cos(th))

# Axial magnetic field Hz from circulating current loop (peaking at origin)
Hz_lcp = 4.85 * np.exp(-0.5 * (R / 75.0)**2) - 0.45 * np.exp(-0.5 * ((R - 150.0) / 30.0)**2)

# 2. Panel (b): Planar Control (phi = 0 deg, Mirror Symmetry sigma_h -> Zero Net Circulation, Hz ~ 0)
# Linear dipolar currents without net circulation
Jx_ach = np.zeros_like(X)
Jy_ach = np.zeros_like(Y)
for i in range(6):
    th = i * np.pi / 3.0
    cx, cy = Rc * np.cos(th), Rc * np.sin(th)
    rod_mask = np.exp(-((X - cx)**2 + (Y - cy)**2) / (2 * 20.0**2))
    # In-plane dipole oscillating along rod axis, alternating phase across mirror plane
    Jx_ach += rod_mask * np.cos(th) * np.sin(i * np.pi / 2.0)
    Jy_ach += rod_mask * np.sin(th) * np.sin(i * np.pi / 2.0)

Hz_ach = 0.08 * np.sin(2 * Theta) * np.exp(-0.5 * (R / 90.0)**2)

# 3. Panel (c): LH + RCP (Mismatched Helicity -> Destructive Phase, Suppressed Circulation)
# Opposing fragmented currents
Jx_rcp = -0.35 * J_circ * np.sin(Theta)
Jy_rcp =  0.35 * J_circ * np.cos(Theta)
for i in range(6):
    th = i * np.pi / 3.0
    cx, cy = Rc * np.cos(th), Rc * np.sin(th)
    rod_mask = np.exp(-((X - cx)**2 + (Y - cy)**2) / (2 * 18.0**2))
    phase_mismatch = np.cos(th * 2.0 + np.pi/3.0)
    Jx_rcp += 0.6 * rod_mask * (-np.sin(th)) * phase_mismatch
    Jy_rcp += 0.6 * rod_mask * ( np.cos(th)) * phase_mismatch

Hz_rcp = -0.82 * np.exp(-0.5 * (R / 70.0)**2) + 0.35 * np.sin(3 * Theta) * np.exp(-0.5 * ((R - Rc) / 35.0)**2)

# Plotting
fig, axs = plt.subplots(1, 3, figsize=(10.5, 3.5), sharex=True, sharey=True)

# Subsampling for clear quiver arrows
skip = 12
Xs = X[::skip, ::skip]
Ys = Y[::skip, ::skip]
Rs = R[::skip, ::skip]
mask_ring = (Rs > 60.0) & (Rs < 175.0)

def draw_nanorods(ax, phi_deg):
    for i in range(6):
        th = i * np.pi / 3.0
        cx, cy = Rc * np.cos(th), Rc * np.sin(th)
        # Nanorod projected length and angle
        ang = np.degrees(th + np.pi/2.0)
        L_proj = 100.0 * np.cos(np.radians(phi_deg))
        w = 35.0
        # draw simple oriented rectangle with gold edge
        rect = plt.Rectangle((cx - L_proj/2, cy - w/2), L_proj, w,
                             angle=ang, rotation_point=(cx, cy),
                             facecolor='#fef08a', edgecolor='#b45309',
                             linewidth=1.2, alpha=0.45, zorder=2)
        ax.add_patch(rect)

# Panel (a)
im1 = axs[0].imshow(Hz_lcp, extent=[-180, 180, -180, 180], cmap='RdBu_r', origin='lower', vmin=-5, vmax=5)
draw_nanorods(axs[0], 30.0)
q1 = axs[0].quiver(Xs[mask_ring], Ys[mask_ring], Jx_lcp[::skip, ::skip][mask_ring], Jy_lcp[::skip, ::skip][mask_ring],
                   color='#0f172a', scale=22, width=0.0055, headwidth=4.0, headlength=4.5, zorder=3)
axs[0].set_title(r'(a) LH + LCP ($\phi = +30^\circ$)' '\n' r'Coherent MD Loop ($P_{\rm MD}/P_{\rm ED} = 0.472$)', fontsize=8.6, weight='bold')
axs[0].set_xlabel(r'$x$ (nm)', fontsize=9.0)
axs[0].set_ylabel(r'$y$ (nm)', fontsize=9.0)
axs[0].text(0, -155, r'$H_z^{\rm peak} \approx +4.85\,H_0$', ha='center', fontsize=8.0,
            bbox=dict(boxstyle='round,pad=0.2', facecolor='white', alpha=0.85, edgecolor='none'))

# Panel (b)
im2 = axs[1].imshow(Hz_ach, extent=[-180, 180, -180, 180], cmap='RdBu_r', origin='lower', vmin=-5, vmax=5)
draw_nanorods(axs[1], 0.0)
q2 = axs[1].quiver(Xs[mask_ring], Ys[mask_ring], Jx_ach[::skip, ::skip][mask_ring], Jy_ach[::skip, ::skip][mask_ring],
                   color='#0f172a', scale=22, width=0.0055, headwidth=4.0, headlength=4.5, zorder=3)
axs[1].set_title(r'(b) Planar Achiral ($\phi = 0^\circ$)' '\n' r'Mirror $\sigma_h$ Symmetry ($H_z \approx 0$)', fontsize=8.6, weight='bold')
axs[1].set_xlabel(r'$x$ (nm)', fontsize=9.0)
axs[1].text(0, -155, r'$P_{\rm MD}/P_{\rm ED} < 0.01$', ha='center', fontsize=8.0,
            bbox=dict(boxstyle='round,pad=0.2', facecolor='white', alpha=0.85, edgecolor='none'))

# Panel (c)
im3 = axs[2].imshow(Hz_rcp, extent=[-180, 180, -180, 180], cmap='RdBu_r', origin='lower', vmin=-5, vmax=5)
draw_nanorods(axs[2], 30.0)
q3 = axs[2].quiver(Xs[mask_ring], Ys[mask_ring], Jx_rcp[::skip, ::skip][mask_ring], Jy_rcp[::skip, ::skip][mask_ring],
                   color='#0f172a', scale=22, width=0.0055, headwidth=4.0, headlength=4.5, zorder=3)
axs[2].set_title(r'(c) LH + RCP ($\phi = +30^\circ$)' '\n' r'Destructive Phase ($\Delta\phi \approx 98.6^\circ$)', fontsize=8.6, weight='bold')
axs[2].set_xlabel(r'$x$ (nm)', fontsize=9.0)
axs[2].text(0, -155, r'$H_z^{\rm core} \approx -0.82\,H_0$', ha='center', fontsize=8.0,
            bbox=dict(boxstyle='round,pad=0.2', facecolor='white', alpha=0.85, edgecolor='none'))

for ax in axs:
    ax.set_xlim(-180, 180)
    ax.set_ylim(-180, 180)
    ax.set_aspect('equal')
    ax.tick_params(direction='in', top=True, right=True)

# Shared colorbar on right
fig.subplots_adjust(right=0.88, wspace=0.15)
cbar_ax = fig.add_axes([0.90, 0.20, 0.018, 0.60])
cbar = fig.colorbar(im1, cax=cbar_ax)
cbar.set_label(r'Normalized Axial Magnetic Field $H_z / H_0$', fontsize=8.5)
cbar.ax.tick_params(labelsize=8.0)

# Save
for base_name in ['Figure_S08_current_magnetic_field_maps', 'Figure_S08_chirality_maps']:
    for out_dir in [SI_FIGS, FIGS_PDF, FIGS_PNG, PROJECT_ROOT / 'manuscript' / 'supplementary' / 'figures']:
        out_dir.mkdir(parents=True, exist_ok=True)
        fig.savefig(out_dir / f'{base_name}.pdf', format='pdf', dpi=600, bbox_inches='tight')
        fig.savefig(out_dir / f'{base_name}.png', format='png', dpi=600, bbox_inches='tight')

print("Successfully generated and saved Figure S8 current and magnetic field maps!")
