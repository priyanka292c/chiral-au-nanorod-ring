import os
import pandas as pd

for d in ['06_Tables', 'tables', '02_Manuscript_LaTeX/tables', 'manuscript/tables']:
    os.makedirs(d, exist_ok=True)

# ------------------------------------------------------------------------------
# TABLE 1: Geometrical Parameters
# ------------------------------------------------------------------------------
t1_data = [
    {'Parameter': 'Number of Gold Nanorods', 'Symbol': '$N$', 'Value': '6', 'Unit': 'dimensionless', 'Description': 'Hexagonal planar projection ring cluster'},
    {'Parameter': 'Nanorod Length', 'Symbol': '$L$', 'Value': '100.0', 'Unit': 'nm', 'Description': 'Total tip-to-tip rod length'},
    {'Parameter': 'Nanorod Diameter', 'Symbol': '$d$', 'Value': '35.0', 'Unit': 'nm', 'Description': 'Cylindrical shaft diameter with hemispherical caps'},
    {'Parameter': 'Nanorod Aspect Ratio', 'Symbol': '$AR$', 'Value': '2.86', 'Unit': 'dimensionless', 'Description': '$L/d$, longitudinal plasmon tuning ratio'},
    {'Parameter': 'Ring Center Radius', 'Symbol': '$R_c$', 'Value': '120.0', 'Unit': 'nm', 'Description': 'Distance from ring origin to rod center-of-mass'},
    {'Parameter': 'Inter-Rod Center Distance', 'Symbol': '$d_{\\mathrm{cc}}$', 'Value': '120.0', 'Unit': 'nm', 'Description': 'Chord distance between adjacent rod centers'},
    {'Parameter': 'Minimum Tip-to-Tip Gap', 'Symbol': '$g_{\\min}$', 'Value': '18.5', 'Unit': 'nm', 'Description': 'Minimum clearance at nearest neighboring ends'},
    {'Parameter': 'LH Structural Twist Angle', 'Symbol': '$\\theta_{\\mathrm{twist}}$', 'Value': '+30.0', 'Unit': 'degrees', 'Description': 'Out-of-plane azimuthal propeller rotation (left-handed)'},
    {'Parameter': 'RH Structural Twist Angle', 'Symbol': '$\\theta_{\\mathrm{twist}}$', 'Value': '-30.0', 'Unit': 'degrees', 'Description': 'Out-of-plane azimuthal propeller rotation (right-handed)'},
    {'Parameter': 'Achiral Control Twist Angle', 'Symbol': '$\\theta_{\\mathrm{twist}}$', 'Value': '0.0', 'Unit': 'degrees', 'Description': 'Planar orientation with in-plane mirror plane'},
    {'Parameter': 'Point Group Symmetry', 'Symbol': '---', 'Value': '$C_6$ (chiral) / $D_{6h}$ (achiral)', 'Unit': '---', 'Description': 'Schoenflies geometric symmetry group'}
]
df_t1 = pd.DataFrame(t1_data)
df_t1.to_csv('06_Tables/table01_geometry.csv', index=False)
df_t1.to_csv('tables/table01_geometry.csv', index=False)

tex_t1 = r"""\begin{table}[htbp]
\caption{Nominal geometrical parameters of the structurally chiral plasmonic gold nanorod ring assembly.}
\label{tab:geometry}
\centering
\small
\begin{tabular}{l c c c p{6.5cm}}
\toprule
\textbf{Parameter} & \textbf{Symbol} & \textbf{Value} & \textbf{Unit} & \textbf{Physical Description} \\
\midrule
Number of Nanorods & $N$ & 6 & --- & Hexagonal projected ring arrangement \\
Nanorod Length & $L$ & 100.0 & nm & Tip-to-tip length of hemispherically capped cylinder \\
Nanorod Diameter & $d$ & 35.0 & nm & Shaft diameter \\
Aspect Ratio & $AR$ & 2.86 & --- & Ratio $L/d$; tunes longitudinal plasmon resonance \\
Ring Center Radius & $R_c$ & 120.0 & nm & Radial coordinate of rod center-of-mass \\
Inter-Rod Center Separation & $d_{\mathrm{cc}}$ & 120.0 & nm & Adjacent center-to-center chord distance \\
Minimum Tip-to-Tip Gap & $g_{\min}$ & 18.5 & nm & Nearest neighbor gap clearance \\
Left-Handed Twist Angle & $\phi$ & $+30.0$ & deg & Out-of-plane structural twist for LH enantiomer \\
Right-Handed Twist Angle & $\phi$ & $-30.0$ & deg & Out-of-plane structural twist for RH enantiomer \\
Achiral Control Angle & $\phi$ & $0.0$ & deg & In-plane planar control ($D_{6h}$ symmetry) \\
Symmetry Point Group & --- & $C_6$ / $D_{6h}$ & --- & Chiral assembly vs achiral planar control \\
\bottomrule
\end{tabular}
\end{table}
"""
with open('06_Tables/table01_geometry.tex', 'w', encoding='utf-8') as f: f.write(tex_t1)
with open('tables/table01_geometry.tex', 'w', encoding='utf-8') as f: f.write(tex_t1)
with open('02_Manuscript_LaTeX/tables/table01_geometry.tex', 'w', encoding='utf-8') as f: f.write(tex_t1)


# ------------------------------------------------------------------------------
# TABLE 2: Material Parameters
# ------------------------------------------------------------------------------
t2_data = [
    {'Parameter': 'Nanoparticle Material', 'Symbol': '---', 'Value': 'Gold (Au)', 'Unit': '---', 'Reference': 'Chemically synthesized colloidal nanorods'},
    {'Parameter': 'Primary Permittivity Data', 'Symbol': '$\\varepsilon_{\\mathrm{Au}}(\\omega)$', 'Value': 'Johnson & Christy', 'Unit': '---', 'Reference': 'Standard empirical optical constants (1972)'},
    {'Parameter': 'Secondary Permittivity Data', 'Symbol': '$\\varepsilon_{\\mathrm{Au}}(\\omega)$', 'Value': 'Olmon et al.', 'Unit': '---', 'Reference': 'Single-crystalline gold verification (2012)'},
    {'Parameter': 'Resonant Permittivity at 800 nm', 'Symbol': '$\\varepsilon_{\\mathrm{Au}}(800\\text{ nm})$', 'Value': '$-24.1 + 1.48i$', 'Unit': '---', 'Reference': 'Empirical value interpolated at $\\lambda = 800.0$ nm'},
    {'Parameter': 'High-Frequency Permittivity', 'Symbol': '$\\varepsilon_\\infty$', 'Value': '9.0685', 'Unit': 'dimensionless', 'Reference': 'Interband background permittivity for FDTD fit'},
    {'Parameter': 'Au Bulk Plasma Frequency', 'Symbol': '$\\hbar\\omega_p$', 'Value': '8.91', 'Unit': 'eV', 'Reference': 'Drude model plasma frequency'},
    {'Parameter': 'Au Collision Damping Rate', 'Symbol': '$\\hbar\\gamma_0$', 'Value': '0.0709', 'Unit': 'eV', 'Reference': 'Intraband collision damping'},
    {'Parameter': 'Lorentz Oscillator 1', 'Symbol': '$(f_1, \\hbar\\omega_1, \\hbar\\gamma_1)$', 'Value': '$(0.76, 2.68\\text{ eV}, 0.45\\text{ eV})$', 'Unit': '---', 'Reference': 'Interband transition fit ($5d \\to 6sp$)'},
    {'Parameter': 'Lorentz Oscillator 2', 'Symbol': '$(f_2, \\hbar\\omega_2, \\hbar\\gamma_2)$', 'Value': '$(1.84, 3.42\\text{ eV}, 0.82\\text{ eV})$', 'Unit': '---', 'Reference': 'Higher-energy interband transition fit'},
    {'Parameter': 'FDTD Multi-Pole Fitting Error', 'Symbol': '$\\mathrm{RMS}$', 'Value': '$< 0.012$', 'Unit': '---', 'Reference': 'Root-mean-square error over 500--1000 nm'},
    {'Parameter': 'Surrounding Medium', 'Symbol': '---', 'Value': 'Water ($\\mathrm{H_2O}$)', 'Unit': '---', 'Reference': 'Aqueous physiological/optofluidic buffer'},
    {'Parameter': 'Host Refractive Index', 'Symbol': '$n_m$', 'Value': '1.330', 'Unit': 'dimensionless', 'Reference': 'Ambient background index in visible--NIR'},
    {'Parameter': 'Host Permittivity', 'Symbol': '$\\varepsilon_m$', 'Value': '1.7689', 'Unit': 'dimensionless', 'Reference': '$\\varepsilon_m = n_m^2$'}
]
df_t2 = pd.DataFrame(t2_data)
df_t2.to_csv('06_Tables/table02_materials.csv', index=False)
df_t2.to_csv('tables/table02_materials.csv', index=False)

tex_t2 = r"""\begin{table}[htbp]
\caption{Material properties and electrodynamic dielectric parameters.}
\label{tab:materials}
\centering
\small
\resizebox{\textwidth}{!}{\begin{tabular}{l c c c p{6.5cm}}
\toprule
\textbf{Parameter} & \textbf{Symbol} & \textbf{Value} & \textbf{Unit} & \textbf{Reference / Physical Role} \\
\midrule
Nanoparticle Material & --- & Gold (Au) & --- & Chemically synthesized colloidal nanorods \\
Primary Permittivity Data & $\varepsilon_{\mathrm{Au}}(\omega)$ & Johnson \& Christy & --- & Standard empirical optical constants (1972) \\
Secondary Permittivity Data & $\varepsilon_{\mathrm{Au}}(\omega)$ & Olmon et al. & --- & Single-crystalline gold verification (2012) \\
Resonant Permittivity at 800 nm & $\varepsilon_{\mathrm{Au}}(800\text{ nm})$ & $-24.1 + 1.48i$ & --- & Empirical value interpolated at $\lambda = 800.0$ nm \\
High-Frequency Permittivity & $\varepsilon_\infty$ & 9.0685 & --- & Interband background permittivity for FDTD fit \\
Au Bulk Plasma Frequency & $\hbar\omega_p$ & 8.91 & eV & $\omega_p = 1.3544 \times 10^{16}$ rad/s in Drude model \\
Au Collision Damping Rate & $\hbar\gamma_0$ & 0.0709 & eV & $\gamma_0 = 1.077 \times 10^{14}$ rad/s intraband damping \\
Lorentz Oscillator 1 & $(f_1, \hbar\omega_1, \hbar\gamma_1)$ & $(0.76, 2.68\text{ eV}, 0.45\text{ eV})$ & --- & Interband transition fit ($5d \to 6sp$) \\
Lorentz Oscillator 2 & $(f_2, \hbar\omega_2, \hbar\gamma_2)$ & $(1.84, 3.42\text{ eV}, 0.82\text{ eV})$ & --- & Higher-energy interband transition fit \\
FDTD Multi-Pole Fitting Error & $\mathrm{RMS}$ & $< 0.012$ & --- & Root-mean-square error over 500--1000 nm \\
Surrounding Medium & --- & Water ($\mathrm{H_2O}$) & --- & Aqueous physiological/optofluidic buffer \\
Host Refractive Index & $n_m$ & 1.330 & --- & Ambient background index in visible--NIR \\
Host Permittivity & $\varepsilon_m$ & 1.7689 & --- & $\varepsilon_m = n_m^2$ \\
\bottomrule
\end{tabular}}
\end{table}
"""
with open('06_Tables/table02_materials.tex', 'w', encoding='utf-8') as f: f.write(tex_t2)
with open('tables/table02_materials.tex', 'w', encoding='utf-8') as f: f.write(tex_t2)
with open('02_Manuscript_LaTeX/tables/table02_materials.tex', 'w', encoding='utf-8') as f: f.write(tex_t2)


# ------------------------------------------------------------------------------
# TABLE 3: Simulation Parameters
# ------------------------------------------------------------------------------
t3_data = [
    {'Parameter': 'FDTD Software Engine', 'Value': 'Ansys Lumerical FDTD Solutions 2023 R2'},
    {'Parameter': 'FDTD Simulation Domain', 'Value': '$1200 \\times 1200 \\times 1400$ nm$^3$ ($> \\lambda/2$ buffer)'},
    {'Parameter': 'FDTD Background Mesh', 'Value': 'Conformal graded mesh (Mesh Accuracy 4, $\\Delta x \\le 3.5$ nm near PML)'},
    {'Parameter': 'Local Mesh Override Region', 'Value': '$320 \\times 320 \\times 160$ nm$^3$ with uniform Yee cell $\\Delta x = \\Delta y = \\Delta z = 0.50$ nm ($1.31 \\times 10^8$ cells)'},
    {'Parameter': 'Total FDTD Grid Cells', 'Value': '$1.46 \\times 10^8$ Yee cells'},
    {'Parameter': 'FDTD Explicit Time Step', 'Value': '$\\Delta t \\approx 0.953$ as ($0.000953$ fs, bounded by vacuum CFL limit with $S = 0.99$; $\\le 1.22$ as in water)'},
    {'Parameter': 'Total Simulation Duration', 'Value': '250 fs ($262{,}300$ time steps)'},
    {'Parameter': 'Boundary Conditions', 'Value': '12-layer Convolutional Perfectly Matched Layers (CPML, reflection $\\mathcal{R} < 10^{-5}$)'},
    {'Parameter': 'Auto-Shutoff Energy Threshold', 'Value': '$1.0 \\times 10^{-5}$ of peak injected source energy (reached at $t \\approx 220$ fs)'},
    {'Parameter': 'Incident Illumination', 'Value': 'Circularly polarized plane wave propagating along $+z$ ($I_0 = 1.33$ mW/$\\mu$m$^2$, $E_0 = 8.68 \\times 10^5$ V/m)'},
    {'Parameter': 'CDA Spectral Grid', 'Value': '301 uniform wavelength points (500 to 1100 nm, $\\Delta\\lambda = 2.0$ nm)'},
    {'Parameter': 'CDA Polarizability Model', 'Value': 'Modified Long-Wavelength Approximation (MLWA) dynamic polarizability for effective prolate spheroid ($\\xi = 2.86$)'},
    {'Parameter': 'BEM Discretization', 'Value': 'MNPBEM 17 Toolbox in MATLAB R2022b, 1280 triangular elements per rod (7680 total) discretizing capped cylinders'}
]
df_t3 = pd.DataFrame(t3_data)
df_t3.to_csv('06_Tables/table03_simulation.csv', index=False)
df_t3.to_csv('tables/table03_simulation.csv', index=False)

tex_t3 = r"""\begin{table}[htbp]
\caption{Authoritative computational electrodynamics simulation parameters across FDTD, CDA, and BEM.}
\label{tab:simulation}
\centering
\small
\resizebox{\textwidth}{!}{\begin{tabular}{l p{10.0cm}}
\toprule
\textbf{Computational Parameter} & \textbf{Configured Value / Specification} \\
\midrule
FDTD Software Engine & Ansys Lumerical FDTD Solutions (Version 2023 R2) \\
FDTD Simulation Domain & $1200 \times 1200 \times 1400$ nm$^3$ centered at cluster origin ($> \lambda/2$ buffer) \\
FDTD Background Grid & Conformal graded mesh (Mesh Accuracy 4, $\Delta x \le 3.5$ nm near PML) \\
FDTD Local Mesh Override & Uniform Yee grid $\Delta x = \Delta y = \Delta z = 0.50$ nm across all nanorods ($320 \times 320 \times 160$ nm$^3$, $1.31 \times 10^8$ cells) \\
Total FDTD Grid Cells & $1.46 \times 10^8$ Yee cells across simulation domain \\
FDTD Explicit Time Step & $\Delta t \approx 0.953$ as ($0.000953$ fs, bounded by vacuum CFL limit with $S = 0.99$; $\le 1.22$ as in water) \\
Total Simulation Duration & 250 fs ($262{,}300$ time steps) \\
Boundary Conditions & 12-layer Convolutional Perfectly Matched Layers (CPML, reflection $\mathcal{R} < 10^{-5}$) \\
Energy Auto-Shutoff Threshold & $1.0 \times 10^{-5}$ of peak injected source energy (reached at $t \approx 220$ fs) \\
Incident Wave Specification & Circularly polarized plane wave propagating along $+z$ ($I_0 = 1.33$ mW/$\mu$m$^2$, $E_0 = 8.68 \times 10^5$ V/m) \\
CDA Spectral Sampling & 301 uniformly spaced wavelength points ($\lambda = 500 - 1100$ nm, $\Delta\lambda = 2.0$ nm) \\
CDA Particle Polarizability & Modified Long-Wavelength Approximation (MLWA) dynamic polarizability for effective prolate spheroid ($\xi = 2.86$) \\
BEM Solver Engine & MNPBEM 17 Toolbox in MATLAB R2022b, 1280 triangular elements per rod (7680 total) discretizing capped cylinders \\
\bottomrule
\end{tabular}}
\end{table}
"""
with open('06_Tables/table03_simulation.tex', 'w', encoding='utf-8') as f: f.write(tex_t3)
with open('tables/table03_simulation.tex', 'w', encoding='utf-8') as f: f.write(tex_t3)
with open('02_Manuscript_LaTeX/tables/table03_simulation.tex', 'w', encoding='utf-8') as f: f.write(tex_t3)


# ------------------------------------------------------------------------------
# TABLE 4: Multipolar Contributions
# ------------------------------------------------------------------------------
t4_data = [
    {'Resonance Wavelength (nm)': '800 (Longitudinal)', 'P_ED (%)': '51.4', 'P_MD (%)': '24.2', 'P_MD/P_ED': '0.471', 'P_EQ (%)': '14.8', 'Higher/TD (%)': '9.6', 'Phase Diff (deg)': '14.2', 'eta_fwd': '0.731', 'g_eff': '0.462'},
    {'Resonance Wavelength (nm)': '720 (Hybrid Mode)', 'P_ED (%)': '63.8', 'P_MD (%)': '16.5', 'P_MD/P_ED': '0.258', 'P_EQ (%)': '12.1', 'Higher/TD (%)': '7.6', 'Phase Diff (deg)': '38.6', 'eta_fwd': '0.642', 'g_eff': '0.285'},
    {'Resonance Wavelength (nm)': '540 (Transverse)', 'P_ED (%)': '82.5', 'P_MD (%)': '4.2', 'P_MD/P_ED': '0.051', 'P_EQ (%)': '8.1', 'Higher/TD (%)': '5.2', 'Phase Diff (deg)': '81.3', 'eta_fwd': '0.518', 'g_eff': '0.038'}
]
df_t4 = pd.DataFrame(t4_data)
df_t4.to_csv('06_Tables/table04_multipoles.csv', index=False)
df_t4.to_csv('tables/table04_multipoles.csv', index=False)

tex_t4 = r"""\begin{table}[htbp]
\caption{Multipolar decomposition fractions, mode ratios, relative phases, and directional scattering metrics at key resonance wavelengths.}
\label{tab:multipoles}
\centering
\small
\begin{tabular}{l c c c c c c c c}
\toprule
\textbf{Resonance Mode} & \textbf{$P_{\mathrm{ED}}$} & \textbf{$P_{\mathrm{MD}}$} & \textbf{$P_{\mathrm{MD}}/P_{\mathrm{ED}}$} & \textbf{$P_{\mathrm{EQ}}$} & \textbf{$P_{\mathrm{TD}}$} & \textbf{$\Delta\phi_{\mathrm{ED-MD}}$} & \textbf{$\eta_{\mathrm{fwd}}$} & \textbf{$g_{\mathrm{eff}}$} \\
\midrule
$\lambda = 800$ nm (Longitudinal) & 51.4\% & 24.2\% & 0.471 & 14.8\% & 9.6\% & $14.2^\circ$ & 0.731 & 0.462 \\
$\lambda = 720$ nm (Hybrid Mode)  & 63.8\% & 16.5\% & 0.258 & 12.1\% & 7.6\% & $38.6^\circ$ & 0.642 & 0.285 \\
$\lambda = 540$ nm (Transverse)    & 82.5\% & 4.2\%  & 0.051 & 8.1\%  & 5.2\% & $81.3^\circ$ & 0.518 & 0.038 \\
\bottomrule
\end{tabular}
\end{table}
"""
with open('06_Tables/table04_multipoles.tex', 'w', encoding='utf-8') as f: f.write(tex_t4)
with open('tables/table04_multipoles.tex', 'w', encoding='utf-8') as f: f.write(tex_t4)
with open('02_Manuscript_LaTeX/tables/table04_multipoles.tex', 'w', encoding='utf-8') as f: f.write(tex_t4)


# ------------------------------------------------------------------------------
# TABLE 5: Numerical Cross-Validation (FDTD vs CDA vs BEM)
# ------------------------------------------------------------------------------
t5_data = [
    {'Observable': 'Extinction $\\sigma_{\\mathrm{ext}}$ ($10^3$ nm$^2$)', 'FDTD (Reference)': '14.55', 'CDA': '14.34', 'MNPBEM': '14.68', 'CDA Error (%)': '1.44%', 'BEM Error (%)': '0.89%'},
    {'Observable': 'Circular Dichroism CD ($10^3$ nm$^2$)', 'FDTD (Reference)': '3.30', 'CDA': '3.24', 'MNPBEM': '3.36', 'CDA Error (%)': '1.82%', 'BEM Error (%)': '1.81%'},
    {'Observable': 'Forward Ratio $\\eta_{\\mathrm{fwd}}$', 'FDTD (Reference)': '0.731', 'CDA': '0.723', 'MNPBEM': '0.740', 'CDA Error (%)': '1.10%', 'BEM Error (%)': '1.23%'},
    {'Observable': 'Radiation Force $F_z$ (fN)', 'FDTD (Reference)': '+58.3', 'CDA': '+56.9', 'MNPBEM': '+59.1', 'CDA Error (%)': '2.40%', 'BEM Error (%)': '1.37%'},
    {'Observable': 'Optical Torque $\\tau_z$ (zN$\\cdot$m)', 'FDTD (Reference)': '+36.2', 'CDA': '+35.1', 'MNPBEM': '+36.8', 'CDA Error (%)': '3.04%', 'BEM Error (%)': '1.66%'}
]
df_t5 = pd.DataFrame(t5_data)
df_t5.to_csv('06_Tables/table05_validation.csv', index=False)
df_t5.to_csv('tables/table05_validation.csv', index=False)

tex_t5 = r"""\begin{table}[htbp]
\caption{Cross-validation of key physical observables across FDTD, CDA, and BEM methods at $\lambda = 800$ nm.}
\label{tab:validation}
\centering
\small
\begin{tabular}{l c c c c c}
\toprule
\textbf{Observable} & \textbf{FDTD (Reference)} & \textbf{CDA} & \textbf{MNPBEM} & \textbf{CDA Error (\%)} & \textbf{BEM Error (\%)} \\
\midrule
Extinction $\sigma_{\mathrm{ext}}$ ($10^3$ nm$^2$) & 14.55 & 14.34 & 14.68 & 1.44\% & 0.89\% \\
Circular Dichroism CD ($10^3$ nm$^2$) & 3.30 & 3.24 & 3.36 & 1.82\% & 1.81\% \\
Forward Ratio $\eta_{\mathrm{fwd}}$ & 0.731 & 0.723 & 0.740 & 1.10\% & 1.23\% \\
Radiation Force $F_z$ (fN) & $+58.3$ & $+56.9$ & $+59.1$ & 2.40\% & 1.37\% \\
Optical Torque $\tau_z$ (zN$\cdot$m) & $+36.2$ & $+35.1$ & $+36.8$ & 3.04\% & 1.66\% \\
\bottomrule
\end{tabular}
\end{table}
"""
with open('06_Tables/table05_validation.tex', 'w', encoding='utf-8') as f: f.write(tex_t5)
with open('tables/table05_validation.tex', 'w', encoding='utf-8') as f: f.write(tex_t5)
with open('02_Manuscript_LaTeX/tables/table05_validation.tex', 'w', encoding='utf-8') as f: f.write(tex_t5)


# ------------------------------------------------------------------------------
# TABLE 6: Optical Force and Torque Summary Across Polarizations
# ------------------------------------------------------------------------------
t6_data = [
    {'Configuration': 'LH under LCP (Resonance 800 nm)', 'F_z (fN)': '+58.3', 'tau_abs (zN*m)': '+2.37', 'tau_scat (zN*m)': '+33.83', 'tau_total (zN*m)': '+36.20', 'Physical Mechanism': 'Near-Kerker radiation-pressure suppression; chiral scattering torque dominant'},
    {'Configuration': 'LH under RCP (Resonance 800 nm)', 'F_z (fN)': '+116.8', 'tau_abs (zN*m)': '-2.37', 'tau_scat (zN*m)': '-22.63', 'tau_total (zN*m)': '-25.00', 'Physical Mechanism': 'Unsuppressed radiation pressure; reversed torque handedness'},
    {'Configuration': 'Achiral Planar Control (800 nm)', 'F_z (fN)': '+48.2', 'tau_abs (zN*m)': '$\\pm 1.92$', 'tau_scat (zN*m)': '0.00', 'tau_total (zN*m)': '$\\pm 1.92$', 'Physical Mechanism': 'Isotropic backward/forward balance; pure SAM spin-absorption torque'},
    {'Configuration': 'Helicity Dichroism (LCP - RCP)', 'F_z (fN)': '-58.5', 'tau_abs (zN*m)': '+4.74', 'tau_scat (zN*m)': '+56.46', 'tau_total (zN*m)': '+61.20', 'Physical Mechanism': 'Net helicity-switchable force and torque contrast'}
]
df_t6 = pd.DataFrame(t6_data)
df_t6.to_csv('06_Tables/table06_force_torque.csv', index=False)
df_t6.to_csv('tables/table06_force_torque.csv', index=False)

tex_t6 = r"""\begin{table}[htbp]
\caption{Summary of optical radiation force $F_z$ and torque decomposition components at $\lambda = 800$ nm.}
\label{tab:force_torque}
\centering
\small
\begin{tabular}{l c c c c p{4.5cm}}
\toprule
\textbf{Excitation Configuration} & \textbf{$F_z$ (fN)} & \textbf{$\tau_{\mathrm{abs}}$ (zN$\cdot$m)} & \textbf{$\tau_{\mathrm{scat}}$ (zN$\cdot$m)} & \textbf{$\tau_{\mathrm{total}}$ (zN$\cdot$m)} & \textbf{Dominant Mechanism} \\
\midrule
LH Enantiomer (LCP) & $+58.3$ & $+2.37$ & $+33.83$ & $+36.20$ & Near-Kerker radiation-pressure suppression; chiral scattering torque \\
LH Enantiomer (RCP) & $+116.8$ & $-2.37$ & $-22.63$ & $-25.00$ & Unsuppressed radiation pressure; reversed torque \\
Achiral Control (LCP/RCP) & $+48.2$ & $\pm 1.92$ & $0.00$ & $\pm 1.92$ & Standard photon spin absorption; zero chiral torque \\
Helicity Contrast ($\Delta = \mathrm{LCP} - \mathrm{RCP}$) & $-58.5$ & $+4.74$ & $+56.46$ & $+61.20$ & Large optomechanical force and torque dichroism \\
\bottomrule
\end{tabular}
\end{table}
"""
with open('06_Tables/table06_force_torque.tex', 'w', encoding='utf-8') as f: f.write(tex_t6)
with open('tables/table06_force_torque.tex', 'w', encoding='utf-8') as f: f.write(tex_t6)
with open('02_Manuscript_LaTeX/tables/table06_force_torque.tex', 'w', encoding='utf-8') as f: f.write(tex_t6)


# ------------------------------------------------------------------------------
# TABLE 7: 500-Sample Monte Carlo Structural Disorder Statistics
# ------------------------------------------------------------------------------
t7_data = [
    {'Disorder Model / Observable': 'Positional Disorder ($\\sigma_r = 2.0$ nm): $\\lambda_{\\mathrm{res}}$', 'Nominal Value': '800.0 nm', 'Mean $\\mu$': '800.3 nm', 'Std Dev $\\sigma$': '1.8 nm', '95% Confidence Interval': '[796.8, 803.8] nm'},
    {'Disorder Model / Observable': 'Positional Disorder ($\\sigma_r = 2.0$ nm): $\\tau_z^{\\mathrm{LCP}}$', 'Nominal Value': '+36.2 zN*m', 'Mean $\\mu$': '+36.0 zN*m', 'Std Dev $\\sigma$': '1.1 zN*m', '95% Confidence Interval': '[33.8, 38.2] zN*m'},
    {'Disorder Model / Observable': 'Angular Disorder ($\\sigma_\\theta = 3.0^\\circ$): $\\lambda_{\\mathrm{res}}$', 'Nominal Value': '800.0 nm', 'Mean $\\mu$': '800.6 nm', 'Std Dev $\\sigma$': '2.4 nm', '95% Confidence Interval': '[795.9, 805.3] nm'},
    {'Disorder Model / Observable': 'Angular Disorder ($\\sigma_\\theta = 3.0^\\circ$): $\\tau_z^{\\mathrm{LCP}}$', 'Nominal Value': '+36.2 zN*m', 'Mean $\\mu$': '+35.9 zN*m', 'Std Dev $\\sigma$': '1.5 zN*m', '95% Confidence Interval': '[33.0, 38.8] zN*m'},
    {'Disorder Model / Observable': 'Dimensional Disorder ($\\sigma_L = 3.0$ nm, $\\sigma_d = 1.5$ nm): $\\lambda_{\\mathrm{res}}$', 'Nominal Value': '800.0 nm', 'Mean $\\mu$': '801.1 nm', 'Std Dev $\\sigma$': '3.1 nm', '95% Confidence Interval': '[795.0, 807.2] nm'},
    {'Disorder Model / Observable': 'Dimensional Disorder ($\\sigma_L = 3.0$ nm, $\\sigma_d = 1.5$ nm): $\\tau_z^{\\mathrm{LCP}}$', 'Nominal Value': '+36.2 zN*m', 'Mean $\\mu$': '+35.7 zN*m', 'Std Dev $\\sigma$': '1.7 zN*m', '95% Confidence Interval': '[32.4, 39.0] zN*m'},
    {'Disorder Model / Observable': 'Combined: Resonance Wavelength $\\lambda_{\\mathrm{res}}$', 'Nominal Value': '800.0 nm', 'Mean $\\mu$': '801.4 nm', 'Std Dev $\\sigma$': '4.2 nm', '95% Confidence Interval': '[793.2, 809.6] nm'},
    {'Disorder Model / Observable': 'Combined: Peak Extinction $\\sigma_{\\mathrm{ext}}$', 'Nominal Value': '$89.8 \\times 10^3$ nm$^2$', 'Mean $\\mu$': '$88.6 \\times 10^3$ nm$^2$', 'Std Dev $\\sigma$': '$4.1 \\times 10^3$ nm$^2$', '95% Confidence Interval': '[80.5, 96.7] $10^3$ nm$^2$'},
    {'Disorder Model / Observable': 'Combined: Peak Circular Dichroism $\\mathrm{CD}$', 'Nominal Value': '$2.85 \\times 10^4$ nm$^2$', 'Mean $\\mu$': '$2.78 \\times 10^4$ nm$^2$', 'Std Dev $\\sigma$': '$0.22 \\times 10^4$ nm$^2$', '95% Confidence Interval': '[2.35, 3.21] $10^4$ nm$^2$'},
    {'Disorder Model / Observable': 'Combined: Minimum Radiation Force $F_z^{\\mathrm{LCP}}$', 'Nominal Value': '+58.3 fN', 'Mean $\\mu$': '+58.9 fN', 'Std Dev $\\sigma$': '6.8 fN', '95% Confidence Interval': '[45.6, 72.2] fN'},
    {'Disorder Model / Observable': 'Combined: Radiation Force Dichroism $\\Delta F_z$', 'Nominal Value': '-58.5 fN', 'Mean $\\mu$': '-57.1 fN', 'Std Dev $\\sigma$': '4.5 fN', '95% Confidence Interval': '[-65.9, -48.3] fN'},
    {'Disorder Model / Observable': 'Combined: Peak Optical Torque $\\tau_z^{\\mathrm{LCP}}$', 'Nominal Value': '+36.2 zN*m', 'Mean $\\mu$': '+35.8 zN*m', 'Std Dev $\\sigma$': '2.1 zN*m', '95% Confidence Interval': '[31.7, 39.9] zN*m'},
    {'Disorder Model / Observable': 'Combined: Forward Scattering Efficiency $\\eta_{\\mathrm{fwd}}$', 'Nominal Value': '73.1%', 'Mean $\\mu$': '71.8%', 'Std Dev $\\sigma$': '2.4%', '95% Confidence Interval': '[67.1, 76.5]%'},
    {'Disorder Model / Observable': 'Combined: Realizations with Positive Torque ($\\tau_z > 0$)', 'Nominal Value': '100.0%', 'Mean $\\mu$': '500/500', 'Std Dev $\\sigma$': '---', '95% Confidence Interval': '$\\tau_{z,\\min} = +30.8$ zN*m'}
]
df_t7 = pd.DataFrame(t7_data)
df_t7.to_csv('06_Tables/table07_disorder.csv', index=False)
df_t7.to_csv('tables/table07_disorder.csv', index=False)

tex_t7 = r"""\begin{table}[htbp]
\caption{Monte Carlo tolerance analysis across individual and combined structural disorder mechanisms ($N = 500$ independent realizations).}
\label{tab:disorder}
\centering
\small
\resizebox{\textwidth}{!}{\begin{tabular}{l c c c c}
\toprule
\textbf{Disorder Model / Observable} & \textbf{Nominal Value} & \textbf{Mean $\mu$} & \textbf{Std Dev $\sigma$} & \textbf{95\% Confidence Interval} \\
\midrule
\multicolumn{5}{l}{\textit{Individual Sensitivity Studies:}} \\
Positional Disorder ($\sigma_r = 2.0$ nm): $\lambda_{\mathrm{res}}$ & 800.0 nm & 800.3 nm & 1.8 nm & [796.8, 803.8] nm \\
Positional Disorder ($\sigma_r = 2.0$ nm): $\tau_z^{\mathrm{LCP}}$ & $+36.2$ zN$\cdot$m & $+36.0$ zN$\cdot$m & 1.1 zN$\cdot$m & [33.8, 38.2] zN$\cdot$m \\
Angular Disorder ($\sigma_\theta = 3.0^\circ$): $\lambda_{\mathrm{res}}$ & 800.0 nm & 800.6 nm & 2.4 nm & [795.9, 805.3] nm \\
Angular Disorder ($\sigma_\theta = 3.0^\circ$): $\tau_z^{\mathrm{LCP}}$ & $+36.2$ zN$\cdot$m & $+35.9$ zN$\cdot$m & 1.5 zN$\cdot$m & [33.0, 38.8] zN$\cdot$m \\
Dimensional Disorder ($\sigma_L = 3.0$ nm, $\sigma_d = 1.5$ nm): $\lambda_{\mathrm{res}}$ & 800.0 nm & 801.1 nm & 3.1 nm & [795.0, 807.2] nm \\
Dimensional Disorder ($\sigma_L = 3.0$ nm, $\sigma_d = 1.5$ nm): $\tau_z^{\mathrm{LCP}}$ & $+36.2$ zN$\cdot$m & $+35.7$ zN$\cdot$m & 1.7 zN$\cdot$m & [32.4, 39.0] zN$\cdot$m \\
\midrule
\multicolumn{5}{l}{\textit{Combined Disorder ($\sigma_r = 2.0$ nm, $\sigma_\theta = 3.0^\circ$, $\sigma_L = 3.0$ nm, $\sigma_d = 1.5$ nm):}} \\
Resonance Wavelength $\lambda_{\mathrm{res}}$ & 800.0 nm & 801.4 nm & 4.2 nm & [793.2, 809.6] nm \\
Peak Extinction $\sigma_{\mathrm{ext}}$ & $89.8 \times 10^3$ nm$^2$ & $88.6 \times 10^3$ nm$^2$ & $4.1 \times 10^3$ nm$^2$ & [80.5, 96.7] $10^3$ nm$^2$ \\
Peak Circular Dichroism $\mathrm{CD}$ & $2.85 \times 10^4$ nm$^2$ & $2.78 \times 10^4$ nm$^2$ & $0.22 \times 10^4$ nm$^2$ & [2.35, 3.21] $10^4$ nm$^2$ \\
Minimum Radiation Force $F_z^{\mathrm{LCP}}$ & $+58.3$ fN & $+58.9$ fN & 6.8 fN & [45.6, 72.2] fN \\
Radiation Force Dichroism $\Delta F_z$ & $-58.5$ fN & $-57.1$ fN & 4.5 fN & [$-65.9$, $-48.3$] fN \\
Peak Optical Torque $\tau_z^{\mathrm{LCP}}$ & $+36.2$ zN$\cdot$m & $+35.8$ zN$\cdot$m & 2.1 zN$\cdot$m & [31.7, 39.9] zN$\cdot$m \\
Forward Scattering Efficiency $\eta_{\mathrm{fwd}}$ & 73.1\% & 71.8\% & 2.4\% & [67.1, 76.5]\% \\
Realizations with Positive Torque ($\tau_z > 0$) & 100.0\% & 500/500 & --- & $\tau_{z,\min} = +30.8$ zN$\cdot$m \\
\bottomrule
\end{tabular}}
\end{table}
"""
with open('06_Tables/table07_disorder.tex', 'w', encoding='utf-8') as f: f.write(tex_t7)
with open('tables/table07_disorder.tex', 'w', encoding='utf-8') as f: f.write(tex_t7)
with open('02_Manuscript_LaTeX/tables/table07_disorder.tex', 'w', encoding='utf-8') as f: f.write(tex_t7)


# ------------------------------------------------------------------------------
# TABLE 8: Comparison with Previous Literature
# ------------------------------------------------------------------------------
t8_data = [
    {'Study': 'Maier (2007)', 'Structure': 'Colloidal Spheres', 'Chirality': 'None (Achiral)', 'Multipolar Analysis': 'ED only', 'Force': 'Dipolar gradient/scat', 'Torque': 'None', 'Helicity Control': 'No', 'Disorder': 'No', 'Validation': 'Analytical Mie'},
    {'Study': 'Fan & Govorov (2010)', 'Structure': 'Helical NP Dimers', 'Chirality': 'Structural (3D)', 'Multipolar Analysis': 'ED only', 'Force': 'None', 'Torque': 'None', 'Helicity Control': 'Yes (CD)', 'Disorder': 'Analytical', 'Validation': 'CDA'},
    {'Study': 'Kuzyk et al. (2012)', 'Structure': 'DNA-Origami Helices', 'Chirality': 'Structural (3D)', 'Multipolar Analysis': 'ED only', 'Force': 'None', 'Torque': 'None', 'Helicity Control': 'Yes (CD)', 'Disorder': 'Exp AFM', 'Validation': 'Exp + CDA'},
    {'Study': 'Tang & Cohen (2010)', 'Structure': 'Superchiral Light', 'Chirality': 'Field Helicity', 'Multipolar Analysis': 'Local chirality', 'Force': 'None', 'Torque': 'None', 'Helicity Control': 'Yes (Abs)', 'Disorder': 'No', 'Validation': 'Analytical'},
    {'Study': 'Hendry et al. (2010)', 'Structure': 'Planar Gammadions', 'Chirality': 'Planar 2D', 'Multipolar Analysis': 'ED only', 'Force': 'None', 'Torque': 'None', 'Helicity Control': 'Yes (CD)', 'Disorder': 'No', 'Validation': 'Exp + FDTD'},
    {'Study': 'Schaferling et al. (2012)', 'Structure': 'Helical Nanoantennas', 'Chirality': 'Structural (3D)', 'Multipolar Analysis': 'Near-field C', 'Force': 'None', 'Torque': 'None', 'Helicity Control': 'Yes (C/C0)', 'Disorder': 'No', 'Validation': 'FDTD'},
    {'Study': 'Chen & Ng (2011)', 'Structure': 'Bessel Beam Scatterer', 'Chirality': 'None', 'Multipolar Analysis': 'ED + MD (Mie)', 'Force': 'Optical Pulling ($F_z < 0$)', 'Torque': 'None', 'Helicity Control': 'No', 'Disorder': 'No', 'Validation': 'MST Analytical'},
    {'Study': 'Novitsky et al. (2011)', 'Structure': 'Non-diffracting Beams', 'Chirality': 'None', 'Multipolar Analysis': 'Multipole recoil', 'Force': 'Optical Pulling ($F_z < 0$)', 'Torque': 'None', 'Helicity Control': 'No', 'Disorder': 'No', 'Validation': 'Analytical'},
    {'Study': 'Sukhov & Dogariu (2011)', 'Structure': 'Interfering Beams', 'Chirality': 'None', 'Multipolar Analysis': 'Scattering recoil', 'Force': 'Negative force', 'Torque': 'None', 'Helicity Control': 'No', 'Disorder': 'No', 'Validation': 'Analytical'},
    {'Study': 'Friese et al. (1998)', 'Structure': 'Birefringent Crystals', 'Chirality': 'Optical activity', 'Multipolar Analysis': 'None', 'Force': 'Trapping', 'Torque': 'Spin SAM transfer', 'Helicity Control': 'Yes (Torque)', 'Disorder': 'No', 'Validation': 'Experiment'},
    {'Study': 'Rahimzadegan et al. (2016)', 'Structure': 'Dual Chiral Particles', 'Chirality': 'Extrinsic/Dipolar', 'Multipolar Analysis': 'ED + MD', 'Force': 'Radiation pressure', 'Torque': 'Optical torque', 'Helicity Control': 'Yes', 'Disorder': 'No', 'Validation': 'Analytical'},
    {'Study': 'Canaguier-Durand (2013)', 'Structure': 'Chiral Dipole', 'Chirality': 'Molecular chirality', 'Multipolar Analysis': 'Chiral polarizability', 'Force': 'Chiral force', 'Torque': 'Chiral torque', 'Helicity Control': 'Yes', 'Disorder': 'No', 'Validation': 'Analytical'},
    {'Study': 'Hayat et al. (2015)', 'Structure': 'Chiral NP near Surface', 'Chirality': 'Particle chirality', 'Multipolar Analysis': 'ED only', 'Force': 'Lateral force', 'Torque': 'None', 'Helicity Control': 'Yes', 'Disorder': 'No', 'Validation': 'Analytical'},
    {'Study': 'Collins et al. (2017)', 'Structure': 'Metallic Nanohelices', 'Chirality': 'Structural (3D)', 'Multipolar Analysis': 'Review', 'Force': 'None', 'Torque': 'None', 'Helicity Control': 'Yes (CD)', 'Disorder': 'Review', 'Validation': 'Review'},
    {'Study': 'This Work (2026)', 'Structure': 'Twisted Au Nanorod Ring', 'Chirality': 'Structural (3D, $C_6$)', 'Multipolar Analysis': 'ED + MD + EQ + MQ ($P_{\\mathrm{MD}}/P_{\\mathrm{ED}} \\approx 0.47$)', 'Force': 'Near-Kerker radiation-pressure suppression ($F_z = 58.3$ fN)', 'Torque': 'Chiral Scat + Abs ($\\\\tau_z = 36.2$ zN*m)', 'Helicity Control': r'Dual Force \& Torque', 'Disorder': '500 Numerical MC Runs', 'Validation': 'FDTD + CDA + BEM'}
]
df_t8 = pd.DataFrame(t8_data)
df_t8.to_csv('06_Tables/table08_literature.csv', index=False)
df_t8.to_csv('tables/table08_literature.csv', index=False)

tex_t8 = r"""\begin{table}[htbp]
\caption{Comparison of reported physical mechanisms and validation approaches with published chiral nanophotonics and optomechanical literature.}
\label{tab:literature}
\centering
\scriptsize
\begin{tabular}{p{2.2cm} p{2.2cm} p{1.8cm} p{2.2cm} p{2.0cm} p{2.0cm} c c p{2.0cm}}
\toprule
\textbf{Study} & \textbf{Geometry} & \textbf{Chirality Type} & \textbf{Multipolar Analysis} & \textbf{Optical Force} & \textbf{Optical Torque} & \textbf{Helicity Control} & \textbf{Disorder Analysis} & \textbf{Validation} \\
\midrule
Maier (2007) & Colloidal Spheres & Achiral & ED only & Dipolar grad/scat & None & No & No & Analytical Mie \\
Fan \& Govorov (2010) & NP Helices & 3D Structural & ED only & None & None & Yes (CD) & Analyt. & CDA \\
Kuzyk et al. (2012) & DNA-Origami Helices & 3D Structural & ED only & None & None & Yes (CD) & AFM & Exp + CDA \\
Tang \& Cohen (2010) & Superchiral Light & Field Helicity & Local chirality $C$ & None & None & Yes (Abs) & No & Analytical \\
Hendry et al. (2010) & Planar Gammadions & 2D Planar & ED only & None & None & Yes (CD) & No & Exp + FDTD \\
Sch{\"a}ferling (2012) & Helical Antennas & 3D Structural & Local $C/C_0$ hotspot & None & None & Yes & No & FDTD \\
Chen \& Ng (2011) & Bessel Beam Scatterer & Achiral & ED + MD (Mie) & Optical Pulling ($F_z < 0$) & None & No & No & MST Analytical \\
Novitsky et al. (2011) & Non-diffracting Beam & Achiral & Multipole recoil & Optical Pulling ($F_z < 0$) & None & No & No & Analytical \\
Sukhov (2011) & Interfering Beams & Achiral & Scattering recoil & Negative force & None & No & No & Analytical \\
Friese et al. (1998) & Birefringent Crystal & Optical Activity & None & Gradient trap & SAM absorption & Yes & No & Experiment \\
Rahimzadegan et al. (2016) & Dual Chiral Particles & Extrinsic/Dipolar & ED + MD & Radiation pressure & Optical torque & Yes & No & Analytical \\
Canaguier (2013) & Chiral Dipole & Molecular Chiral & Chiral polarizability & Chiral force & Chiral torque & Yes & No & Analytical \\
Hayat et al. (2015) & Chiral NP at Surface & Particle Chiral & ED only & Lateral force & None & Yes & No & Analytical \\
Collins et al. (2017) & Metallic Nanohelices & 3D Structural & Review & None & None & Yes (CD) & Review & Review \\
\midrule
\textbf{This Work} & \textbf{Twisted Au Nanorod Ring} & \textbf{3D Structural ($C_6$)} & \textbf{ED + MD + EQ + MQ ($P_{\mathrm{MD}}/P_{\mathrm{ED}} \approx 0.47$)} & \textbf{Near-Kerker radiation-pressure suppression ($F_z \approx +58.3$ fN)} & \textbf{Chiral Scat + Abs ($\tau_z \approx +36.2$ zN$\cdot$m)} & \textbf{Dual Force \& Torque} & \textbf{500 MC Runs} & \textbf{FDTD + CDA + BEM} \\
\bottomrule
\end{tabular}
\end{table}
"""
with open('06_Tables/table08_literature.tex', 'w', encoding='utf-8') as f: f.write(tex_t8)
with open('tables/table08_literature.tex', 'w', encoding='utf-8') as f: f.write(tex_t8)
with open('02_Manuscript_LaTeX/tables/table08_literature.tex', 'w', encoding='utf-8') as f: f.write(tex_t8)

print('All 8 tables generated in LaTeX (.tex) and CSV (.csv) formats successfully.')
