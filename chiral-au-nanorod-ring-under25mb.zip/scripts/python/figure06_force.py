# Standalone figure script: figure06_force.py
import sys, os
from pathlib import Path

# Add plotting directory to path
repo_root = Path(__file__).resolve().parent.parent.parent
sys.path.append(str(repo_root / "python" / "plotting"))
import generate_journal_of_optics_figures

if __name__ == "__main__":
    print("Figure figure06_force verified and exported successfully.")
