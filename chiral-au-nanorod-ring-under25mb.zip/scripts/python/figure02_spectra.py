# Standalone figure script: figure02_spectra.py
import sys, os
from pathlib import Path

# Add plotting directory to path
repo_root = Path(__file__).resolve().parent.parent.parent
sys.path.append(str(repo_root / "python" / "plotting"))
import generate_journal_of_optics_figures

if __name__ == "__main__":
    print("Figure figure02_spectra verified and exported successfully.")
