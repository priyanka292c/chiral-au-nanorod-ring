"""
Assemble the official JOSA B submission package (ZIP) and full repository archive.
Computes SHA256 checksums and validates all files before and after packaging.
"""

import os
import zipfile
import hashlib
import glob

def get_sha256(filepath):
    h = hashlib.sha256()
    with open(filepath, 'rb') as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

def make_submission_zip(repo_root, zip_path):
    print(f"Creating JOSA B submission package: {zip_path}")
    
    # Files to include in the submission package
    include_files = [
        # Manuscript
        ('manuscript/manuscript.pdf', 'manuscript.pdf'),
        ('manuscript/main.docx', 'main.docx'),
        ('manuscript/manuscript.docx', 'manuscript.docx'),
        ('manuscript/manuscript.tex', 'manuscript.tex'),
        ('manuscript/references.bib', 'references.bib'),
        ('manuscript/opticajnl.cls', 'opticajnl.cls'),
        ('manuscript/opticajnl.bst', 'opticajnl.bst'),
        ('manuscript/jabbrv.sty', 'jabbrv.sty'),
        ('manuscript/jabbrv-ltwa-all.ldf', 'jabbrv-ltwa-all.ldf'),
        ('manuscript/jabbrv-ltwa-en.ldf', 'jabbrv-ltwa-en.ldf'),
        ('manuscript/silence.sty', 'silence.sty'),
        ('manuscript/compile_manuscript.bat', 'compile_manuscript.bat'),
        ('manuscript/compile_manuscript.ps1', 'compile_manuscript.ps1'),
        
        # Supplementary
        ('supplementary/supplementary_information.pdf', 'supplementary/supplementary_information.pdf'),
        ('supplementary/supplementary_information.tex', 'supplementary/supplementary_information.tex'),
        ('supplementary/compile_supplementary.bat', 'supplementary/compile_supplementary.bat'),
        
        # Documentation & Governance
        ('docs/cover_letter_josab.txt', 'Cover_Letter_JOSA_B.txt'),
        ('docs/cover_letter_josab.md', 'Cover_Letter_JOSA_B.md'),
        ('docs/journal_scope_and_format_report.md', 'journal_scope_and_format_report.md'),
        ('docs/scientific_audit.md', 'scientific_audit.md'),
        ('docs/solver_logs_and_provenance.md', 'solver_logs_and_provenance.md'),
        ('docs/ai_use_disclosure.md', 'ai_use_disclosure.md'),
        ('AI_CONSENT_DECLARATION.md', 'AI_CONSENT_DECLARATION.md'),
        ('docs/texmaker_configuration_guide.md', 'texmaker_configuration_guide.md'),
        
        # Datasets & Provenance
        ('data/processed/enantiomeric_symmetry_matrix_301pts.csv', 'data/enantiomeric_symmetry_matrix_301pts.csv'),
        ('data/processed/force_momentum_highres.csv', 'data/force_momentum_highres.csv'),
        ('data/processed/disorder_configurations_500_runs.csv', 'data/disorder_configurations_500_runs.csv'),
        ('data/processed/fdtd_mesh_convergence.csv', 'data/fdtd_mesh_convergence.csv'),
        ('data/processed/bem_cda_crossvalidation_301pts.csv', 'data/bem_cda_crossvalidation_301pts.csv'),
        ('data/processed/chiroptical_spectra_highres.csv', 'data/chiroptical_spectra_highres.csv'),
        ('data/processed/torque_decomposition_highres.csv', 'data/torque_decomposition_highres.csv'),
        ('data/processed/multipolar_highres.csv', 'data/multipolar_highres.csv'),
        
        # References
        ('references/doi_verification_report.md', 'references/doi_verification_report.md'),
        ('references/verified_references.csv', 'references/verified_references.csv'),
        ('references/literature_candidates.csv', 'references/literature_candidates.csv'),
        ('references/rejected_references.csv', 'references/rejected_references.csv'),
        ('references/citation_claim_matrix.csv', 'references/citation_claim_matrix.csv'),
        ('references/references.bib', 'references/references.bib'),
        
        # Metadata
        ('README.md', 'README.md'),
        ('LICENSE', 'LICENSE'),
        ('CITATION.cff', 'CITATION.cff'),
        ('AUTHORS.md', 'AUTHORS.md'),
        ('authors.yaml', 'authors.yaml'),
        ('CHANGELOG.md', 'CHANGELOG.md'),
        ('RESPONSE_TO_REVIEWERS.md', 'RESPONSE_TO_REVIEWERS.md'),
        ('FINAL_QA_REPORT.md', 'FINAL_QA_REPORT.md'),
    ]
    
    # Collect all figures
    for f in glob.glob(os.path.join(repo_root, 'figures', '**', '*.*'), recursive=True):
        if not os.path.isdir(f):
            rel = os.path.relpath(f, repo_root)
            include_files.append((rel, rel))
            
    # Collect all supplementary figures
    for f in glob.glob(os.path.join(repo_root, 'supplementary', 'figures', '*.*')):
        if not os.path.isdir(f):
            rel = os.path.relpath(f, repo_root)
            include_files.append((rel, rel))
            
    # Collect all tables
    for f in glob.glob(os.path.join(repo_root, 'tables', '**', '*.*'), recursive=True):
        if not os.path.isdir(f):
            rel = os.path.relpath(f, repo_root)
            include_files.append((rel, rel))
            
    # Collect CAD models
    for f in glob.glob(os.path.join(repo_root, 'CAD', '*.*')):
        if not os.path.isdir(f):
            rel = os.path.relpath(f, repo_root)
            include_files.append((rel, rel))

    # Collect computational scripts (Section S23 compliance)
    for f in glob.glob(os.path.join(repo_root, 'scripts', '**', '*.*'), recursive=True):
        if not os.path.isdir(f):
            rel = os.path.relpath(f, repo_root)
            include_files.append((rel, rel))

    # Collect all processed data files
    for f in glob.glob(os.path.join(repo_root, 'data', '**', '*.*'), recursive=True):
        if not os.path.isdir(f):
            rel = os.path.relpath(f, repo_root)
            include_files.append((rel, rel))

    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
        for src_rel, arcname in include_files:
            abs_src = os.path.join(repo_root, src_rel)
            if os.path.exists(abs_src):
                z.write(abs_src, arcname)
            else:
                print(f"Warning: file not found: {abs_src}")
                
    print(f"Package created successfully! Size: {os.path.getsize(zip_path):,} bytes")
    print(f"SHA256: {get_sha256(zip_path)}")

def make_full_repo_zip(repo_root, zip_path):
    print(f"\nCreating full repository backup archive: {zip_path}")
    exclude_dirs = {'.git', '__pycache__', '.venv', 'venv'}
    exclude_exts = {'.aux', '.log', '.out', '.toc', '.synctex.gz', '.bbl', '.blg', '.zip'}
    
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(repo_root):
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                if ext in exclude_exts and not file.endswith('manuscript.pdf') and not file.endswith('supplementary_information.pdf'):
                    continue
                # Skip target zip itself
                abs_f = os.path.join(root, file)
                if abs_f == zip_path:
                    continue
                rel_f = os.path.relpath(abs_f, repo_root)
                z.write(abs_f, rel_f)
                
    print(f"Repository archive created! Size: {os.path.getsize(zip_path):,} bytes")
    print(f"SHA256: {get_sha256(zip_path)}")

if __name__ == '__main__':
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
    
    pkg_zip = os.path.join(root, 'JOSA_B_Manuscript_Package.zip')
    repo_zip = os.path.join(root, 'josab-chiral-plasmonic-optomechanics.zip')
    
    make_submission_zip(root, pkg_zip)
    make_full_repo_zip(root, repo_zip)
