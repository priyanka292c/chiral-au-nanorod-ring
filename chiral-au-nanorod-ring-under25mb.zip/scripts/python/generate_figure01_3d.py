"""
generate_figure01_3d.py
=======================
Generates a publication-quality 3D rendering of the chiral plasmonic nanorod
ring assembly with realistic, shiny metallic gold appearance on a clean white
background suitable for journal publication.

Each capsule (cylinder + two hemispheres) is rendered as a smooth surface mesh
with Blinn-Phong specular + diffuse lighting implemented via face normals and
facecolors built with numpy. The result is exported to all target figure directories.

Usage:
    python python/plotting/generate_figure01_3d.py

Physics constants (preserved):
    Rc = 120 nm, L = 100 nm, d = 35 nm, N = 6 rods
    theta_twist(LH) = +30°, theta_twist(RH) = -30°, theta_twist(Ach) = 0°
"""

import os
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from mpl_toolkits.mplot3d import Axes3D                         # noqa: F401
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import matplotlib.gridspec as gridspec

# ---------------------------------------------------------------------------
# Export directories (same as main figure generator)
# ---------------------------------------------------------------------------
DIRS = [
    '05_Figures/png', '05_Figures/jpeg', '05_Figures/pdf', '05_Figures/eps',
    'figures/png', 'figures/jpeg', 'figures/pdf', 'figures/eps',
    'manuscript/figures', '02_Manuscript_LaTeX/figures'
]
for d in DIRS:
    os.makedirs(d, exist_ok=True)

def export_figure(fig, base_name):
    """Exports figure across all figure directories in PNG, JPEG, and PDF."""
    for prefix in ['05_Figures', 'figures']:
        fig.savefig(f'{prefix}/png/{base_name}.png',  format='png',  dpi=300, facecolor='white', bbox_inches='tight')
        fig.savefig(f'{prefix}/jpeg/{base_name}.jpg', format='jpeg', dpi=300, facecolor='white', bbox_inches='tight')
        fig.savefig(f'{prefix}/pdf/{base_name}.pdf',  format='pdf',  facecolor='white', bbox_inches='tight')

    for dest in ['manuscript/figures', '02_Manuscript_LaTeX/figures']:
        fig.savefig(f'{dest}/{base_name}.png', format='png', dpi=300, facecolor='white', bbox_inches='tight')
        fig.savefig(f'{dest}/{base_name}.pdf', format='pdf', facecolor='white', bbox_inches='tight')

    print(f'  [SUCCESS] Exported {base_name} (PNG, JPEG, PDF) to all directories.')


# ---------------------------------------------------------------------------
# Phong shading helper
# ---------------------------------------------------------------------------

def phong_colors(verts, face_normals, light_dir, base_rgb, ambient=0.28,
                 diffuse=0.60, specular=0.72, shininess=75):
    """Return RGBA array (N_faces, 4) with Blinn-Phong shading per face."""
    L = light_dir / np.linalg.norm(light_dir)           # unit light vector
    n = face_normals / (np.linalg.norm(face_normals, axis=1, keepdims=True) + 1e-12)

    diff = np.clip(np.dot(n, L), 0, 1)                  # diffuse term

    # Blinn–Phong half-vector specular
    view_dir = np.array([0.5, -0.8, 1.3])
    view_dir = view_dir / np.linalg.norm(view_dir)
    H = (L + view_dir)
    H = H / np.linalg.norm(H)
    spec = np.power(np.clip(np.dot(n, H), 0, 1), shininess)

    intensity = ambient + diffuse * diff + specular * spec   # scalar per face
    intensity = np.clip(intensity, 0, 1)[:, None]           # (N, 1)

    r, g, b = base_rgb
    # Metallic gold has warm golden-white specular highlights
    highlight = np.array([1.0, 0.98, 0.88])
    base = np.array([r, g, b])
    rgb = base * intensity + highlight * (intensity ** 2) * specular * 0.40
    rgb = np.clip(rgb, 0, 1)

    alpha = np.ones((rgb.shape[0], 1))
    return np.hstack([rgb, alpha])


# ---------------------------------------------------------------------------
# Geometry builders
# ---------------------------------------------------------------------------

def make_capsule(cx, cy, cz, half_len, radius, axis_dir, n_lat=32, n_cap=18):
    """
    Build faces of a smooth capsule (cylinder + 2 hemispheres) centred at
    (cx, cy, cz), with long axis along axis_dir.
    Returns (verts_list, face_normals) where verts_list is a list of
    (4,3) face vertex arrays suitable for Poly3DCollection.
    """
    u = np.array(axis_dir, dtype=float)
    u /= np.linalg.norm(u)
    tmp = np.array([1, 0, 0]) if abs(u[0]) < 0.9 else np.array([0, 1, 0])
    v = np.cross(u, tmp); v /= np.linalg.norm(v)
    w = np.cross(u, v);   w /= np.linalg.norm(w)

    theta = np.linspace(0, 2 * np.pi, n_lat + 1)
    phi   = np.linspace(0, np.pi / 2, n_cap + 1)

    verts_list   = []
    face_normals = []
    centre = np.array([cx, cy, cz])

    # Cylinder body
    cos_t, sin_t = np.cos(theta), np.sin(theta)
    R_vec = radius * (cos_t[:, None] * v[None, :] + sin_t[:, None] * w[None, :])

    top_pts = centre + half_len * u + R_vec[:-1]
    bot_pts = centre - half_len * u + R_vec[:-1]

    for i in range(n_lat):
        quad = np.array([top_pts[i], top_pts[(i+1) % n_lat],
                         bot_pts[(i+1) % n_lat], bot_pts[i]])
        normal = cos_t[i] * v + sin_t[i] * w
        verts_list.append(quad)
        face_normals.append(normal)

    # Hemisphere caps
    for sign, cap_centre in [(+1, centre + half_len * u), (-1, centre - half_len * u)]:
        for j in range(n_cap):
            phi0, phi1 = phi[j], phi[j + 1]
            for i in range(n_lat):
                t0, t1 = theta[i], theta[i + 1]
                def cap_pt(ph, th):
                    normal_dir = (np.sin(ph) * (np.cos(th) * v + np.sin(th) * w)
                                  + np.cos(ph) * sign * u)
                    return cap_centre + radius * normal_dir, normal_dir

                p0, n0 = cap_pt(phi0, t0)
                p1, n1 = cap_pt(phi0, t1)
                p2, n2 = cap_pt(phi1, t1)
                p3, n3 = cap_pt(phi1, t0)
                quad = np.array([p0, p1, p2, p3])
                avg_n = (n0 + n1 + n2 + n3) / 4.0
                verts_list.append(quad)
                face_normals.append(avg_n)

    return verts_list, np.array(face_normals)


# ---------------------------------------------------------------------------
# Draw a full 3-D nanorod ring onto a 3-D axis
# ---------------------------------------------------------------------------

def draw_ring_3d(ax, phi_deg, mode='lh', elev=32, azim=-52):
    """
    Draw 6 shiny 3-D gold capsules arranged on a circle (Rc=1.05 unit = 120 nm).
    phi_deg is the azimuthal propeller twist in degrees.
    mode: 'lh' | 'rh' | 'ach'
    """
    ax.set_facecolor('#ffffff')

    # Directional lighting
    light = np.array([0.65, -0.75, 1.45])

    # All rods across LH, RH, and planar control are identical gold (Au)
    base_rgb = (0.88, 0.72, 0.18)

    Rc   = 1.05
    half = 0.44
    rad  = 0.125

    # Center axis marker
    ax.scatter([0], [0], [0], color='#475569', s=30, zorder=12)

    all_verts  = []
    all_colors = []

    for i in range(6):
        th = i * np.pi / 3.0
        cx = Rc * np.cos(th)
        cy = Rc * np.sin(th)
        cz = 0.0

        tangent = np.array([-np.sin(th), np.cos(th), 0.0])
        radial  = np.array([ np.cos(th), np.sin(th), 0.0])
        zhat    = np.array([0, 0, 1.0])

        phi_rad = np.deg2rad(phi_deg)
        axis_dir = (np.cos(phi_rad) * tangent + np.sin(phi_rad) * zhat)
        axis_dir /= np.linalg.norm(axis_dir)

        v_list, f_normals = make_capsule(cx, cy, cz, half, rad, axis_dir,
                                         n_lat=24, n_cap=12)
        colors = phong_colors(v_list, f_normals, light, base_rgb,
                              ambient=0.28, diffuse=0.58, specular=0.72, shininess=80)

        all_verts.extend(v_list)
        all_colors.extend(list(colors))

    coll = Poly3DCollection(all_verts, zsort='average', shade=False)
    coll.set_facecolor(all_colors)
    coll.set_edgecolor('none')
    coll.set_alpha(1.0)
    ax.add_collection3d(coll)

    # ---- Guide circle on xy-plane ----
    ring_th = np.linspace(0, 2 * np.pi, 300)
    if mode == 'lh':
        guide_col = '#0284c7'
    elif mode == 'rh':
        guide_col = '#e11d48'
    else:
        guide_col = '#94a3b8'
    ax.plot(Rc * np.cos(ring_th), Rc * np.sin(ring_th), np.zeros(300),
            color=guide_col, lw=1.6, ls='--', alpha=0.50, zorder=2)

    # ---- Propagation beam arrow (+z) ----
    if mode == 'lh':
        ax.quiver(0, 0, 0.60, 0, 0, 0.50, color='#0284c7', lw=2.4,
                  arrow_length_ratio=0.30, linewidth=2.8, alpha=0.95)
        ax.text(0.10, 0.0, 1.25, r'$\mathbf{k}$  LCP ($\sigma\!=\!+1$)',
                fontsize=8.2, color='#0369a1', fontweight='bold', zorder=15)

    elif mode == 'rh':
        ax.quiver(0, 0, 0.60, 0, 0, 0.50, color='#e11d48', lw=2.4,
                  arrow_length_ratio=0.30, linewidth=2.8, alpha=0.95)
        ax.text(0.10, 0.0, 1.25, r'$\mathbf{k}$  RCP ($\sigma\!=\!-1$)',
                fontsize=8.2, color='#be123c', fontweight='bold', zorder=15)

    elif mode == 'ach':
        ax.quiver(0, 0, 0.60, 0, 0, 0.50, color='#64748b', lw=2.4,
                  arrow_length_ratio=0.30, linewidth=2.8, alpha=0.90)
        ax.text(0.10, 0.0, 1.25, r'$\mathbf{k}$  (unpolarized)',
                fontsize=8.2, color='#334155', fontweight='bold', zorder=15)

    ax.set_xlim(-1.32, 1.32)
    ax.set_ylim(-1.32, 1.32)
    ax.set_zlim(-0.55, 1.45)
    ax.set_box_aspect([1.0, 1.0, 0.76])
    ax.view_init(elev=elev, azim=azim)
    ax.axis('off')


# ---------------------------------------------------------------------------
# Main figure layout (White background publication quality)
# ---------------------------------------------------------------------------

def generate_figure01():
    print('Generating Figure 1 (3D shiny metallic gold, white background)...', flush=True)

    plt.rcParams.update({
        'font.family': 'serif',
        'font.size': 10,
        'savefig.dpi': 300,
        'savefig.bbox': 'tight',
    })

    fig = plt.figure(figsize=(13.8, 4.3), dpi=300)
    fig.patch.set_facecolor('#ffffff')

    gs = gridspec.GridSpec(1, 4,
                           width_ratios=[1.0, 1.0, 1.0, 1.58],
                           left=0.01, right=0.98, bottom=0.03, top=0.89,
                           wspace=0.04)

    # ---------- Panel (a): Left-Handed (LH) ----------
    ax1 = fig.add_subplot(gs[0, 0], projection='3d')
    ax1.set_facecolor('#ffffff')
    draw_ring_3d(ax1, phi_deg=30.0, mode='lh', elev=32, azim=-52)
    ax1.set_title('(a) Left-Handed (LH)\n'
                  r'$\phi = +30^\circ$  ($C_6$ chiral)',
                  fontsize=9.6, fontweight='bold', color='#0f172a', pad=8)

    # ---------- Panel (b): Right-Handed (RH) ----------
    ax2 = fig.add_subplot(gs[0, 1], projection='3d')
    ax2.set_facecolor('#ffffff')
    draw_ring_3d(ax2, phi_deg=-30.0, mode='rh', elev=32, azim=-52)
    ax2.set_title('(b) Right-Handed (RH)\n'
                  r'$\phi = -30^\circ$  ($C_6$ chiral)',
                  fontsize=9.6, fontweight='bold', color='#0f172a', pad=8)

    # ---------- Panel (c): Achiral Control ----------
    ax3 = fig.add_subplot(gs[0, 2], projection='3d')
    ax3.set_facecolor('#ffffff')
    draw_ring_3d(ax3, phi_deg=0.0, mode='ach', elev=32, azim=-52)
    ax3.set_title('(c) Achiral Control\n'
                  r'$\phi = 0^\circ$  ($D_{6h}$ planar)',
                  fontsize=9.6, fontweight='bold', color='#0f172a', pad=8)

    # ---------- Panel (d): Mechanistic Flowchart (Publication styling) ----------
    ax4 = fig.add_subplot(gs[0, 3])
    ax4.set_facecolor('#ffffff')

    fig.canvas.draw()
    pos1 = ax1.get_position()
    pos4 = ax4.get_position()
    ax4.set_position([pos4.x0, 0.04, pos4.width, pos1.y1 - 0.04])

    ax4.axis('off')
    ax4.set_xlim(0, 10)
    ax4.set_ylim(0, 10)

    boxes = [
        (8.35, r'1. Structural Chirality ($D_{6h} \to C_6$)',
         r'Structural Twist $\phi = +30^\circ$ Breaks $\sigma_h$ Mirror',
         '#f0f9ff', '#0284c7', '#0369a1'),
        (6.30, r'2. Multipolar Mode Activation',
         r'Collective Magnetic Dipole: $P_{\mathrm{MD}}/P_{\mathrm{ED}} \approx 0.472$',
         '#fff1f2', '#e11d48', '#be123c'),
        (4.25, r'3. Near-Kerker Scattering Interference',
         r'Phase Difference $\Delta\phi \approx 14.2^\circ \to \eta_{\mathrm{fwd}} \approx 73.1\%$',
         '#f0fdf4', '#16a34a', '#15803d'),
        (2.20, r'4. Helicity-Controlled Optomechanics',
         r'Recoil Force $F_z \approx 58.3$ fN $\mid$ Torque $\tau_z \approx 36.2$ zN$\cdot$m',
         '#faf5ff', '#9333ea', '#7e22ce'),
    ]

    for y, title, detail, fc, ec, tc in boxes:
        box = FancyBboxPatch((0.25, y - 0.70), 9.50, 1.40,
                             boxstyle='round,pad=0.15,rounding_size=0.25',
                             facecolor=fc, edgecolor=ec, lw=1.8, zorder=2)
        ax4.add_patch(box)
        ax4.text(5.0, y + 0.18, title,
                 ha='center', va='center', fontsize=8.4, fontweight='bold',
                 color=tc, zorder=3)
        ax4.text(5.0, y - 0.22, detail,
                 ha='center', va='center', fontsize=7.8, fontweight='normal',
                 color='#1e293b', zorder=3)

    # Clean directional arrows
    for y_s, y_e in [(7.56, 7.05), (5.51, 5.00), (3.46, 2.95)]:
        ax4.annotate('', xy=(5.0, y_e), xytext=(5.0, y_s),
                     arrowprops=dict(arrowstyle='->', lw=2.0, color='#64748b',
                                     mutation_scale=12),
                     zorder=4)

    ax4.set_title('(d) Electrodynamic Pathway\nMechanistic Causality Chain',
                  fontsize=9.6, fontweight='bold', color='#0f172a', pad=8)

    # Export under both names to cover all references
    export_figure(fig, 'figure01_geometry_3d')
    export_figure(fig, 'figure01_geometry')
    plt.close('all')
    print('Done! figure01_geometry and figure01_geometry_3d successfully exported with white background.', flush=True)

if __name__ == '__main__':
    generate_figure01()
