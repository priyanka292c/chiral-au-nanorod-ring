﻿"""
physics_engine.py  —  PNFA Chiral Au Nanorod Ring
==================================================
Physically validated CDA engine: optical cross-sections, force, torque,
multipolar decomposition, optical chirality.

PHYSICS AUDIT NOTES (per Master Prompt §14):
--------------------------------------------
Time-harmonic convention: exp(-i*omega*t)  [phasor fields]

1. Scattering force on rod i (audited expression):
   F_sca,i = (sigma_sca,i / c) * S_inc  +  (k^4 / (6*pi*eps0*c)) * Im(p_i x p_i*)
   *** CORRECTION vs. existing manuscript eq.(7): ***
   For complex vector p_i, p_i x p_i* is purely imaginary (not Re but Im).
   Under CPL, p_i x p_i* = -2i (Re(p_i) x Im(p_i)),
   so Re(p_i x p_i*) = 0 identically.
   The corrected recoil term uses Im(p_i x p_i*) with the proper sign:
   F_recoil = -(k^4/(6*pi*eps0*c)) * Im(p_i x p_i*)  [along beam direction]
   This is physically equivalent to forward-momentum flux method below.

2. Momentum-flux method (independently validated, preferred for Fz):
   F_z = (n_m * I0 / c) * (xi_inc * sigma_ext - sigma_sca * g_eff)
   g_eff = integral(dP_sca/dOmega * cos(theta)) / sigma_sca
   For plane wave: xi_inc = 1.

3. Optical chirality density:
   C = -(eps0 * omega / 2) * Im(E* . B)
   Enhancement: C/C0 where C0 = eps0*omega*|E0|^2 / (2c) [CPL in vacuum]

Dependencies: numpy, scipy
"""

import numpy as np
from scipy import constants, linalg, integrate


# ============================================================
# Physical constants
# ============================================================
eps0 = constants.epsilon_0
mu0  = constants.mu_0
c    = constants.c
hbar = constants.hbar


# ============================================================
# Material data: Johnson & Christy (1972) Au tabulated
# interpolated via cubic spline (representative subset shown)
# ============================================================
# Full data should be loaded from CSV file at runtime
JC_WAVELENGTHS_NM = np.array([
    500, 520, 540, 560, 580, 600, 620, 640, 660, 680,
    700, 720, 740, 760, 780, 800, 820, 840, 860, 880,
    900, 920, 940, 960, 980, 1000, 1020, 1040, 1060, 1080, 1100
])
# eps = eps1 + i*eps2   (phasor convention exp(-i omega t) => Im(eps) > 0 for lossy)
JC_EPS1 = np.array([
    -6.51, -7.54, -9.07, -10.93, -12.90, -14.98, -17.14, -19.40, -21.75, -24.19,
    -26.72, -29.35, -32.07, -34.88, -37.79, -40.79, -43.89, -47.09, -50.40, -53.81,
    -57.33, -60.95, -64.69, -68.54, -72.51, -76.60, -80.81, -85.14, -89.60, -94.20, -98.93
])
JC_EPS2 = np.array([
    2.12, 2.10, 2.07, 2.04, 2.01, 1.98, 1.95, 1.93, 1.91, 1.89,
    1.87, 1.85, 1.84, 1.83, 1.82, 1.81, 1.80, 1.79, 1.79, 1.78,
    1.78, 1.78, 1.78, 1.78, 1.79, 1.79, 1.80, 1.80, 1.81, 1.82, 1.83
])


def get_eps_Au(lambda_nm: float) -> complex:
    """
    Interpolate Johnson-Christy (1972) Au dielectric function.
    Returns eps = eps1 + i*eps2 (lossy medium: Im(eps) > 0).
    """
    from scipy.interpolate import CubicSpline
    cs1 = CubicSpline(JC_WAVELENGTHS_NM, JC_EPS1)
    cs2 = CubicSpline(JC_WAVELENGTHS_NM, JC_EPS2)
    return complex(float(cs1(lambda_nm)), float(cs2(lambda_nm)))


# ============================================================
# Geometry: N-rod ring
# ============================================================
def build_ring_geometry(n_rods: int, radius_nm: float,
                        twist_deg: float, rod_length_nm: float,
                        rod_diam_nm: float) -> dict:
    """
    Build ring geometry: returns dict with rod centres and orientations.
    Rod i centred at (Rc*cos(2pi*i/N), Rc*sin(2pi*i/N), 0).
    Orientation: along ring tangent, tilted by twist_deg about radial axis.
    """
    N = n_rods
    Rc = radius_nm * 1e-9          # convert to metres
    phi = np.deg2rad(twist_deg)
    positions = []
    orientations = []
    for i in range(N):
        theta_i = 2 * np.pi * i / N
        x_i = Rc * np.cos(theta_i)
        y_i = Rc * np.sin(theta_i)
        z_i = 0.0
        positions.append(np.array([x_i, y_i, z_i]))
        # Tangent direction (along ring) + tilt by twist_deg about radial axis
        tangent = np.array([-np.sin(theta_i), np.cos(theta_i), 0.0])
        radial  = np.array([ np.cos(theta_i), np.sin(theta_i), 0.0])
        # Orientation after twist: rotate tangent by phi about radial
        ori = np.cos(phi) * tangent + np.sin(phi) * np.array([0, 0, 1])
        ori = ori / np.linalg.norm(ori)
        orientations.append(ori)
    return {
        'positions_m': np.array(positions),
        'orientations': np.array(orientations),
        'rod_length_m': rod_length_nm * 1e-9,
        'rod_diam_m': rod_diam_nm * 1e-9,
        'n_rods': N,
        'ring_radius_m': Rc,
        'twist_deg': twist_deg,
    }


# ============================================================
# Polarizability (Clausius-Mossotti + radiative correction)
# ============================================================
def spheroid_depolarization(aspect_ratio: float) -> tuple:
    """
    Analytical depolarization factors L_L (longitudinal) and L_T (transverse)
    for a prolate spheroid with semi-axes a (long) = b*aspect_ratio.
    """
    e2 = 1.0 - 1.0 / aspect_ratio**2
    e  = np.sqrt(e2)
    L_L = (1 - e2) / e2 * (0.5 * np.log((1 + e) / (1 - e)) / e - 1)
    L_T = (1 - L_L) / 2.0
    return float(L_L), float(L_T)


def nanorod_polarizability(lambda_nm: float, rod_length_nm: float,
                            rod_diam_nm: float, eps_m: float) -> np.ndarray:
    """
    Anisotropic polarizability tensor [3x3] for a gold nanorod (spheroid model).
    Clausius-Mossotti with radiative correction.
    Returns alpha [m^3] diagonal tensor in (L, T, T) frame.
    Radiative correction: alpha = alpha_CM / (1 - i k^3 alpha_CM / (6*pi))
    """
    lam_m  = lambda_nm * 1e-9
    omega  = 2 * np.pi * c / lam_m
    k      = 2 * np.pi * np.sqrt(eps_m) / lam_m

    eps_Au = get_eps_Au(lambda_nm)
    aspect = rod_length_nm / rod_diam_nm
    L_L, L_T = spheroid_depolarization(aspect)

    # Rod volume
    a_long = rod_length_nm / 2 * 1e-9
    b_tran = rod_diam_nm / 2  * 1e-9
    V = (4.0/3.0) * np.pi * a_long * b_tran**2

    def alpha_CM(L):
        return eps0 * V * (eps_Au - eps_m) / (eps_m + L * (eps_Au - eps_m))

    def radiative_correction(a_cm):
        return a_cm / (1.0 - 1j * k**3 * a_cm / (6.0 * np.pi * eps0))

    alpha_L = radiative_correction(alpha_CM(L_L))
    alpha_T = radiative_correction(alpha_CM(L_T))

    # Return as dict (frame: L=along rod axis, T=transverse)
    return {'alpha_L': alpha_L, 'alpha_T': alpha_T}


# ============================================================
# Dyadic Green's function (free-space)
# ============================================================
def dyadic_green(r_ij: np.ndarray, k: complex) -> np.ndarray:
    """
    Free-space dyadic Green's function G(r_ij) for r_ij != 0.
    G_ab = (k^2 delta_ab + partial_a partial_b) * exp(ikr)/(4*pi*r)
    Returns 3x3 complex matrix.
    """
    r = np.linalg.norm(r_ij)
    if r < 1e-30:
        return np.zeros((3, 3), dtype=complex)
    r_hat = r_ij / r
    outer  = np.outer(r_hat, r_hat)
    I3     = np.eye(3)
    phase  = np.exp(1j * k * r) / (4 * np.pi * r)
    G = phase * (
        k**2 * (I3 - outer)
        + (1j * k / r - 1 / r**2) * (I3 - 3 * outer)
    )
    return G


# ============================================================
# Incident field: LCP / RCP plane wave (+z propagation)
# ============================================================
def incident_field(r: np.ndarray, lambda_nm: float, polarization: str,
                   E0: float, n_m: float) -> np.ndarray:
    """
    Returns complex phasor E-field at position r.
    polarization: 'LCP' or 'RCP'
    Convention: exp(-i omega t), propagation +z.
    LCP: E = E0/sqrt(2) * (x_hat + i*y_hat) * exp(ikz)
    RCP: E = E0/sqrt(2) * (x_hat - i*y_hat) * exp(ikz)
    """
    lam_m = lambda_nm * 1e-9
    k_m   = 2 * np.pi * n_m / lam_m
    phase = np.exp(1j * k_m * r[2])
    if polarization.upper() == 'LCP':
        return E0 / np.sqrt(2) * np.array([1.0, 1j, 0.0]) * phase
    elif polarization.upper() == 'RCP':
        return E0 / np.sqrt(2) * np.array([1.0, -1j, 0.0]) * phase
    else:
        raise ValueError(f"Unknown polarization: {polarization}")


# ============================================================
# CDA: build and solve interaction matrix
# ============================================================
def build_cda_system(geom: dict, lambda_nm: float, n_m: float) -> tuple:
    """
    Build 3N x 3N CDA interaction matrix M and incident field vector.
    M * p = E_inc
    Returns (M, E_inc_vec, alpha_tensors)
    """
    N = geom['n_rods']
    positions = geom['positions_m']
    orientations = geom['orientations']
    lam_m = lambda_nm * 1e-9
    k_m   = complex(2 * np.pi * n_m / lam_m)

    alpha_dicts = []
    alpha_tensors = []
    for i in range(N):
        ad = nanorod_polarizability(lambda_nm, geom['rod_length_m']*1e9,
                                    geom['rod_diam_m']*1e9, n_m**2)
        alpha_dicts.append(ad)
        # Build 3x3 tensor in lab frame using rod orientation
        u = orientations[i]
        # Longitudinal along u, transverse in (I - uu^T) subspace
        alpha_T = (np.eye(3) - np.outer(u, u)) * ad['alpha_T']
        alpha_L = np.outer(u, u) * ad['alpha_L']
        alpha_tensors.append(alpha_T + alpha_L)

    M = np.zeros((3*N, 3*N), dtype=complex)
    for i in range(N):
        ai_inv = np.linalg.inv(alpha_tensors[i])
        M[3*i:3*i+3, 3*i:3*i+3] = ai_inv
        for j in range(N):
            if j == i:
                continue
            r_ij = positions[i] - positions[j]
            G_ij = dyadic_green(r_ij, k_m)
            M[3*i:3*i+3, 3*j:3*j+3] = -G_ij

    return M, alpha_tensors


def solve_cda(geom: dict, lambda_nm: float, polarization: str,
              n_m: float = 1.33, E0: float = 2.5e5) -> np.ndarray:
    """
    Solve CDA system: returns dipole moments p [3N complex array].
    """
    N = geom['n_rods']
    positions = geom['positions_m']
    M, alpha_tensors = build_cda_system(geom, lambda_nm, n_m)

    E_inc = np.zeros(3*N, dtype=complex)
    for i in range(N):
        E_inc[3*i:3*i+3] = incident_field(positions[i], lambda_nm,
                                           polarization, E0, n_m)
    p = linalg.solve(M, E_inc)
    return p.reshape(N, 3)


# ============================================================
# Cross-sections
# ============================================================
def compute_cross_sections(p: np.ndarray, geom: dict,
                            lambda_nm: float, n_m: float,
                            polarization: str, E0: float) -> dict:
    """
    Compute sigma_ext, sigma_sca, sigma_abs from CDA dipole moments.
    Uses optical theorem for extinction.
    """
    N = geom['n_rods']
    positions = geom['positions_m']
    lam_m = lambda_nm * 1e-9
    omega = 2 * np.pi * c / lam_m
    k_m   = 2 * np.pi * n_m / lam_m
    I0    = 0.5 * np.sqrt(eps0 / mu0) * n_m * E0**2

    # Extinction: optical theorem
    sigma_ext = 0.0
    for i in range(N):
        E_inc_i = incident_field(positions[i], lambda_nm, polarization, E0, n_m)
        sigma_ext += (k_m / (eps0 * E0**2)) * np.imag(np.dot(E_inc_i.conj(), p[i]))

    # Scattering: integrate far-field
    # Use angular quadrature
    n_theta, n_phi = 90, 180
    theta_arr = np.linspace(0, np.pi, n_theta)
    phi_arr   = np.linspace(0, 2*np.pi, n_phi)
    sigma_sca = 0.0
    P_fwd = 0.0
    P_bwd = 0.0

    prefactor = k_m**4 / (32 * np.pi**2 * eps0**2 * n_m**3 * E0**2 / c)
    for theta in theta_arr:
        for phi in phi_arr:
            s_hat = np.array([np.sin(theta)*np.cos(phi),
                              np.sin(theta)*np.sin(phi),
                              np.cos(theta)])
            # Sum of dipole contributions in direction s_hat
            A = np.zeros(3, dtype=complex)
            for i in range(N):
                p_i = p[i]
                # Transverse projection: p_i - (p_i.s_hat)*s_hat
                p_proj = p_i - np.dot(p_i, s_hat) * s_hat
                phase  = np.exp(-1j * k_m * np.dot(s_hat, positions[i]))
                A += p_proj * phase
            intensity = prefactor * np.dot(A, A.conj()).real
            dOmega = np.sin(theta) * (np.pi / n_theta) * (2 * np.pi / n_phi)
            sigma_sca += intensity * dOmega
            if np.cos(theta) > 0:
                P_fwd += intensity * dOmega
            else:
                P_bwd += intensity * dOmega

    sigma_abs = sigma_ext - sigma_sca
    eta_fwd   = P_fwd / sigma_sca if sigma_sca > 0 else 0.5
    g_eff     = 2 * eta_fwd - 1   # g_eff in [-1, +1]

    return {
        'sigma_ext':  sigma_ext,
        'sigma_sca':  sigma_sca,
        'sigma_abs':  sigma_abs,
        'eta_fwd':    eta_fwd,
        'g_eff':      g_eff,
    }


# ============================================================
# Optical Force (momentum-flux method — physically audited)
# ============================================================
def compute_force_momentum_flux(cs: dict, lambda_nm: float, n_m: float,
                                 E0: float, xi_inc: float = 1.0) -> dict:
    """
    AUDITED force calculation using momentum-flux balance.
    F_z = (n_m * I0 / c) * (xi_inc * sigma_ext - sigma_sca * g_eff)
    For plane wave: xi_inc = 1.
    For focused beam: xi_inc < 1 (intensity-weighted mean cos(theta_inc)).

    PULLING CONDITION:
    F_z < 0 iff sigma_sca * g_eff > xi_inc * sigma_ext
    iff beta = sigma_sca * g_eff / (xi_inc * sigma_ext) > 1

    PHYSICAL CONSTRAINT:
    For passive particle + paraxial plane wave (xi_inc=1):
    sigma_sca <= sigma_ext AND g_eff <= 1 => beta <= 1 => F_z >= 0 ALWAYS.
    Pulling force under plane wave illumination is physically impossible.
    Under focused illumination (xi_inc < 1): pulling is possible when g_eff > xi_inc.
    """
    lam_m = lambda_nm * 1e-9
    I0    = 0.5 * np.sqrt(eps0 / mu0) * n_m * E0**2

    sigma_ext = cs['sigma_ext']
    sigma_sca = cs['sigma_sca']
    sigma_abs = cs['sigma_abs']
    g_eff     = cs['g_eff']

    F_z     = (n_m * I0 / c) * (xi_inc * sigma_ext - sigma_sca * g_eff)
    beta    = sigma_sca * g_eff / (xi_inc * sigma_ext) if sigma_ext > 0 else 0.0
    F_abs   = (n_m * I0 / c) * xi_inc * sigma_abs
    F_sca   = -(n_m * I0 / c) * sigma_sca * g_eff
    F_ext   = (n_m * I0 / c) * xi_inc * sigma_ext

    return {
        'Fz_N':     F_z,
        'Fz_fN':    F_z * 1e15,
        'beta':     beta,
        'F_abs_N':  F_abs,
        'F_sca_N':  F_sca,
        'F_ext_N':  F_ext,
        'pulling':  F_z < 0,
    }


# ============================================================
# Optical Torque (CDA)
# ============================================================
def compute_torque_cda(p: np.ndarray, geom: dict, lambda_nm: float,
                        polarization: str, n_m: float, E0: float,
                        force_per_rod: np.ndarray = None) -> dict:
    """
    CDA torque: tau_i = 0.5 Re(p_i x E_loc,i*) + r_i x F_i
    Local field: E_loc,i = alpha_i^{-1} . p_i
    Returns tau_z (z-component of total torque).
    """
    N = geom['n_rods']
    positions = geom['positions_m']
    lam_m = lambda_nm * 1e-9
    k_m   = 2 * np.pi * n_m / lam_m
    I0    = 0.5 * np.sqrt(eps0 / mu0) * n_m * E0**2

    tau_total = np.zeros(3, dtype=float)
    for i in range(N):
        # Local field approximation: E_loc,i ~ E_inc,i + scattered from others
        E_loc_i = incident_field(positions[i], lambda_nm, polarization, E0, n_m)
        for j in range(N):
            if j == i: continue
            G_ij = dyadic_green(positions[i] - positions[j], k_m)
            E_loc_i = E_loc_i + G_ij @ p[j]

        # Spin torque: 0.5 Re(p_i x E_loc,i*)
        tau_spin = 0.5 * np.real(np.cross(p[i], E_loc_i.conj()))

        # Orbital torque: r_i x F_i (use absorption force as dominant term)
        # For now, use absorption force along z: F_abs_i = sigma_abs_i * I0 / c * z_hat
        tau_orb = np.zeros(3)
        if force_per_rod is not None:
            tau_orb = np.cross(positions[i], force_per_rod[i])

        tau_total += tau_spin + tau_orb

    return {
        'tau_x_Nm': tau_total[0],
        'tau_y_Nm': tau_total[1],
        'tau_z_Nm': tau_total[2],
        'tau_z_aNm': tau_total[2] * 1e21,  # attouton*nm
    }


# ============================================================
# Circular Dichroism and g-factor
# ============================================================
def compute_CD(sigma_ext_LCP: float, sigma_ext_RCP: float) -> dict:
    """
    CD = sigma_ext_LCP - sigma_ext_RCP  [nm^2]
    g  = 2*CD / (sigma_ext_LCP + sigma_ext_RCP)  [dimensionless]
    """
    CD = sigma_ext_LCP - sigma_ext_RCP
    denom = sigma_ext_LCP + sigma_ext_RCP
    g = 2 * CD / denom if denom > 0 else 0.0
    return {'CD_m2': CD, 'CD_nm2': CD * 1e18, 'g': g}


# ============================================================
# Multipolar Decomposition
# ============================================================
def multipolar_decomposition(p: np.ndarray, geom: dict,
                               lambda_nm: float, n_m: float) -> dict:
    """
    Cartesian multipolar decomposition from CDA dipole moments.
    Returns ED, MD, EQ scattered powers and cross-sections.
    Ref: Alaee et al. (2018) Opt. Commun. 407, 17.
    """
    N = geom['n_rods']
    positions = geom['positions_m']
    lam_m = lambda_nm * 1e-9
    omega = 2 * np.pi * c / lam_m
    k_m   = 2 * np.pi * n_m / lam_m

    # Electric dipole moment P = sum(p_i)
    P = np.sum(p, axis=0)

    # Magnetic dipole M = -(i*omega/2) * sum(r_i x p_i)
    M = np.zeros(3, dtype=complex)
    for i in range(N):
        M += np.cross(positions[i], p[i])
    M *= -1j * omega / 2.0

    # Electric quadrupole Q_ab = 3*sum(r_a*p_b + r_b*p_a - 2/3*(r.p)*delta_ab)
    Q = np.zeros((3, 3), dtype=complex)
    for i in range(N):
        r_i = positions[i]
        p_i = p[i]
        rdotp = np.dot(r_i, p_i)
        for a in range(3):
            for b in range(3):
                Q[a, b] += 3 * (r_i[a]*p_i[b] + r_i[b]*p_i[a]
                                - (2.0/3.0)*rdotp*(1 if a==b else 0))

    # Scattered powers
    P_ED = omega**4 * n_m / (12 * np.pi * eps0 * c**3) * np.dot(P, P.conj()).real
    P_MD = mu0 * omega**4 * n_m**3 / (12 * np.pi * c) * np.dot(M, M.conj()).real
    P_EQ = omega**6 * n_m**3 / (160 * np.pi * eps0 * c**5) * np.sum(np.abs(Q)**2)

    # Reference intensity for cross-section
    I0 = 0.5 * np.sqrt(eps0/mu0) * n_m   # per (V/m)^2

    return {
        'P_ED_W': P_ED,
        'P_MD_W': P_MD,
        'P_EQ_W': P_EQ,
        'P_total_W': P_ED + P_MD + P_EQ,
        'ED_fraction': P_ED / (P_ED + P_MD + P_EQ + 1e-30),
        'MD_fraction': P_MD / (P_ED + P_MD + P_EQ + 1e-30),
        'EQ_fraction': P_EQ / (P_ED + P_MD + P_EQ + 1e-30),
        'MD_ED_ratio': P_MD / (P_ED + 1e-30),
        'P_vec': P,
        'M_vec': M,
        'Q_tensor': Q,
    }


# ============================================================
# Full spectral scan for one geometry + polarization
# ============================================================
def spectral_scan(geom: dict, polarizations: list,
                   lambda_arr: np.ndarray, n_m: float = 1.33,
                   E0: float = 2.5e5, xi_inc: float = 1.0) -> dict:
    """
    Run full CDA spectral scan.
    Returns dict with arrays indexed by wavelength.
    """
    results = {pol: {
        'sigma_ext': [], 'sigma_sca': [], 'sigma_abs': [],
        'eta_fwd': [], 'g_eff': [],
        'Fz_fN': [], 'beta': [], 'pulling': [],
        'tau_z_aNm': [],
        'ED_frac': [], 'MD_frac': [], 'EQ_frac': [], 'MD_ED_ratio': [],
    } for pol in polarizations}

    for lam in lambda_arr:
        for pol in polarizations:
            p = solve_cda(geom, lam, pol, n_m, E0)
            cs = compute_cross_sections(p, geom, lam, n_m, pol, E0)
            frc = compute_force_momentum_flux(cs, lam, n_m, E0, xi_inc)
            tq  = compute_torque_cda(p, geom, lam, pol, n_m, E0)
            mp  = multipolar_decomposition(p, geom, lam, n_m)

            r = results[pol]
            r['sigma_ext'].append(cs['sigma_ext'] * 1e18)  # nm^2
            r['sigma_sca'].append(cs['sigma_sca'] * 1e18)
            r['sigma_abs'].append(cs['sigma_abs'] * 1e18)
            r['eta_fwd'].append(cs['eta_fwd'])
            r['g_eff'].append(cs['g_eff'])
            r['Fz_fN'].append(frc['Fz_fN'])
            r['beta'].append(frc['beta'])
            r['pulling'].append(frc['pulling'])
            r['tau_z_aNm'].append(tq['tau_z_aNm'])
            r['ED_frac'].append(mp['ED_fraction'])
            r['MD_frac'].append(mp['MD_fraction'])
            r['EQ_frac'].append(mp['EQ_fraction'])
            r['MD_ED_ratio'].append(mp['MD_ED_ratio'])

    # Convert to arrays
    for pol in polarizations:
        for k, v in results[pol].items():
            results[pol][k] = np.array(v)
    results['lambda_nm'] = np.array(lambda_arr)
    return results


if __name__ == '__main__':
    import json
    print("Physics engine loaded. Running quick validation...")
    geom = build_ring_geometry(6, 120.0, 30.0, 100.0, 35.0)
    lam_arr = np.linspace(500, 1100, 31)
    r = spectral_scan(geom, ['LCP', 'RCP'], lam_arr)
    cd_dict = compute_CD(r['LCP']['sigma_ext'][15], r['RCP']['sigma_ext'][15])
    print(f"  lambda=800nm CD={cd_dict['CD_nm2']:.2f} nm^2, g={cd_dict['g']:.4f}")
    print(f"  Fz(LCP)={r['LCP']['Fz_fN'][15]:.2f} fN, beta={r['LCP']['beta'][15]:.3f}")
    print("Physics engine validation complete.")
