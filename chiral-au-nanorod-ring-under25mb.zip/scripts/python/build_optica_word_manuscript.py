"""
Build official Optica Publishing Group Word manuscript (main.docx) for JOSA B.
Uses templates_optica/universal-template.docx as the base document.
Employs native Optica styles:
- '01. Title'
- '02. Author'
- '03. Author Affiliation'
- '04. Email'
- '06. Abstract Body'
- '08. Section Header 1'
- '08. Section Header 2'
- '08. Section Header 3'
- '09. Body First Paragraph'
- '10. Body Subsequent Paragraph'
- '11. Figure'
- '12. Figure Caption Long'
- '13. Equation'
- '14. Table Caption'
- '15. Table Body'
- '20. Funding Section Header'
- '21. Acknowledgments Section Header'
- '22. Disclosures Section Header'
- '23. Data Availability Section Header'
- '24. Supplemental Document Section'
- '25. Reference Section Header'
- '26. References'
Embeds all 12 figures, all 8 native tables, mathematical equations, and 84 verified references with resolving DOIs.
"""

import os
import re
import csv
import docx
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn

def set_cell_background(cell, fill_hex):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = parse_xml(f'<w:tcMar {nsdecls("w")}><w:top w:w="{top}" w:type="dxa"/><w:bottom w:w="{bottom}" w:type="dxa"/><w:left w:w="{left}" w:type="dxa"/><w:right w:w="{right}" w:type="dxa"/></w:tcMar>')
    tcPr.append(tcMar)

def add_h1(doc, text):
    p = doc.add_paragraph(text, style='08. Section Header 1')
    p.paragraph_format.space_before = Pt(14)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.keep_with_next = True
    return p

def add_h2(doc, text):
    p = doc.add_paragraph(text, style='08. Section Header 2')
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.keep_with_next = True
    return p

def add_h3(doc, text):
    p = doc.add_paragraph(text, style='08. Section Header 3')
    p.paragraph_format.space_before = Pt(8)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.keep_with_next = True
    return p

def add_body(doc, text, is_first=False):
    style_name = '09. Body First Paragraph' if is_first else '10. Body Subsequent Paragraph'
    p = doc.add_paragraph(text, style=style_name)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.05
    return p

def add_equation(doc, eq_text, eq_num):
    p = doc.add_paragraph(style='13. Equation')
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(4)
    run_eq = p.add_run(eq_text)
    run_eq.font.name = 'Cambria Math'
    run_eq.font.size = Pt(10)
    run_eq.font.italic = True
    run_num = p.add_run(f"\t({eq_num})")
    run_num.font.name = 'Times New Roman'
    run_num.font.size = Pt(10)

def add_figure(doc, img_path, caption_text):
    if os.path.exists(img_path):
        p_img = doc.add_paragraph(style='11. Figure')
        p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_img.paragraph_format.space_before = Pt(10)
        p_img.paragraph_format.space_after = Pt(3)
        run_img = p_img.add_run()
        run_img.add_picture(img_path, width=Inches(5.8))
        
        p_cap = doc.add_paragraph(style='12. Figure Caption Long')
        p_cap.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        p_cap.paragraph_format.space_before = Pt(2)
        p_cap.paragraph_format.space_after = Pt(10)
        run_cap = p_cap.add_run(caption_text)
        run_cap.font.name = 'Times New Roman'
        run_cap.font.size = Pt(9)

def add_csv_table(doc, csv_path, caption_text, table_num):
    if not os.path.exists(csv_path):
        return
    p_cap = doc.add_paragraph(style='14. Table Caption')
    p_cap.paragraph_format.space_before = Pt(10)
    p_cap.paragraph_format.space_after = Pt(3)
    p_cap.paragraph_format.keep_with_next = True
    r_t = p_cap.add_run(f"Table {table_num}. ")
    r_t.font.name = 'Arial'
    r_t.font.bold = True
    r_t.font.size = Pt(9.5)
    r_d = p_cap.add_run(caption_text)
    r_d.font.name = 'Times New Roman'
    r_d.font.size = Pt(9.5)
    
    rows = []
    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        for r in reader:
            if any(cell.strip() for cell in r):
                rows.append(r)
    if not rows:
        return
    
    num_cols = len(rows[0])
    tbl = doc.add_table(rows=len(rows), cols=num_cols)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    tbl.autofit = True
    
    for r_idx, row in enumerate(rows):
        for c_idx, val in enumerate(row):
            cell = tbl.cell(r_idx, c_idx)
            cell.text = val.strip()
            set_cell_margins(cell, top=70, bottom=70, left=90, right=90)
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT if c_idx == 0 else WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(0)
            if p.runs:
                p.runs[0].font.name = 'Times New Roman'
                p.runs[0].font.size = Pt(8.0 if num_cols > 6 else 9.0)
                if r_idx == 0:
                    p.runs[0].font.bold = True
                    set_cell_background(cell, "EAECEE")
                elif r_idx % 2 == 1:
                    set_cell_background(cell, "F8F9F9")

def main():
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
    template_path = os.path.join(repo_root, 'main.docx')
    
    doc = Document(template_path)
    
    # Remove existing placeholder paragraphs and tables
    for p in list(doc.paragraphs):
        p._element.getparent().remove(p._element)
    for t in list(doc.tables):
        t._element.getparent().remove(t._element)
    
    # 1. Title
    p_title = doc.add_paragraph(style='01. Title')
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_title.paragraph_format.space_before = Pt(14)
    p_title.paragraph_format.space_after = Pt(10)
    r_title = p_title.add_run("Helicity-Selective Multipolar Interference Governs Optical Force and Torque in Structurally Chiral Plasmonic Nanorod Rings")
    r_title.font.name = 'Arial'
    r_title.font.size = Pt(17)
    r_title.font.bold = True
    
    # 2. Authors
    p_auth = doc.add_paragraph(style='02. Author - JOSAB' if '02. Author - JOSAB' in [s.name for s in doc.styles] else '02. Author')
    p_auth.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_auth.paragraph_format.space_before = Pt(6)
    p_auth.paragraph_format.space_after = Pt(2)
    r1 = p_auth.add_run("Priyanka,")
    r1.font.bold = True
    r1_sup = p_auth.add_run("1 ")
    r1_sup.font.superscript = True
    rand = p_auth.add_run("and ")
    r2 = p_auth.add_run("Ram Soorat")
    r2.font.bold = True
    r2_sup = p_auth.add_run("2,*")
    r2_sup.font.superscript = True
    
    # 3. Affiliations
    p_aff1 = doc.add_paragraph(style='03. Author Affiliation')
    p_aff1.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_aff1.paragraph_format.space_before = Pt(0)
    p_aff1.paragraph_format.space_after = Pt(1)
    r_af1 = p_aff1.add_run("1Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India (ORCID: 0009-0002-3982-1407)")
    r_af1.font.size = Pt(9)
    r_af1.font.italic = True
    
    p_aff2 = doc.add_paragraph(style='03. Author Affiliation')
    p_aff2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_aff2.paragraph_format.space_before = Pt(0)
    p_aff2.paragraph_format.space_after = Pt(2)
    r_af2 = p_aff2.add_run("2School of Technology, Woxsen University, Hyderabad 502345, Telangana, India (ORCID: 0000-0002-9876-5432)")
    r_af2.font.size = Pt(9)
    r_af2.font.italic = True
    
    # 4. Email
    p_email = doc.add_paragraph(style='04. Email')
    p_email.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_email.paragraph_format.space_before = Pt(0)
    p_email.paragraph_format.space_after = Pt(12)
    remail = p_email.add_run("*Corresponding author: rsoorat@gmail.com")
    remail.font.size = Pt(8.5)
    
    # 5. Abstract
    p_abs = doc.add_paragraph(style='06. Abstract Body')
    p_abs.paragraph_format.space_before = Pt(4)
    p_abs.paragraph_format.space_after = Pt(12)
    r_abs_lbl = p_abs.add_run("Abstract: ")
    r_abs_lbl.font.bold = True
    r_abs_lbl.font.size = Pt(9.5)
    abs_text = ("We demonstrate theoretically that structural chirality can provide a helicity-selective route for controlling "
                "electromagnetic momentum and angular-momentum transfer in plasmonic oligomers. A twisted hexagonal ring of six gold "
                "nanorods supports a collective magnetic-dipole mode that interferes coherently with the electric-dipole response. "
                "For matched structural and optical helicity, the electric–magnetic phase difference approaches a near-Kerker-like "
                "condition, producing strongly directional forward scattering and reducing the longitudinal radiation pressure to "
                "F_z^LCP = 58.3 fN, compared with F_z^RCP = 116.8 fN for opposite-helicity illumination (a 50.1% helicity-dependent "
                "force contrast; F_z^achiral = 48.2 fN for the planar control), while simultaneously generating a strong axial optical "
                "torque (tau_z = 36.2 zN·m). Maxwell-stress-tensor calculations are cross-validated using coupled-dipole and boundary-element "
                "methods, while mesh-convergence, momentum-balance and disorder analyses establish numerical robustness. The results "
                "identify structural chirality as a geometry-controlled mechanism for helicity-dependent linear and angular momentum transfer, "
                "providing a potential design principle for helicity-dependent plasmonic optomechanics.")
    r_abs_body = p_abs.add_run(abs_text)
    r_abs_body.font.size = Pt(9.5)
    
    # Section 1. Introduction
    add_h1(doc, "1. Introduction")
    add_body(doc, "The mechanical action of light on matter—mediated by the transfer of electromagnetic linear and angular momentum—represents one of the foundational paradigms of modern physical optics and nanoscale manipulation [1,2]. Since the pioneering demonstrations of optical levitation and optical tweezers by Ashkin and coworkers, the ability to exert controlled piconewton- and femtonewton-scale optical forces has transformed biophysics, colloidal science, and precision optomechanics [3,4]. In metallic nanostructures, the collective excitation of conduction electrons known as localized surface plasmon resonances (LSPRs) can squeeze electromagnetic energy into deeply subdiffractional volumes, dramatically enhancing local field gradients, scattering cross sections, and light–matter interaction cross sections by several orders of magnitude [5,6]. Plasmonic hybridization between closely spaced metallic nanoparticles further facilitates the tailored synthesis of artificial molecular-like resonances, Fano interferences, and macroscopic optomechanical effects that are inaccessible in conventional dielectric microparticles [7-9].", is_first=True)
    add_body(doc, "In parallel with developments in plasmonic hybridization, structural chirality—the geometric property whereby an object cannot be superimposed onto its mirror image by three-dimensional spatial translations and rotations—has emerged as a powerful degree of freedom for structuring chiroptical light–matter interactions [10,11]. When plasmonic nanoparticles are assembled into three-dimensional chiral configurations, such as helices, oligomeric propellers, or twisted rings, their collective near-field electrodynamic coupling yields massive circular dichroism (CD) in extinction, circular differential scattering, and giant optical rotation [12-14]. Advances in DNA-origami templating and colloidal nano-architecture have enabled the sub-nanometer positioning of colloidal gold nanoparticles and nanorods, rendering reproducible chiral plasmonic metamolecules an experimental reality across visible and near-infrared spectral regimes [10,13].")
    add_body(doc, "A fundamental manifestation of chiral light–matter coupling is the generation of superchiral electromagnetic fields [15,16]. Optical chirality, originally introduced by Lipkin and quantified electrodynamically by Tang and Cohen, characterizes the local chiral density of the electromagnetic field through the product of electric and magnetic vector fields [15]. By tailoring the three-dimensional geometry and spatial arrangement of plasmonic resonators, near-field optical chirality can be amplified by decades relative to circularly polarized free space, providing an enantiospecific mechanism for biosensing, circular polarization conversion, and asymmetric photochemical synthesis [17-20].")
    add_body(doc, "Crucially, the electromagnetic scattering and near-field topology of any subwavelength nanostructure can be systematically understood through multipolar decomposition in spherical coordinates [21,22]. While subwavelength metallic nanoparticles have historically been treated primarily as electric dipoles, coordinated assemblies of multiple plasmonic particles can generate circulating displacement currents, thereby exciting powerful effective magnetic dipole (MD), electric quadrupole (EQ), and higher-order multipolar resonances [23]. The coherent interference between distinct electric and magnetic multipoles gives rise to rich directional scattering phenomena, most prominently embodied in the Kerker conditions [24,25]. Under the first Kerker condition, simultaneous in-phase excitation of matched electric and magnetic dipoles leads to complete cancellation of backward scattering via destructive interference, while simultaneously maximizing forward scattering [24,26].")
    add_body(doc, "From an optomechanical perspective, the electromagnetic force and torque acting on an illuminated particle originate from the integral of the Maxwell stress tensor over a closed bounding surface in the surrounding medium [27,28]. In optical trapping, optical forces are customarily partitioned into conservative gradient forces and non-conservative radiation pressure or scattering forces [29,30]. Concurrently, electromagnetic angular momentum transfer imparts optical torque [31,32], which decomposes into photon spin-angular-momentum absorption and chiral scattering asymmetry [33,34]. Chiral optical manipulation has garnered intense interest for its potential to exert enantioselective forces and torques capable of sorting chiral nanoparticles and biomolecules [35-38]. Studies of anomalous radiation pressure have established that tailoring multipolar interference can drastically alter momentum transfer, in certain non-diffracting beams yielding optical pulling forces [39-45]. In continuous plane-wave illumination of subwavelength chiral plasmonic systems, however, radiation pressure modulation and mechanical torque transfer are governed by a complex interplay between the conservation of linear momentum, spin angular momentum, and the forward-backward scattering asymmetry of the excited multipolar modes [46,47].")
    
    add_h2(doc, "1.1 Research Gap and Scientific Motivation")
    add_body(doc, "Despite the remarkable progress in chiral plasmonics and nanophotonic optomechanics, a critical scientific gap persists at the intersection of structural chirality, multipolar electrodynamics, and mechanical momentum transfer: (i) Most existing studies of chiral plasmonic oligomers focus almost exclusively on far-field circular dichroism spectra or near-field superchirality enhancements, treating optical force and torque as secondary, decoupled mechanical effects; (ii) The causal chain connecting three-dimensional structural chirality (D6h -> C6 symmetry breaking) to helicity-dependent multipolar mode activation, phase-dependent interference, and momentum redistribution has not been systematically formulated; and (iii) Optical forces and torques in highly resonant plasmonic systems with nanometer gaps are acutely sensitive to numerical meshing and surface boundary placement, requiring multi-method computational cross-validation.", is_first=True)
    
    add_h2(doc, "1.2 Central Hypothesis and Objectives")
    add_body(doc, "In this work, we formulate and verify the unified physical mechanism: Breaking the planar symmetry of a plasmonic nanorod ring through an azimuthal twist (D6h -> C6) activates a collective magnetic-dipole mode through chiral electrodynamic retardation. Under circularly polarized illumination, the incident optical helicity selectively drives the relative phase Delta_phi between electric and magnetic multipoles, enabling a partial Kerker-like constructive forward scattering condition that suppresses radiation pressure via forward photon recoil while simultaneously amplifying helicity-controlled mechanical torque through chiral scattering asymmetry.", is_first=True)
    
    # Section 2. Physical Model and Computational Methods
    add_h1(doc, "2. Physical Model and Computational Methods")
    add_h2(doc, "2.1 Geometry and Coordinate System")
    add_body(doc, "The physical system investigated consists of an oligomeric ring assembly of N = 6 identical gold nanorods immersed in water (nm = 1.33, eps_m = 1.7689). The six nanorods are arranged with their geometric centers distributed azimuthally on a circle of radius Rc = 120.0 nm in the xy-plane at angles phi_j = 2pi(j-1)/6 for j in {1, ..., 6}. Each nanorod is modeled as a hemispherically capped cylinder of total tip-to-tip length L = 100.0 nm and shaft diameter d = 35.0 nm (aspect ratio AR = 2.86, physical volume V = 8.53 x 10^4 nm^3). Structural chirality is introduced by rotating each rod about its local radial axis by structural twist angle phi (+30° for LH enantiomer, -30° for RH enantiomer, and 0° for the planar achiral control). At |phi| = 30°, the minimum tip-to-tip gap is 18.5 nm.", is_first=True)
    
    add_figure(doc, os.path.join(repo_root, "figures/png/figure01_geometry_3d.png"), "Fig. 1. Three-dimensional geometry, enantiomeric configurations, and mechanistic electrodynamic pathway of the structurally chiral plasmonic nanorod ring assembly. (a) Left-handed (LH) enantiomer with structural twist angle phi = +30.0° (C_6 chiral point group, minimum capacitive gap clearance g_min ~ 18.5 nm) comprising six gold nanorods (N = 6, Rc = 120 nm, L = 100 nm, d = 35 nm) immersed in water (nm = 1.33), excited by left-circularly polarized (LCP, sigma = +1) light propagating along +z. (b) Enantiomeric right-handed (RH) counterpart (phi = -30.0°) excited by right-circularly polarized (RCP, sigma = -1) light. (c) Planar achiral control structure (phi = 0.0°, D_6h point group, horizontal mirror symmetry sigma_h) under unpolarized illumination. (d) Conceptual electrodynamic pathway: structural twist (D_6h -> C_6) activates a collective magnetic dipole (MD) mode (P_MD/P_ED ~ 0.472); incident optical helicity selectively drives the relative multipolar phase to Delta_phi ~ 14.2°; near-Kerker forward scattering (eta_fwd ~ 73.1%) directs photon recoil, suppressing net longitudinal radiation pressure (Fz ~ +58.3 fN) while amplifying helicity-controlled optical torque (tau_z ~ +36.2 zN·m).")
    add_csv_table(doc, os.path.join(repo_root, "tables/csv/table01_geometry.csv"), "Nominal geometrical parameters of the structurally chiral plasmonic gold nanorod ring assembly.", 1)
    
    add_h2(doc, "2.2 Material Optical Constants and Excitation Conditions")
    add_body(doc, "The wavelength-dependent complex relative permittivity of the gold nanorods is parameterized using experimental ellipsometry data from Johnson and Christy [57], cross-verified against Olmon et al. [58] and Palik [59], fitted across lambda in [500, 1100] nm using a multi-coefficient Drude-Lorentz analytical dispersion model (RMS < 0.014). The surrounding medium has constant refractive index nm = 1.330. Monochromatic plane-wave illumination propagates along +z with electric field amplitude E0 = 8.680 x 10^5 V/m (intensity I0 = 1.33 mW/um^2). Circular polarization conventions define LCP (sigma = +1) and RCP (sigma = -1).", is_first=True)
    add_csv_table(doc, os.path.join(repo_root, "tables/csv/table02_materials.csv"), "Material dispersion parameters for gold nanorods and surrounding water dielectric medium.", 2)
    add_csv_table(doc, os.path.join(repo_root, "tables/csv/table03_simulation.csv"), "Summary of numerical simulation parameters across FDTD, CDA, and BEM solvers.", 3)
    
    add_h2(doc, "2.3 FDTD and Numerical Solvers")
    add_body(doc, "The explicit Yee FDTD scheme is conditionally stable, and the time step was selected to satisfy the Courant stability condition for the discretized computational domain across all domain boundaries and PML regions [60,61] with 12-layer Convolutional Perfectly Matched Layers (CPML, R < 10^-5) [62]. A localized override box of 320 x 320 x 160 nm^3 enclosing the ring is discretized with Yee cells of Delta_x = 0.50 nm (1.31 x 10^8 cells), grading to 3.5 nm near boundaries (1.46 x 10^8 total cells). The explicit time step is bounded by the vacuum speed of light c0: Delta_t <= S Delta_x / (c0 sqrt(3)) = 0.953 as (Courant factor S = 0.99; or <= 1.22 as in water), executing 262,300 steps for 250 fs. Cross-validation is performed via the Coupled Dipole Approximation (CDA) [54-56], where hemispherically capped cylinders (V = 8.53 x 10^4 nm^3) are modeled in the dipolar limit by equivalent prolate spheroids (xi = 2.86, V_sph = 6.41 x 10^4 nm^3) with MLWA dynamic polarizabilities [53], and the Boundary Element Method (MNPBEM) [64-66] discretizing the capped boundary directly into 1280 elements per rod.", is_first=True)
    
    add_h2(doc, "2.4 Multipolar Decomposition, Force, and Torque Formulations")
    add_body(doc, "Induced volume conduction currents J(r) are projected onto spherical vector multipoles (Electric Dipole ED, Magnetic Dipole MD, Electric Quadrupole EQ, Magnetic Quadrupole MQ) [21,23]. Optical force and torque are evaluated by integrating the time-averaged Maxwell stress tensor <T> over a closed surface enclosing the assembly [48-52,63]. Conservation of linear and angular momentum yields Fz = (nm I0 / c) [sigma_ext - g_eff sigma_scat] and tau_z = tau_z,abs + tau_z,scat, where g_eff = <cos theta> is the scattering asymmetry parameter (distinct from the chiroptical Kuhn dissymmetry factor g_CD).", is_first=True)
    
    # Section 3. Results
    add_h1(doc, "3. Results")
    add_h2(doc, "3.1 Chiroptical Response and Circular Dichroism Spectra")
    add_body(doc, "Under circularly polarized illumination, the LH enantiomer (phi = +30.0°) exhibits pronounced differential extinction, with LCP extinction peaking at sigma_ext^LCP = 14.55 x 10^3 nm^2 compared with sigma_ext^RCP = 11.25 x 10^3 nm^2 at lambda = 800.0 nm, while the planar achiral control exhibits an unpolarized baseline peak of 12.80 x 10^3 nm^2 [Fig. 2(a)]. The resulting extinction circular dichroism, CD = sigma_ext^LCP - sigma_ext^RCP, reaches a positive maximum of CD = +3.30 x 10^3 nm^2 at lambda = 800.0 nm [Fig. 2(b), left axis], while the RH enantiomer displays exact sign inversion (CD = -3.30 x 10^3 nm^2) and the planar control exhibits zero CD (|CD| < 10^-3 nm^2). Concurrently, the chiroptical Kuhn dissymmetry factor g_CD(lambda) peaks at g_CD = +0.28 [Fig. 2(b), right axis]. Microscopic multipolar interference relates this dissymmetry directly to electric and magnetic dipoles: g_CD(lambda) ~ 4 Im[p(lambda) · (m*(lambda)/v)] / (|p(lambda)|^2 + |m(lambda)/v|^2), where v = c/n_m, ensuring strict dimensional consistency.", is_first=True)
    add_figure(doc, os.path.join(repo_root, "figures/png/figure02_spectra.png"), "Fig. 2. Far-field chiroptical response and circular dichroism spectra in water. (a) Helicity-dependent extinction cross-section spectra sigma_ext(lambda) for the left-handed chiral ring (LH, phi = +30.0°) under LCP (sigma = +1, solid blue), RCP (sigma = -1, dashed red), and the planar achiral control (phi = 0.0°, dotted green), highlighting the resonant longitudinal peak at lambda = 800.0 nm. (b) Extinction circular dichroism CD(lambda) = sigma_ext^LCP - sigma_ext^RCP (purple curve, left axis) peaking at +3.30 x 10^3 nm^2, and the chiroptical Kuhn dissymmetry factor g_CD(lambda) = 2(sigma_ext^LCP - sigma_ext^RCP)/(sigma_ext^LCP + sigma_ext^RCP) (orange dashed curve, right axis) reaching g_CD = +0.28.")
    
    add_h2(doc, "3.2 Near-Field Intensity and Superchiral Hot Spots")
    add_body(doc, "Resonant LCP illumination at lambda = 800.0 nm generates intense electric near-field hot spots in the 18.5 nm gaps (gap centerline enhancement 142.5, peak boundary hotspot value 185.2 for LCP vs peak enhancement ~ 28.4 for RCP, below the planar achiral control baseline of ~ 35.0). Coherent overlap of non-collinear electric and magnetic near fields creates localized superchiral fields defined via C(r) = -0.5 eps0 omega Im[E*(r) · B(r)], reaching C/C0 ~ +68.2 (vacuum-normalized) and C/C_inc,water = (C/C0)/n_m ~ +51.1 (water-normalized, where C_inc,water = n_m C0 = 1.33 C0).", is_first=True)
    add_figure(doc, os.path.join(repo_root, "figures/png/figure03_chirality_maps.png"), "Fig. 3. Near-field electromagnetic intensity profiles and local optical chirality enhancement at the longitudinal plasmon resonance (lambda = 800.0 nm). (a) Transverse near-field electric field intensity enhancement across the 18.5 nm inter-rod nanogap coordinate under LCP (blue solid, gap centerline enhancement 142.5, peak boundary hotspot value 185.2), RCP (red dashed, peak enhancement ~ 28.4), and planar achiral control (green dotted, peak enhancement ~ 35.0). (b) Spectral dispersion of local optical chirality density enhancement C/C0 at the capacitive gap center under LCP (vacuum-normalized peak C/C0 ~ +68.2; water-normalized peak C/C_inc,water = (C/C0)/n_m ~ +51.1) and under RCP (reversed chiroptical sign C/C0 ~ -18.2).")
    
    add_h2(doc, "3.3 Multipolar Decomposition and Magnetic Dipole Activation")
    add_body(doc, "In the planar control (phi = 0°), the optical response is overwhelmingly electric-dipole dominated (PED ~ 92.5%, PMD < 0.8%), where D6h symmetry suppresses the ideal net out-of-plane magnetic-dipole component, leaving only a numerically negligible residual contribution (PMD < 0.8%, PMD/PED < 0.05). Imparting the twist phi = +30° drives a circulating loop current, activating a powerful magnetic dipole mode at lambda = 800.0 nm. Authoritative spherical multipolar decomposition reveals: ED = 60.3%, MD = 28.5%, EQ = 7.8%, and magnetic quadrupole MQ = 3.4% (summing to 100.0%, PMD/PED ~ 0.472). The Cartesian decomposition further resolves the spherical ED channel into electric-dipole (51.4%) and toroidal-dipole (8.9%) contributions.", is_first=True)
    add_figure(doc, os.path.join(repo_root, "figures/png/figure04_multipoles.png"), "Fig. 4. Multipolar decomposition of scattered electromagnetic power. (a) Planar achiral control showing ED dominance. (b) Chiral assembly showing activation of magnetic dipole (MD) mode. (c) Multipolar fractional power contributions at 800 nm, displaying electric dipole (ED, 60.3%), magnetic dipole (MD, 28.5%), electric quadrupole (EQ, 7.8%), and magnetic quadrupole (MQ, 3.4%). (d) Polarization-resolved multipolar spectra under LCP and RCP.")
    add_csv_table(doc, os.path.join(repo_root, "tables/csv/table04_multipoles.csv"), "Spherical multipolar decomposition fractions, mode ratios, relative phases, and directional scattering metrics at key resonance wavelengths.", 4)
    
    add_h2(doc, "3.4 Multipolar Interference Mechanism and Near-Kerker Forward Scattering")
    add_body(doc, "Under LCP illumination at lambda = 800.0 nm, the relative phase between ED and MD moments drops to Delta_phi = phi_E - phi_M ~ 14.2° with amplitude ratio |m|/(c|p|) ~ 0.687, approaching a generalized first Kerker-like forward scattering condition. Within the dipolar sector, on-axis constructive interference yields |a_1 + b_1|^2 ~ 2.80 and destructive backward cancellation yields |a_1 - b_1|^2 ~ 0.14 (dipolar forward-to-backward directivity ratio 20:1, corresponding to 95.0% dipolar backward suppression). When integrating the complete far-field Poynting flux across all multipolar orders and the full spherical angular domain, the forward scattering efficiency reaches eta_fwd = Pfwd/Pscat ~ 0.731 (73.1%) and the scattering asymmetry parameter reaches geff ~ +0.462 (physically distinct from the chiroptical Kuhn dissymmetry factor g_CD ~ +0.28). Under RCP, Delta_phi ~ 98.6° (quadrature), disabling backward cancellation (eta_fwd ~ 0.492, geff ~ +0.124). Modal symmetry analysis confirms that helicity-dependent geometric phase matching across the chiral eigenmode spectrum causally locks Delta_phi.", is_first=True)
    add_figure(doc, os.path.join(repo_root, "figures/png/figure05_interference.png"), "Fig. 5. Multipolar interference mechanism and near-Kerker forward scattering condition. (a) Amplitude ratio |m|/(c|p|) and relative phase Delta_phi. (b) Forward scattering efficiency eta_fwd and scattering asymmetry parameter g_eff = <cos theta> = +0.462 (physically distinct from the chiroptical Kuhn dissymmetry factor g_CD = +0.28). (c) Differential scattering directivity. (d) Polar radiation patterns at 800 nm.")
    
    add_h2(doc, "3.5 Helicity-Dependent Optical Force and Radiation-Pressure Suppression")
    add_body(doc, "Under LCP illumination, the longitudinal optical force exhibits a pronounced dip at resonance, plunging to Fz ~ +58.3 fN (FDTD) / +56.9 fN (CDA). Under RCP, forward scattering recoil is absent, yielding Fz ~ +116.8 fN, resulting in a radiation force dichroism Delta_Fz ~ -58.5 fN (representing a 50.1% helicity-dependent force contrast; compared with Fz^achiral = +48.2 fN for the planar achiral control). Net force remains strictly positive (Fz > 0), demonstrating radiation-pressure modulation rather than plane-wave pulling.", is_first=True)
    add_figure(doc, os.path.join(repo_root, "figures/png/figure06_optical_force.png"), "Fig. 6. Helicity-dependent optical force and radiation-pressure modulation. (a) Longitudinal optical force spectra Fz(lambda) under LCP (FDTD: dip to +58.3 fN at lambda = 800 nm; CDA: +56.9 fN), RCP (+116.8 fN), and planar achiral control (+48.2 fN). (b) Optomechanical force contrast Delta_Fz (peak dichroism Delta_Fz ~ -58.5 fN). Quantitative agreement with far-field momentum conservation (<1.1% discrepancy) and transverse force cancellation (|Fx,y| < 0.04 fN) are detailed in Table 6.")
    add_csv_table(doc, os.path.join(repo_root, "tables/csv/table06_force_torque.csv"), "Summary of optical radiation force Fz and torque decomposition components at lambda = 800 nm.", 6)
    
    add_h2(doc, "3.6 Helicity-Controlled Optical Torque and Angular-Momentum Decomposition")
    add_body(doc, "Axial optical torque reaches tau_z ~ +36.20 zN·m under LCP and -25.00 zN·m under RCP (Delta_tau_z = +61.20 zN·m), representing an approximately 19-fold enhancement relative to the planar achiral baseline (±1.92 zN·m). Decomposing the torque into spin absorption and chiral scattering components reveals: under LCP (sigma = +1), tau_z,abs = +2.37 zN·m and tau_z,scat = +33.83 zN·m, summing to tau_z^LCP = +36.20 zN·m (dominated by chiral scattering, accounting for 93.5% [33.83/36.20] of total LCP torque and 92.3% [56.46/61.20] of the net helicity-dependent torque contrast Delta_tau_z; scattering dominates as sigma_sca >> sigma_abs, while spin absorption reverses sign from +2.37 to -2.37 zN*m contributing +4.74 zN*m or 7.7% to contrast); under RCP (sigma = -1), spin absorption reverses to tau_z,abs = -2.37 zN·m and scattering torque evaluates to tau_z,scat = -22.63 zN·m, exactly summing to tau_z^RCP = -25.00 zN·m (Table 6). In an aqueous environment, this torque overcomes Brownian rotational diffusion (rotational Peclet number Pe_rot ~ 8.81), yielding a steady-state rotation rate of Omega_z ~ 3.02 rad/s (hydrodynamic screening range ~ 2.3-3.0 rad/s).", is_first=True)
    add_figure(doc, os.path.join(repo_root, "figures/png/figure07_optical_torque.png"), "Fig. 7. Helicity-dependent optical torque and mechanical angular-momentum transfer. (a) Axial torque tau_z(lambda) under LCP and RCP. (b) Decomposition into spin absorption tau_z,abs and chiral scattering torque tau_z,scat. (c) Differential torque Delta_tau_z. (d) Comparison with planar achiral control.")
    
    add_h2(doc, "3.7 Far-Field Angular Momentum Flux Conservation and Angular-Momentum Redistribution")
    add_body(doc, "To place the torque mechanism on a strict conservation foundation, far-field angular momentum flux integration confirms <tau> + J_dot_scat = J_dot_ext. The scattered radiation carries negative outgoing angular momentum flux to the far field (J_dot_z,scat = -33.51 zN·m), imparting an equal and opposite positive mechanical recoil torque on the nanostructure (tau_z,scat^flux = -J_dot_z,scat = +33.51 zN·m) by action-reaction, in close agreement with the near-field MST remainder (+33.83 zN·m) within 0.95%. Total torque (tau_z = +36.20 zN·m under LCP, -25.00 zN·m under RCP) satisfies global angular-momentum conservation with a closure residual error below 1.09%, confirming that helicity-dependent redistribution of electromagnetic angular momentum into scattered radiation is the dominant physical origin of the observed torque.", is_first=True)
    
    add_h2(doc, "3.8 Parametric Scaling with Structural Twist Angle")
    add_body(doc, "Varying structural twist angle phi from 0° to 60° shows quadratic scaling for small angles, identifying phi ~ 30°-35° as the optimum within the investigated geometry range where magnetic dipole fraction, CD, force dichroism, and torque all achieve their maximum responses.", is_first=True)
    add_figure(doc, os.path.join(repo_root, "figures/png/figure08_correlation_twist.png"), "Fig. 8. Continuous parametric scaling with structural twist angle phi in [0°, 60°] at lambda = 800 nm. (a) Peak circular dichroism and optical torque. (b) Multipolar ratio PMD/PED and interpolar phase Delta_phi. (c) Near-Kerker forward scattering ratio and asymmetry parameter geff. (d) Radiation force and force dichroism Delta_Fz.")
    
    # Section 4. Discussion
    add_h1(doc, "4. Discussion")
    add_h2(doc, "4.1 Cross-Validation Across FDTD, CDA, and BEM")
    add_body(doc, "Cross-validation across 301 spectral points shows close agreement across FDTD, CDA, and BEM: resonance wavelength agrees within 0.26%, extinction within 1.44%, CD within 1.82%, force within 2.40%, and torque within 3.04%. Systematic BEM mesh refinement (300 to 1600 elements/rod) confirms sub-0.4% numerical convergence at the 1280 elements/rod standard, establishing internal numerical precision distinct from cross-solver electrodynamic agreement (within 3.04% across all mechanical observables).", is_first=True)
    add_figure(doc, os.path.join(repo_root, "figures/png/figure09_cross_validation.png"), "Fig. 9. Quantitative cross-validation of the electrodynamic response using FDTD, CDA, and MNPBEM. (a) Extinction cross-section spectra. (b) Magnetic-to-electric dipole power ratio PMD/PED. (c) Longitudinal optical force. (d) Axial optical torque. The three methods show close agreement over the 500–1100 nm spectral range, bounded below 3.04% across the principal physical observables reported in Table 5.")
    add_csv_table(doc, os.path.join(repo_root, "tables/csv/table05_validation.csv"), "Quantitative cross-validation of optical response, force, and torque across FDTD, CDA, and BEM solvers at lambda = 800 nm.", 5)
    
    add_h2(doc, "4.2 Structural Disorder and Monte Carlo Tolerance Analysis")
    add_body(doc, "Monte Carlo simulations across N = 500 independent realizations generated via a deterministic PRNG (seed 42) evaluate individual sensitivities from independent Gaussian distributions: positional disorder alone (sigma_r = 2.0 nm: lambda_res = 800.3 ± 1.8 nm, tau_z = 36.0 ± 1.1 zN·m), angular disorder alone (sigma_theta = 3.0°: lambda_res = 800.6 ± 2.4 nm, tau_z = 35.9 ± 1.5 zN·m), and dimensional polydispersity alone (sigma_L = 3.0 nm, sigma_d = 1.5 nm: lambda_res = 801.1 ± 3.1 nm, tau_z = 35.7 ± 1.7 zN·m). Under combined disorder, all 500 simulated configurations retain positive optical torque (mean tau_z = +35.8 ± 2.1 zN·m, minimum torque +30.8 zN·m, 95% empirical realization interval [31.9, 40.1] zN·m, parametric mu +- 1.96*sigma = [31.7, 39.9] zN·m, 95% confidence interval for the mean [35.62, 35.98] zN·m, lambda_res = 801.4 ± 4.2 nm), with full per-run coordinates archived in the repository.", is_first=True)
    add_figure(doc, os.path.join(repo_root, "figures/png/figure10_disorder_robustness.png"), "Fig. 10. Monte Carlo tolerance analysis across 500 stochastic disorder configurations. (a) Schematic of perturbations. (b) Probability distributions for resonance wavelength. (c) Distributions for CD and force dichroism. (d) Distribution for axial optical torque, confirming all simulated realizations maintain positive torque.")
    add_csv_table(doc, os.path.join(repo_root, "tables/csv/table07_disorder.csv"), "Monte Carlo tolerance analysis across individual and combined structural disorder mechanisms (N = 500 independent realizations).", 7)
    
    add_h2(doc, "4.3 Numerical Convergence and Stress-Tensor Invariance")
    add_body(doc, "Further refining the grid from 0.50 nm to 0.25 nm changes the longitudinal force by 0.8% and the optical torque by 0.5% at the primary 800 nm resonance. Across the tested wavelengths, the maximum deviations are 0.8% for force and 1.1% for torque. We therefore selected Delta_x = 0.50 nm as the validated baseline mesh. Evaluating the closed-surface Maxwell stress tensor integral over box separation distances ranging from 10 to 30 nm confirms that surface-placement variation remains below 1.8%. Combining grid discretization, CPML reflections, and surface placement gives a total root-sum-square numerical uncertainty of approximately 2.11% (2.14% using conservative bounds; Section S20), with the 1.09% far-field momentum-balance closure discrepancy serving as an independent cross-validation residual.", is_first=True)
    add_figure(doc, os.path.join(repo_root, "figures/png/figure11_convergence.png"), "Fig. 11. Systematic numerical convergence analysis. (a) FDTD mesh refinement (1.0 nm to 0.25 nm). (b) CPML boundary layers. (c) Temporal field energy decay. (d) Maxwell stress tensor integration box distance invariance.")
    
    add_h2(doc, "4.4 Proposed Experimental Realization Pathway")
    add_body(doc, "The proposed geometry could potentially be realized using DNA-origami-directed positioning strategies, where tubular or polygonal DNA origami bundles serve as rigid scaffolds, although experimental fabrication and mechanical characterization remain beyond the scope of the present numerical study. Thermal and hydrodynamic dissipation are not explicitly modeled here and require separate coupled thermo-optical and fluid-mechanical treatment. To provide an idealized hydrodynamic upper-bound estimate of the mechanical response in an optical trap, balancing the peak optical torque tau_z = 36.2 zN·m against bulk Stokes rotational drag [gamma_rot = 8*pi*eta*Rh^3 ~ 1.20 x 10^-20 N·m·s, for an equivalent hydrodynamic radius Rh ~ 78 nm in water (eta = 1.0 x 10^-3 Pa·s)] yields an idealized terminal angular velocity estimate of Omega_z = tau_z / gamma_rot ~ 3.02 rad/s (~28.8 rpm, rotational Peclet number Pe_rot ~ 8.81 > 1). We explicitly emphasize that this value represents an idealized hydrodynamic model estimate for an unconfined rotor in bulk fluid; in physical experiments, hydrodynamic boundary proximity, tether compliance, trap restoring torques, and local viscosity variations will substantially modify observable rotation rates, and a full rotational Brownian-dynamics treatment remains beyond the scope of the present electrodynamic study.", is_first=True)
    add_figure(doc, os.path.join(repo_root, "figures/png/figure12_experimental_scheme.png"), "Fig. 12. Proposed experimental realization and measurement pathway. (a) DNA-origami directed assembly. (b) CD extinction spectroscopy. (c) Optical trapping and quadrant-photodiode rotational tracking setup.")
    
    add_h2(doc, "4.5 Comparison with Literature and Novelty Benchmark")
    add_body(doc, "Table 8 benchmarks this work against 15 published studies [10,15,17,19,31,32,33,34,39,40,41,43,73,74,75,76,79]. We did not identify prior studies combining comparable three-method electrodynamic validation with a 500-sample structural-disorder analysis of chiral plasmonic optomechanics.", is_first=True)
    add_csv_table(doc, os.path.join(repo_root, "tables/csv/table08_literature.csv"), "Comparison of reported physical mechanisms and validation approaches with published chiral nanophotonics and optomechanical literature.", 8)
    
    # Section 5. Conclusions
    add_h1(doc, "5. Conclusions")
    add_body(doc, "In this study, we have formulated and computationally verified an electrodynamic mechanism linking three-dimensional structural chirality to multipolar interference and electromagnetic momentum and angular-momentum transfer in plasmonic oligomeric rings. By breaking planar mirror symmetry through a coordinated structural twist (D6h -> C6), the structure activates an out-of-plane magnetic dipole mode (PMD/PED ~ 0.472) at the longitudinal plasmon resonance (lambda = 800 nm). Incident optical helicity selectively aligns the multipolar phase difference to Delta_phi ~ 14.2°, approaching a generalized first Kerker-like forward-scattering regime (eta_fwd ~ 0.731, geff ~ +0.462) that suppresses forward radiation pressure down to Fz ~ +58.3 fN (yielding a 50.1% helicity-dependent force contrast; Delta_Fz ~ -58.5 fN; compared with Fz^achiral = +48.2 fN for the planar control). Concurrently, chiral scattering redirects photon spin into orbital angular momentum, amplifying axial torque to tau_z ~ +36.2 zN·m under LCP (an approximately 19-fold enhancement over the achiral baseline), verified by far-field angular momentum flux conservation within < 1.09% closure discrepancy. Rigorous cross-validation across FDTD, CDA, and BEM (discrepancy < 3.2%) and 500-sample Monte Carlo disorder simulations confirm that all simulated configurations retain positive optical torque (tau_z = 35.8 ± 2.1 zN·m, minimum +30.8 zN·m) with verified robustness to the specified 500-sample numerical disorder ensemble. These results establish a geometry-controlled design principle that may be generalized to other chiral plasmonic oligomers for light-driven rotary nanomotors and optofluidic manipulation platforms.", is_first=True)
    
    # Appendices A to E
    add_h1(doc, "Appendix A: Coordinate Transformation Matrices and Euler Rotations")
    add_body(doc, "Complete transformation matrices mapping local nanorod coordinates to global laboratory frame via Rodrigues' rotation formula around the local radial unit vector.", is_first=True)
    
    add_h1(doc, "Appendix B: Analytical Decomposition of the Dyadic Green's Function")
    add_body(doc, "Partitioning of the Helmholtz dyadic Green's tensor into near-field (R^-3), intermediate induction (R^-2), and radiative far-field (R^-1) zones governing inter-rod capacitive coupling and long-range phase retardation.", is_first=True)

    add_h1(doc, "Appendix C: Vector Spherical Wave Functions and Kerker Scattering Directivity")
    add_body(doc, "Projection onto Vector Spherical Wave Functions (VSWFs) and exact proof of backward scattering cancellation under the generalized first Kerker condition.", is_first=True)

    add_h1(doc, "Appendix D: Maxwell Stress Tensor Momentum Budget and Angular Momentum Flux")
    add_body(doc, "Proof of equivalence between closed-surface Maxwell stress tensor integrals and far-field momentum conservation cross-section budgets.", is_first=True)

    add_h1(doc, "Appendix E: Optical Chirality Density Formulation and Normalization")
    add_body(doc, "Formulation and media-dependent normalization of the Lipkin-Tang-Cohen optical chirality density and decomposition into electric and magnetic polarization ellipticities.", is_first=True)

    # Optica Official End-Matter
    doc.add_paragraph("Funding", style='20. Funding Section Header')
    p_fund = doc.add_paragraph("This research did not receive any specific grant from funding agencies in the public, commercial, or not-for-profit sectors.", style='09. Body First Paragraph')
    p_fund.paragraph_format.space_after = Pt(6)

    doc.add_paragraph("Acknowledgments", style='21. Acknowledgments Section Header')
    p_ack = doc.add_paragraph("P. acknowledges doctoral fellowship support from the University of Delhi. R.S. acknowledges research infrastructure support from the School of Technology, Woxsen University.", style='09. Body First Paragraph')
    p_ack.paragraph_format.space_after = Pt(6)

    doc.add_paragraph("Disclosures", style='22. Disclosures Section Header')
    p_disc = doc.add_paragraph("The authors declare no conflicts of interest.", style='09. Body First Paragraph')
    p_disc.paragraph_format.space_after = Pt(6)

    doc.add_paragraph("Data Availability", style='23. Data Availability Section Header')
    p_data = doc.add_paragraph("The complete dataset, 3D CAD models, simulation input scripts (FDTD, MNPBEM, CDA), and the canonical 500-run Monte Carlo disorder ensemble supporting this study are permanently accessible in the project GitHub repository at https://github.com/priyanka292c/josab-chiral-plasmonic-optomechanics.", style='09. Body First Paragraph')
    p_data.paragraph_format.space_after = Pt(6)

    doc.add_paragraph("Supplemental Document", style='24. Supplemental Document Section')
    p_supp = doc.add_paragraph("See Supplement 1 for supporting content.", style='09. Body First Paragraph')
    p_supp.paragraph_format.space_after = Pt(6)

    # AI Declaration
    add_h2(doc, "Declaration on the Use of Artificial Intelligence and Author Consent")
    p_ai = doc.add_paragraph("During the preparation of this manuscript, the authors used AI-assisted technologies (specifically large language model interfaces) solely for language editing, stylistic refinement, reference metadata consistency checks, and formatting script assistance under direct author supervision. Both authors formulated the scientific hypotheses, performed and cross-validated all theoretical electrodynamic derivations and computational simulations (FDTD, CDA, MNPBEM, and Maxwell stress tensor integrations), designed and verified all figures and tables, and critically analyzed all scientific findings. Following the use of these tools, both authors thoroughly reviewed, verified, edited the manuscript content, and provide full author consent, taking complete and sole responsibility for the accuracy, integrity, and original contributions of the published work in accordance with Optica Publishing Group author guidelines.", style='09. Body First Paragraph')
    p_ai.paragraph_format.space_after = Pt(10)

    # References
    doc.add_paragraph("References", style='25. Reference Section Header')
    
    # Load reference master for DOIs
    ref_master = {}
    master_csv_path = os.path.join(repo_root, 'references/verified_references.csv')
    if os.path.exists(master_csv_path):
        with open(master_csv_path, 'r', encoding='utf-8') as f:
            for r in csv.DictReader(f):
                ref_master[r['Bib_Key']] = r

    bbl_path = os.path.join(repo_root, 'manuscript/manuscript.bbl')
    if os.path.exists(bbl_path):
        with open(bbl_path, 'r', encoding='utf-8') as f:
            bbl_text = f.read()
        items = re.findall(r'\\bibitem\{([^}]+)\}(.*?)(?=\\bibitem\{|\\end\{thebibliography\}|$)', bbl_text, flags=re.DOTALL)
        for idx, (key, btext) in enumerate(items, 1):
            doi_val = ref_master.get(key, {}).get('DOI', '').strip()
            if 'N/A' in doi_val or not doi_val.startswith('10.'):
                doi_val = ''
            
            # Clean LaTeX markup from body
            clean = btext.replace('\n', ' ')
            clean = re.sub(r'\\enquote\{([^}]+)\}', r'"\1"', clean)
            clean = re.sub(r'\{\\protect\\JournalTitle\{([^}]+)\}\}', r'\1', clean)
            clean = re.sub(r'\\JournalTitle\{([^}]+)\}', r'\1', clean)
            clean = re.sub(r'\\emph\{([^}]+)\}', r'\1', clean)
            clean = re.sub(r'\\textbf\{([^}]+)\}', r'\1', clean)
            clean = re.sub(r'\\urlprefix\\url\{[^}]+\}', '', clean)
            clean = re.sub(r'\\urlprefix', '', clean)
            clean = re.sub(r'\\url\{[^}]+\}', '', clean)
            clean = re.sub(r'\\newblock', '', clean)
            clean = re.sub(r'\{\\em\s*(.*?)\\/\}', r'\1', clean)
            clean = re.sub(r'\\em\s*', '', clean)
            clean = re.sub(r'\\/', '', clean)
            clean = re.sub(r'\\&', '&', clean)
            clean = clean.replace('~', ' ')
            clean = re.sub(r'--+', '–', clean)
            clean = re.sub(r'\{|\}', '', clean)
            clean = re.sub(r'\s+', ' ', clean).strip()
            
            p_ref = doc.add_paragraph(style='26. References' if '26. References' in [s.name for s in doc.styles] else 'Normal')
            p_ref.paragraph_format.space_before = Pt(1)
            p_ref.paragraph_format.space_after = Pt(3)
            p_ref.paragraph_format.left_indent = Inches(0.25)
            p_ref.paragraph_format.first_line_indent = Inches(-0.25)
            
            r_num = p_ref.add_run(f"{idx}. ")
            r_num.font.name = 'Times New Roman'
            r_num.font.size = Pt(9.5)
            r_num.font.bold = True
            
            r_body = p_ref.add_run(clean + " ")
            r_body.font.name = 'Times New Roman'
            r_body.font.size = Pt(9.5)
            
            if doi_val:
                r_doi = p_ref.add_run(f"https://doi.org/{doi_val}")
                r_doi.font.name = 'Times New Roman'
                r_doi.font.size = Pt(9.5)
                r_doi.font.underline = True
                r_doi.font.color.rgb = RGBColor(0, 51, 153) # Link Blue
    
    # Save outputs to both root and manuscript directories
    targets = [
        os.path.join(repo_root, 'main.docx'),
        os.path.join(repo_root, 'manuscript', 'main.docx'),
        os.path.join(repo_root, 'manuscript', 'manuscript.docx'),
    ]
    for target in targets:
        os.makedirs(os.path.dirname(target), exist_ok=True)
        doc.save(target)
        print(f"Word document saved: {target}")

if __name__ == '__main__':
    main()
