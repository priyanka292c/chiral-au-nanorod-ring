"""
Build and verify exactly 10-page main manuscript PDF for JOSA B.
Uses pypdf to inspect physical page count and extracted text.
"""

import subprocess
import os
import sys

def compile_pdf(cwd):
    pdflatex = r"C:\Users\priya\AppData\Local\Programs\MiKTeX\miktex\bin\x64\pdflatex.exe"
    bibtex = r"C:\Users\priya\AppData\Local\Programs\MiKTeX\miktex\bin\x64\bibtex.exe"
    
    if not os.path.exists(pdflatex):
        pdflatex = "pdflatex"
        bibtex = "bibtex"

    print("Running pdflatex pass 1...")
    subprocess.run([pdflatex, "-interaction=nonstopmode", "--miktex-disable-installer", "manuscript.tex"], cwd=cwd, check=True, stdout=subprocess.DEVNULL)
    
    print("Running bibtex...")
    subprocess.run([bibtex, "manuscript"], cwd=cwd, stdout=subprocess.DEVNULL)
    
    print("Running pdflatex pass 2...")
    subprocess.run([pdflatex, "-interaction=nonstopmode", "--miktex-disable-installer", "manuscript.tex"], cwd=cwd, check=True, stdout=subprocess.DEVNULL)
    
    print("Running pdflatex pass 3 (finalizing cross-references)...")
    subprocess.run([pdflatex, "-interaction=nonstopmode", "--miktex-disable-installer", "manuscript.tex"], cwd=cwd, check=True, stdout=subprocess.DEVNULL)

def check_pages(pdf_path):
    import pypdf
    reader = pypdf.PdfReader(pdf_path)
    num_pages = len(reader.pages)
    print(f"\n=======================================================")
    print(f"MAIN PDF PAGE COUNT AUDIT")
    print(f"File: {pdf_path}")
    print(f"Actual Page Count: {num_pages}")
    print(f"Expected Target:   10")
    print(f"=======================================================")
    
    for i, page in enumerate(reader.pages, 1):
        text = page.extract_text()
        first_line = text.split("\n")[0] if text else "EMPTY"
        char_count = len(text)
        print(f"Page {i:02d}: {char_count:4d} chars | Starts: {first_line[:60]}")

    return num_pages

if __name__ == "__main__":
    cwd = r"d:\Reasearch work\PNFA_Chiral_Au_Nanorod_Ring\revised_project\manuscript"
    pdf_path = os.path.join(cwd, "manuscript.pdf")
    
    compile_pdf(cwd)
    pages = check_pages(pdf_path)
    
    if pages == 10:
        print("\nSUCCESS: Manuscript is EXACTLY 10 PAGES!")
        sys.exit(0)
    else:
        print(f"\nATTENTION: Manuscript has {pages} pages (target: 10). Adjustments required.")
        sys.exit(pages)
