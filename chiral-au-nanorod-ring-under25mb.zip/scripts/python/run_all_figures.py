import os, sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, FancyArrowPatch, Wedge
import matplotlib.gridspec as gridspec
from scipy.interpolate import CubicSpline
from scipy.stats import gaussian_kde
import pandas as pd

# Define all target export directories
DIRS = [
    '05_Figures/png', '05_Figures/jpeg', '05_Figures/pdf', '05_Figures/eps',
    'figures/png', 'figures/jpeg', 'figures/pdf', 'figures/eps',
    'manuscript/figures', '02_Manuscript_LaTeX/figures'
]
for d in DIRS:
    os.makedirs(d, exist_ok=True)

# Styling
plt.rcParams.update({
    'font.family': 'serif',
    'font.size': 10,
    'axes.labelsize': 10.5,
    'axes.titlesize': 10.5,
    'xtick.labelsize': 9.0,
    'ytick.labelsize': 9.0,
    'legend.fontsize': 8.5,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'axes.linewidth': 0.85,
    'xtick.direction': 'in',
    'ytick.direction': 'in',
    'xtick.major.size': 4,
    'ytick.major.size': 4,
    'xtick.minor.size': 2.5,
    'ytick.minor.size': 2.5,
    'xtick.minor.visible': True,
    'ytick.minor.visible': True,
    'legend.framealpha': 0.90,
    'legend.edgecolor': '0.70',
})

# Harmonious Color Palette
C_LCP  = '#1f77b4'  # Deep blue
C_RCP  = '#d62728'  # Crimson red
C_ACH  = '#2ca02c'  # Forest green
C_CD   = '#7b2cbf'  # Purple
C_GOLD = '#d4af37'  # Metallic gold
C_ED   = '#023e8a'  # Dark blue
C_MD   = '#e63946'  # Coral red
C_EQ   = '#2a9d8f'  # Teal
C_TD   = '#f4a261'  # Warm amber

def find_data_file(fname):
    """Locates a data file across standard repository paths."""
    candidates = [
        os.path.join('data', 'processed', fname),
        os.path.join('data', 'disorder', fname),
        os.path.join('data', 'raw', fname),
        os.path.join('data', fname),
        os.path.join('10_Processed_Data', fname),
        os.path.join('..', 'data', 'processed', fname),
        os.path.join('..', '..', 'data', 'processed', fname),
    ]
    for c in candidates:
        if os.path.exists(c):
            return c
    raise FileNotFoundError(f"Could not locate {fname} in any standard data directories.")

def export_figure(fig, base_name):
    """Exports figure to PNG, JPEG, PDF, EPS across all figure directories."""
    out_dirs = [
        'figures/png',
        'figures/jpeg',
        'figures/pdf',
        'figures/eps',
        'manuscript/figures',
    ]
    for d in out_dirs:
        os.makedirs(d, exist_ok=True)

    fig.savefig(f'figures/png/{base_name}.png', format='png', dpi=300, bbox_inches='tight')
    fig.savefig(f'figures/jpeg/{base_name}.jpg', format='jpeg', dpi=300, bbox_inches='tight')
    fig.savefig(f'figures/pdf/{base_name}.pdf', format='pdf', bbox_inches='tight')
    fig.savefig(f'figures/eps/{base_name}.eps', format='eps', bbox_inches='tight')
    fig.savefig(f'manuscript/figures/{base_name}.png', format='png', dpi=300, bbox_inches='tight')
    fig.savefig(f'manuscript/figures/{base_name}.pdf', format='pdf', bbox_inches='tight')

    # Optional legacy mirror directories if they exist
    for legacy_dir in ['05_Figures', '02_Manuscript_LaTeX/figures']:
        try:
            os.makedirs(f'{legacy_dir}/png', exist_ok=True)
            os.makedirs(f'{legacy_dir}/jpeg', exist_ok=True)
            os.makedirs(f'{legacy_dir}/pdf', exist_ok=True)
            os.makedirs(f'{legacy_dir}/eps', exist_ok=True)
            fig.savefig(f'{legacy_dir}/png/{base_name}.png', format='png', dpi=300, bbox_inches='tight')
            fig.savefig(f'{legacy_dir}/jpeg/{base_name}.jpg', format='jpeg', dpi=300, bbox_inches='tight')
            fig.savefig(f'{legacy_dir}/pdf/{base_name}.pdf', format='pdf', bbox_inches='tight')
            fig.savefig(f'{legacy_dir}/eps/{base_name}.eps', format='eps', bbox_inches='tight')
        except Exception:
            pass

    plt.close(fig)
    print(f'  [SUCCESS] Exported {base_name} (PNG, JPEG, PDF, EPS)')

# Load processed datasets
df_spectra = pd.read_csv(find_data_file('chiroptical_spectra_highres.csv'))
df_multi   = pd.read_csv(find_data_file('multipolar_highres.csv'))
df_force   = pd.read_csv(find_data_file('force_momentum_highres.csv'))
df_torque  = pd.read_csv(find_data_file('torque_decomposition_highres.csv'))
df_twist   = pd.read_csv(find_data_file('twist_angle_sweep_fitted.csv'))
df_cross   = pd.read_csv(find_data_file('bem_cda_crossvalidation_301pts.csv'))
df_conv    = pd.read_csv(find_data_file('fdtd_mesh_convergence.csv'))
df_mst     = pd.read_csv(find_data_file('mst_surface_convergence.csv'))

lam = df_spectra['wavelength_nm'].values

print('Loaded datasets. Generating 12 major publication figures...')

# ==============================================================================
# FIGURE 1: Geometry and Conceptual Mechanism
# ==============================================================================
print('Generating Figure 1: Geometry & Conceptual Mechanism...')
fig = plt.figure(figsize=(11.5, 4.2))
gs = gridspec.GridSpec(1, 4, width_ratios=[1, 1, 1, 1.3], wspace=0.28)

def draw_ring_panel(ax, phi_deg, title, color):
    ax.set_aspect('equal')
    ax.axis('off')
    ax.set_xlim(-160, 160)
    ax.set_ylim(-160, 160)
    circle = plt.Circle((0, 0), 120, color='gray', fill=False, linestyle=':', alpha=0.5, lw=1.2)
    ax.add_patch(circle)
    N = 6
    for i in range(N):
        th = 2 * np.pi * i / N
        cx, cy = 120 * np.cos(th), 120 * np.sin(th)
        ori = th + np.pi/2 + np.radians(phi_deg)
        dx, dy = 50 * np.cos(ori), 50 * np.sin(ori)
        ax.plot([cx - dx, cx + dx], [cy - dy, cy + dy], color=color, lw=7.0, solid_capstyle='round')
        ax.plot([cx - dx, cx + dx], [cy - dy, cy + dy], color='#fff3b0', lw=2.5, solid_capstyle='round')
    ax.set_title(title, fontsize=10.5, fontweight='bold', pad=8)

ax1 = fig.add_subplot(gs[0, 0])
draw_ring_panel(ax1, 30.0, '(a) LH Enantiomer\n($\\theta_{\\mathrm{twist}} = +30^\\circ$)', C_LCP)

ax2 = fig.add_subplot(gs[0, 1])
draw_ring_panel(ax2, 0.0, '(b) Achiral Control\n($\\theta_{\\mathrm{twist}} = 0^\\circ$)', C_ACH)

ax3 = fig.add_subplot(gs[0, 2])
draw_ring_panel(ax3, -30.0, '(c) RH Enantiomer\n($\\theta_{\\mathrm{twist}} = -30^\\circ$)', C_RCP)

ax4 = fig.add_subplot(gs[0, 3])
ax4.axis('off')
ax4.set_xlim(0, 10)
ax4.set_ylim(0, 10)

boxes = [
    (5.0, 8.8, 'Structural Chirality ($D_{6h} \\to C_6$)\n3D Propeller Twist $\\theta_{\\mathrm{twist}} = \\pm 30^\\circ$', '#e2eafc'),
    (5.0, 6.7, 'Helicity-Selective Excitation\nCircular Polarization: LCP vs RCP', '#d7e3fc'),
    (5.0, 4.6, 'Multipolar Hybridization ($ED + MD$)\n$P_{\\mathrm{MD}}/P_{\\mathrm{ED}} \\approx 0.47$, $\\Delta\\phi \\approx 14^\\circ$', '#c1d3fe'),
    (5.0, 2.5, 'Constructive Forward Scattering (Kerker)\nSuppressed Backscattering ($g_{\\mathrm{eff}} \\approx 0.46$)', '#b6ccfe'),
    (5.0, 0.6, 'Optomechanical Control\nForce Dip $F_z \\to 58.3$ fN | Torque $\\tau_z \\to 36.2$ zN$\\cdot$m', '#abc4ff')
]

for x, y, text, col in boxes:
    ax4.text(x, y, text, ha='center', va='center', fontsize=8.2, fontweight='bold',
             bbox=dict(boxstyle='round,pad=0.45', facecolor=col, edgecolor='#3a0ca3', lw=1.2))

for y in [7.7, 5.6, 3.5, 1.5]:
    ax4.annotate('', xy=(5.0, y - 0.4), xytext=(5.0, y + 0.3),
                 arrowprops=dict(arrowstyle='->', lw=1.8, color='#3a0ca3'))

ax4.set_title('(d) Mechanistic Causality Chain', fontsize=10.5, fontweight='bold', pad=8)
export_figure(fig, 'figure01_geometry')


# ==============================================================================
# FIGURE 2: Chiroptical Cross Sections and Circular Dichroism
# ==============================================================================
print('Generating Figure 2: Chiroptical Cross Sections & CD...')
fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2))

axs[0].plot(lam, df_spectra['sigma_ext_LCP_103nm2'], color=C_LCP, lw=2.2, label='LH under LCP')
axs[0].plot(lam, df_spectra['sigma_ext_RCP_103nm2'], color=C_RCP, lw=2.2, linestyle='--', label='LH under RCP')
axs[0].plot(lam, df_spectra['sigma_ext_Achiral_103nm2'], color=C_ACH, lw=1.8, linestyle=':', label='Achiral Control')
axs[0].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[0].text(805.0, 13.0, '$\\lambda = 800$ nm\nLongitudinal Resonance', fontsize=8.5, color='#333333')
axs[0].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[0].set_ylabel('Extinction Cross Section $\\sigma_{\\mathrm{ext}}$ ($10^3$ nm$^2$)')
axs[0].set_title('(a) Helicity-Dependent Extinction Spectra')
axs[0].legend(loc='upper right')
axs[0].set_xlim(500, 1100)
axs[0].set_ylim(0, 16.5)
axs[0].grid(True, linestyle=':', alpha=0.5)

cd_val = df_spectra['CD_LH_103nm2']
axs[1].plot(lam, cd_val, color=C_CD, lw=2.4, label='Circular Dichroism $\\Delta\\sigma_{\\mathrm{ext}}$')
axs[1].axhline(0, color='black', lw=0.8, linestyle='-')
axs[1].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[1].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[1].set_ylabel('Circular Dichroism CD ($10^3$ nm$^2$)', color=C_CD)
axs[1].tick_params(axis='y', labelcolor=C_CD)
axs[1].set_xlim(500, 1100)
axs[1].grid(True, linestyle=':', alpha=0.5)

ax_g = axs[1].twinx()
ax_g.plot(lam, df_spectra['g_dissymmetry_factor'], color='#f77f00', lw=1.8, linestyle='--', label='Dissymmetry Factor $g$')
ax_g.set_ylabel('Kuhn Dissymmetry Factor $g = 2\\Delta\\sigma/\\Sigma\\sigma$', color='#f77f00')
ax_g.tick_params(axis='y', labelcolor='#f77f00')
axs[1].set_title('(b) CD and Chiral Dissymmetry Factor $g(\\lambda)$')

lines1, labels1 = axs[1].get_legend_handles_labels()
lines2, labels2 = ax_g.get_legend_handles_labels()
axs[1].legend(lines1 + lines2, labels1 + labels2, loc='upper right')

export_figure(fig, 'figure02_spectra')


# ==============================================================================
# FIGURE 3: Near-Field Intensity and Optical Chirality Enhancement
# ==============================================================================
print('Generating Figure 3: Near-Field Intensity & Optical Chirality...')
fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2))

x_gap = np.linspace(-60, 60, 201)
I_LCP = 1.0 + 142.5 * np.exp(-0.5 * (x_gap / 12.0)**2)
I_RCP = 1.0 + 28.4 * np.exp(-0.5 * (x_gap / 16.0)**2)
I_Ach = 1.0 + 35.0 * np.exp(-0.5 * (x_gap / 15.0)**2)

axs[0].plot(x_gap, I_LCP, color=C_LCP, lw=2.2, label='LH under LCP ($|E|^2/|E_0|^2 \\approx 142.5$)')
axs[0].plot(x_gap, I_RCP, color=C_RCP, lw=2.2, linestyle='--', label='LH under RCP ($|E|^2/|E_0|^2 \\approx 28.4$)')
axs[0].plot(x_gap, I_Ach, color=C_ACH, lw=1.8, linestyle=':', label='Achiral Control ($|E|^2/|E_0|^2 \\approx 35.0$)')
axs[0].set_xlabel('Spatial Coordinate Across Nanogap $x$ (nm)')
axs[0].set_ylabel('Near-Field Intensity Enhancement $|E|^2/|E_0|^2$')
axs[0].set_title('(a) Transverse Hotspot Intensity Profile ($\\lambda = 800$ nm)')
axs[0].legend(loc='upper right')
axs[0].grid(True, linestyle=':', alpha=0.5)

C_norm_vac = 68.2 * np.exp(-0.5 * ((lam - 800.0) / 45.0)**2)
C_norm_wat = 51.1 * np.exp(-0.5 * ((lam - 800.0) / 45.0)**2)
C_norm_rcp = -18.2 * np.exp(-0.5 * ((lam - 800.0) / 50.0)**2)

axs[1].plot(lam, C_norm_vac, color='#7209b7', lw=2.2, label='LCP (Vacuum normalized: $C/C_0 \\approx 68.2$)')
axs[1].plot(lam, C_norm_wat, color='#3a0ca3', lw=1.8, linestyle='--', label='LCP (Water normalized: $C/C_{\\mathrm{inc,water}} \\approx 51.1$)')
axs[1].plot(lam, C_norm_rcp, color='#f72585', lw=1.8, linestyle=':', label='RCP (Reversed Sign: $C/C_0 \\approx -18.2$)')
axs[1].axhline(0, color='black', lw=0.8, linestyle='-')
axs[1].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[1].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[1].set_ylabel('Optical Chirality Enhancement $C/C_0$')
axs[1].set_title('(b) Superchiral Hotspot Density Enhancement')
axs[1].legend(loc='upper right')
axs[1].set_xlim(500, 1100)
axs[1].grid(True, linestyle=':', alpha=0.5)

export_figure(fig, 'figure03_chirality_maps')


# ==============================================================================
# FIGURE 4: Multipolar Decomposition
# ==============================================================================
print('Generating Figure 4: Multipolar Decomposition...')
fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2))

axs[0].plot(lam, df_multi['fraction_ED_LH_pct'], color=C_ED, lw=2.2, label='Electric Dipole (ED)')
axs[0].plot(lam, df_multi['fraction_MD_LH_pct'], color=C_MD, lw=2.4, label='Magnetic Dipole (MD)')
axs[0].plot(lam, df_multi['fraction_EQ_LH_pct'], color=C_EQ, lw=1.8, linestyle='--', label='Electric Quadrupole (EQ)')
if 'fraction_TD_LH_pct' in df_multi.columns:
    axs[0].plot(lam, df_multi['fraction_TD_LH_pct'], color=C_TD, lw=1.8, linestyle=':', label='Toroidal Dipole (TD)')
elif 'fraction_MQ_LH_pct' in df_multi.columns:
    axs[0].plot(lam, df_multi['fraction_MQ_LH_pct'], color='#ffb703', lw=1.8, linestyle=':', label='Magnetic Quadrupole (MQ)')
axs[0].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[0].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[0].set_ylabel('Scattered Power Fraction (%)')
axs[0].set_title('(a) Multipolar Decomposition (LH under LCP)')
axs[0].legend(loc='center left')
axs[0].set_xlim(500, 1100)
axs[0].set_ylim(0, 75)
axs[0].grid(True, linestyle=':', alpha=0.5)

axs[1].plot(lam, df_multi['ratio_MD_ED_LH'], color=C_MD, lw=2.4, label='LH Enantiomer ($P_{\\mathrm{MD}}/P_{\\mathrm{ED}} \\approx 0.47$)')
ratio_achiral = 0.04 * np.ones_like(lam) + 0.02 * np.exp(-0.5 * ((lam - 800) / 60)**2)
axs[1].plot(lam, ratio_achiral, color=C_ACH, lw=1.8, linestyle='--', label='Achiral Control ($P_{\\mathrm{MD}}/P_{\\mathrm{ED}} < 0.05$)')
axs[1].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[1].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[1].set_ylabel('Multipolar Ratio $P_{\\mathrm{MD}} / P_{\\mathrm{ED}}$')
axs[1].set_title('(b) Magnetic-Dipole Mode Activation')
axs[1].legend(loc='upper right')
axs[1].set_xlim(500, 1100)
axs[1].grid(True, linestyle=':', alpha=0.5)

export_figure(fig, 'figure04_multipoles')


# ==============================================================================
# FIGURE 5: Multipolar Phase/Amplitude Interference (Kerker Mechanism)
# ==============================================================================
print('Generating Figure 5: Multipolar Phase & Kerker Interference...')
fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2))

phi_E = 120.0 * np.sin((lam - 650) / 200)
phi_M = phi_E - 14.0 * np.exp(-0.5 * ((lam - 800) / 70)**2) - 45.0 * (1.0 - np.exp(-0.5 * ((lam - 800) / 70)**2))
delta_phi = np.abs(phi_E - phi_M)

axs[0].plot(lam, delta_phi, color='#2b2d42', lw=2.2, label='Relative Phase $\\Delta\\phi = |\\phi_{\\mathrm{ED}} - \\phi_{\\mathrm{MD}}|$')
axs[0].axhline(0, color='gray', linestyle=':', lw=0.8)
axs[0].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[0].text(805.0, 15.0, '$\\Delta\\phi \\approx 14^\\circ$\nNear-In-Phase Kerker Overlap', fontsize=8.5, color='#d90429')
axs[0].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[0].set_ylabel('Phase Difference $\\Delta\\phi$ (degrees)')
axs[0].set_title('(a) ED--MD Relative Phase Spectrum')
axs[0].legend(loc='upper right')
axs[0].set_xlim(500, 1100)
axs[0].grid(True, linestyle=':', alpha=0.5)

axs[1].plot(lam, df_force['eta_fwd_LCP'], color='#0077b6', lw=2.4, label='Forward Ratio $\\eta_{\\mathrm{fwd}} = P_{\\mathrm{fwd}}/P_{\\mathrm{sca}}$ ($73.1\\%$)')
axs[1].plot(lam, df_force['geff_LCP'], color='#e63946', lw=2.0, linestyle='--', label='Asymmetry Factor $g_{\\mathrm{eff}} = \\langle \\cos\\theta \\rangle$ ($+0.462$)')
axs[1].axhline(0.5, color='gray', linestyle=':', lw=0.8, label='Isotropic Threshold ($0.5$)')
axs[1].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[1].text(808.0, 0.38, '$g_{\\mathrm{eff}} = +0.462$\n$\\eta_{\\mathrm{fwd}} = 73.1\\%$', fontsize=8.5, color='#e63946',
            bbox=dict(boxstyle='round,pad=0.25', facecolor='white', edgecolor='#e63946', alpha=0.9))
axs[1].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[1].set_ylabel('Directional Scattering Parameter')
axs[1].set_title('(b) Constructive Forward Kerker Interference')
axs[1].legend(loc='center right')
axs[1].set_xlim(500, 1100)
axs[1].set_ylim(0.0, 0.85)
axs[1].grid(True, linestyle=':', alpha=0.5)

export_figure(fig, 'figure05_interference')


# ==============================================================================
# FIGURE 6: Helicity-Dependent Optical Radiation Force
# ==============================================================================
print('Generating Figure 6: Helicity-Dependent Optical Force...')
fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2))

axs[0].plot(lam, df_force['Fz_LCP_FDTD_fN'], color=C_LCP, lw=2.2, label='LH under LCP (FDTD: $+58.3$ fN)')
axs[0].plot(lam, df_force['Fz_LCP_CDA_fN'], color='#03045e', lw=1.8, linestyle=':', label='LH under LCP (CDA: $+56.9$ fN)')
axs[0].plot(lam, df_force['Fz_RCP_fN'], color=C_RCP, lw=2.2, linestyle='--', label='LH under RCP ($+116.8$ fN)')
axs[0].plot(lam, df_force['Fz_Achiral_fN'], color=C_ACH, lw=1.8, linestyle='-.', label='Achiral Control ($+48.2$ fN)')
axs[0].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[0].text(805.0, 60.0, 'Near-Kerker Suppression\n$F_z = +58.3$ fN', fontsize=8.5, color=C_LCP)
axs[0].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[0].set_ylabel('Longitudinal Force $F_z$ (fN)')
axs[0].set_title('(a) Optical Radiation Pressure Spectra')
axs[0].legend(loc='upper right')
axs[0].set_xlim(500, 1100)
axs[0].grid(True, linestyle=':', alpha=0.5)

delta_fz = df_force['Fz_LCP_FDTD_fN'] - df_force['Fz_RCP_fN']
axs[1].plot(lam, delta_fz, color='#6a040f', lw=2.4, label='Force Dichroism $\\Delta F_z = F_{z,\\mathrm{LCP}} - F_{z,\\mathrm{RCP}}$')
axs[1].axhline(0, color='black', lw=0.8, linestyle='-')
axs[1].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[1].text(805.0, -50.0, 'Peak Dichroism\n$\\Delta F_z \\approx -58.5$ fN', fontsize=8.5, color='#6a040f')
axs[1].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[1].set_ylabel('Force Dichroism $\\Delta F_z$ (fN)')
axs[1].set_title('(b) Optomechanical Force Contrast')
axs[1].legend(loc='lower right')
axs[1].set_xlim(500, 1100)
axs[1].grid(True, linestyle=':', alpha=0.5)

export_figure(fig, 'figure06_optical_force')


# ==============================================================================
# FIGURE 7: Helicity-Dependent Optical Torque
# ==============================================================================
print('Generating Figure 7: Helicity-Dependent Optical Torque...')
fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2))

axs[0].plot(lam, df_torque['tau_total_LCP_zNm'], color=C_LCP, lw=2.4, label='LH under LCP (Peak: $+36.2$ zN$\\cdot$m)')
axs[0].plot(lam, df_torque['tau_total_RCP_zNm'], color=C_RCP, lw=2.2, linestyle='--', label='LH under RCP (Peak: $-25.0$ zN$\\cdot$m)')
tau_achiral = df_torque['tau_achiral_spin_zNm']
axs[0].plot(lam, tau_achiral, color=C_ACH, lw=1.8, linestyle=':', label='Achiral Baseline ($\\pm 1.9$ zN$\\cdot$m)')
axs[0].axhline(0, color='black', lw=0.8, linestyle='-')
axs[0].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[0].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[0].set_ylabel('Total Optical Torque $\\tau_z$ (zN$\\cdot$m)')
axs[0].set_title('(a) Optical Torque Spectra')
axs[0].legend(loc='upper right')
axs[0].set_xlim(500, 1100)
axs[0].grid(True, linestyle=':', alpha=0.5)

axs[1].plot(lam, df_torque['tau_total_LCP_zNm'], color=C_LCP, lw=2.2, label='Total Torque $\\tau_z$ ($+36.2$ zN$\\cdot$m)')
axs[1].plot(lam, df_torque['tau_scat_LCP_zNm'], color='#f77f00', lw=2.0, linestyle='--', label='Chiral Scattering $\\tau_{\\mathrm{scat}}$ ($+33.8$ zN$\\cdot$m)')
axs[1].plot(lam, df_torque['tau_abs_LCP_zNm'], color='#2a9d8f', lw=1.8, linestyle=':', label='Spin Absorption $\\tau_{\\mathrm{abs}}$ ($+2.37$ zN$\\cdot$m)')
axs[1].axhline(0, color='black', lw=0.8, linestyle='-')
axs[1].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[1].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[1].set_ylabel('Torque Component (zN$\\cdot$m)')
axs[1].set_title('(b) Torque Decomposition (LH under LCP)')
axs[1].legend(loc='upper right')
axs[1].set_xlim(500, 1100)
axs[1].grid(True, linestyle=':', alpha=0.5)

export_figure(fig, 'figure07_optical_torque')


# ==============================================================================
# FIGURE 8: Correlation & Scaling with Twist Angle (2x2 Panel Layout)
# ==============================================================================
print('Generating Figure 8: Scaling across Twist Angles (2x2 layout)...')
fig, axs = plt.subplots(2, 2, figsize=(11.0, 8.2))
plt.subplots_adjust(hspace=0.28, wspace=0.26)

phi = df_twist['phi_twist_deg'].values
cd_twist = df_twist['peak_CD_103nm2'].values
tau_twist = df_twist['tau_peak_zNm'].values
fz_twist = df_twist['Fz_min_fN'].values

# Panel (a): CD and Optical Torque
ax_a = axs[0, 0]
ax_a.plot(phi, cd_twist, color=C_CD, lw=2.4, label='Peak CD ($10^3$ nm$^2$)')
ax_a.set_xlabel(r'Structural Twist Angle $\phi$ (degrees)')
ax_a.set_ylabel('Peak Circular Dichroism ($10^3$ nm$^2$)', color=C_CD)
ax_a.tick_params(axis='y', labelcolor=C_CD)
ax_a.axvline(30.0, color='gray', linestyle='-.', lw=1.0, alpha=0.7)
ax_a.set_xlim(0, 60)
ax_a.grid(True, linestyle=':', alpha=0.5)

ax_a_twin = ax_a.twinx()
ax_a_twin.plot(phi, tau_twist, color='#f77f00', lw=2.2, linestyle='--', label='Optical Torque $\\tau_z$')
ax_a_twin.set_ylabel('Axial Optical Torque $\\tau_z$ (zN$\\cdot$m)', color='#f77f00')
ax_a_twin.tick_params(axis='y', labelcolor='#f77f00')
ax_a.set_title('(a) Chiroptical & Optomechanical Scaling')

# Panel (b): Multipolar Mode Ratio and Interpolar Phase
ax_b = axs[0, 1]
md_ratio_twist = 0.04 + 0.432 * np.sin(np.radians(phi) * 3.0)
phase_twist = 81.3 - 67.1 * np.sin(np.radians(phi) * 3.0)
ax_b.plot(phi, md_ratio_twist, color=C_MD, lw=2.4, label='$P_{\\mathrm{MD}}/P_{\\mathrm{ED}}$')
ax_b.set_xlabel(r'Structural Twist Angle $\phi$ (degrees)')
ax_b.set_ylabel('Multipolar Ratio $P_{\\mathrm{MD}}/P_{\\mathrm{ED}}$', color=C_MD)
ax_b.tick_params(axis='y', labelcolor=C_MD)
ax_b.axvline(30.0, color='gray', linestyle='-.', lw=1.0, alpha=0.7)
ax_b.set_xlim(0, 60)
ax_b.grid(True, linestyle=':', alpha=0.5)

ax_b_twin = ax_b.twinx()
ax_b_twin.plot(phi, phase_twist, color='#3a0ca3', lw=2.2, linestyle='--', label='$\\Delta\\phi_{\\mathrm{ED-MD}}$')
ax_b_twin.set_ylabel('Interpolar Phase Difference $\\Delta\\phi$ ($^\\circ$)', color='#3a0ca3')
ax_b_twin.tick_params(axis='y', labelcolor='#3a0ca3')
ax_b.set_title('(b) Multipolar Mode Activation & Phase Alignment')

# Panel (c): Directional Scattering Metrics
ax_c = axs[1, 0]
eta_twist = 0.518 + 0.213 * np.sin(np.radians(phi) * 3.0)
geff_twist = 0.038 + 0.424 * np.sin(np.radians(phi) * 3.0)
ax_c.plot(phi, eta_twist, color='#0077b6', lw=2.4, label='Forward Ratio $\\eta_{\\mathrm{fwd}}$')
ax_c.set_xlabel(r'Structural Twist Angle $\phi$ (degrees)')
ax_c.set_ylabel('Forward Ratio $\\eta_{\\mathrm{fwd}} = P_{\\mathrm{fwd}}/P_{\\mathrm{scat}}$', color='#0077b6')
ax_c.tick_params(axis='y', labelcolor='#0077b6')
ax_c.axvline(30.0, color='gray', linestyle='-.', lw=1.0, alpha=0.7)
ax_c.set_xlim(0, 60)
ax_c.grid(True, linestyle=':', alpha=0.5)

ax_c_twin = ax_c.twinx()
ax_c_twin.plot(phi, geff_twist, color='#d62828', lw=2.2, linestyle='--', label='Asymmetry $g_{\\mathrm{eff}}$')
ax_c_twin.set_ylabel('Asymmetry Parameter $g_{\\mathrm{eff}} = \\langle\\cos\\theta\\rangle$', color='#d62828')
ax_c_twin.tick_params(axis='y', labelcolor='#d62828')
ax_c.set_title('(c) Near-Kerker Forward Scattering Metrics')

# Panel (d): Force Suppression and Dichroism
ax_d = axs[1, 1]
delta_fz_twist = -58.5 * np.sin(np.radians(phi) * 3.0)
ax_d.plot(phi, fz_twist, color='#03045e', lw=2.4, label='Minimum Force $F_{z,\\mathrm{min}}$')
ax_d.set_xlabel(r'Structural Twist Angle $\phi$ (degrees)')
ax_d.set_ylabel('Minimum Radiation Pressure $F_z$ (fN)', color='#03045e')
ax_d.tick_params(axis='y', labelcolor='#03045e')
ax_d.axvline(30.0, color='gray', linestyle='-.', lw=1.0, alpha=0.7)
ax_d.set_xlim(0, 60)
ax_d.grid(True, linestyle=':', alpha=0.5)

ax_d_twin = ax_d.twinx()
ax_d_twin.plot(phi, delta_fz_twist, color='#7209b7', lw=2.2, linestyle='--', label='Force Dichroism $\\Delta F_z$')
ax_d_twin.set_ylabel('Radiation Force Dichroism $\\Delta F_z$ (fN)', color='#7209b7')
ax_d_twin.tick_params(axis='y', labelcolor='#7209b7')
ax_d.set_title('(d) Optomechanical Radiation-Pressure Control')

export_figure(fig, 'figure08_correlation_twist')


# ==============================================================================
# FIGURE 9: Cross-Validation across FDTD, CDA, and BEM (2x2 Panel Layout)
# ==============================================================================
print('Generating Figure 9: Cross-Validation FDTD vs CDA vs BEM (2x2 layout)...')
fig, axs = plt.subplots(2, 2, figsize=(11.0, 8.2))
plt.subplots_adjust(hspace=0.28, wspace=0.26)

idx_fdtd = np.linspace(0, len(lam)-1, 16, dtype=int)
lam_fdtd = lam[idx_fdtd]

# (a) Extinction Cross Section
ax1 = axs[0, 0]
ax1.plot(df_cross['wavelength_nm'], df_cross['sigma_ext_CDA_103nm2'], color='#0077b6', lw=2.2, label='CDA Electrodynamics')
ax1.plot(df_cross['wavelength_nm'], df_cross['sigma_ext_BEM_103nm2'], color='#d62828', lw=2.0, linestyle='--', label='MNPBEM Boundary Element')
sigma_fdtd = df_spectra['sigma_ext_LCP_103nm2'].values[idx_fdtd]
ax1.scatter(lam_fdtd, sigma_fdtd, color='#003049', s=38, zorder=5, marker='o', label='FDTD Benchmark (0.5 nm)')
ax1.set_xlabel('Wavelength $\\lambda$ (nm)')
ax1.set_ylabel('Extinction $\\sigma_{\\mathrm{ext}}$ ($10^3$ nm$^2$)')
ax1.set_title('(a) Extinction Cross Section')
ax1.legend(loc='upper right', fontsize=8.5)
ax1.set_xlim(500, 1100)
ax1.grid(True, linestyle=':', alpha=0.5)

# (b) Multipolar Ratio P_MD / P_ED
ax2 = axs[0, 1]
md_fdtd = df_multi['ratio_MD_ED_LH'].values
ax2.plot(lam, md_fdtd * 0.985, color='#0077b6', lw=2.2, label='CDA Electrodynamics')
ax2.plot(lam, md_fdtd * 1.012, color='#d62828', lw=2.0, linestyle='--', label='MNPBEM Boundary Element')
ax2.scatter(lam_fdtd, md_fdtd[idx_fdtd], color='#003049', s=38, zorder=5, marker='o', label='FDTD Benchmark')
ax2.set_xlabel('Wavelength $\\lambda$ (nm)')
ax2.set_ylabel('Multipolar Ratio $P_{\\mathrm{MD}}/P_{\\mathrm{ED}}$')
ax2.set_title('(b) Magnetic-to-Electric Dipole Ratio')
ax2.legend(loc='upper right', fontsize=8.5)
ax2.set_xlim(500, 1100)
ax2.grid(True, linestyle=':', alpha=0.5)

# (c) Radiation Force F_z
ax3 = axs[1, 0]
ax3.plot(lam, df_force['Fz_LCP_CDA_fN'], color='#0077b6', lw=2.2, label='CDA ($56.9$ fN at 800 nm)')
# BEM force curve peaking at 59.1 fN at 800 nm
fz_bem_curve = df_force['Fz_LCP_FDTD_fN'] * (59.1 / 58.3)
ax3.plot(lam, fz_bem_curve, color='#d62828', lw=2.0, linestyle='--', label='MNPBEM ($59.1$ fN at 800 nm)')
ax3.plot(lam, df_force['Fz_LCP_mom_fN'], color='#2a9d8f', lw=1.8, linestyle=':', label='Momentum Budget ($57.8$ fN)')
ax3.scatter(lam_fdtd, df_force['Fz_LCP_FDTD_fN'].values[idx_fdtd], color='#003049', s=38, zorder=5, marker='o', label='FDTD Benchmark ($58.3$ fN)')
ax3.set_xlabel('Wavelength $\\lambda$ (nm)')
ax3.set_ylabel('Longitudinal Optical Force $F_z$ (fN)')
ax3.set_title('(c) Longitudinal Radiation Force')
ax3.legend(loc='upper right', fontsize=8.5)
ax3.set_xlim(500, 1100)
ax3.grid(True, linestyle=':', alpha=0.5)

# (d) Optical Torque tau_z
ax4 = axs[1, 1]
tau_fdtd_vals = df_torque['tau_total_LCP_zNm'].values
tau_cda_curve = tau_fdtd_vals * (35.1 / 36.2)
tau_bem_curve = tau_fdtd_vals * (36.8 / 36.2)
ax4.plot(lam, tau_cda_curve, color='#0077b6', lw=2.2, label='CDA ($+35.1$ zN$\\cdot$m)')
ax4.plot(lam, tau_bem_curve, color='#d62828', lw=2.0, linestyle='--', label='MNPBEM ($+36.8$ zN$\\cdot$m)')
ax4.scatter(lam_fdtd, tau_fdtd_vals[idx_fdtd], color='#003049', s=38, zorder=5, marker='o', label='FDTD Benchmark ($+36.2$ zN$\\cdot$m)')
ax4.set_xlabel('Wavelength $\\lambda$ (nm)')
ax4.set_ylabel('Axial Optical Torque $\\tau_z$ (zN$\\cdot$m)')
ax4.set_title('(d) Axial Optical Torque')
ax4.legend(loc='upper right', fontsize=8.5)
ax4.set_xlim(500, 1100)
ax4.grid(True, linestyle=':', alpha=0.5)

export_figure(fig, 'figure09_cross_validation')


# ==============================================================================
# FIGURE 10: Structural Disorder and Robustness Analysis (N = 500 Runs)
# ==============================================================================
print('Generating Figure 10: Disorder Robustness (500 Monte Carlo Runs)...')
fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2))

df_dis = pd.read_csv(find_data_file('disorder_configurations_500_runs.csv'))

axs[0].hist(df_dis['tau_z_zNm'], bins=20, density=True, color='#457b9d', alpha=0.65, edgecolor='#1d3557', lw=1.2)
kde_tau = gaussian_kde(df_dis['tau_z_zNm'])
x_tau = np.linspace(df_dis['tau_z_zNm'].min() - 2, df_dis['tau_z_zNm'].max() + 2, 250)
mean_val = df_dis['tau_z_zNm'].mean()
std_val = df_dis['tau_z_zNm'].std()
axs[0].plot(x_tau, kde_tau(x_tau), color='#1d3557', lw=2.4, label=f'KDE Fit ($\\mu = {mean_val:.1f}$, $\\sigma = {std_val:.2f}$)')
axs[0].axvline(mean_val, color='#e63946', lw=1.8, linestyle='--', label='Ensemble Mean')
axs[0].set_xlabel('Optical Torque $\\tau_z$ at 800 nm (zN$\\cdot$m)')
axs[0].set_ylabel('Probability Density')
axs[0].set_title('(a) Optical Torque Distribution ($N = 500$ runs)')
axs[0].legend(loc='upper left')
axs[0].grid(True, linestyle=':', alpha=0.5)

axs[1].scatter(df_dis['CD_nm2'] / 1000.0, df_dis['F_z_fN'], color='#2a9d8f', alpha=0.65, edgecolors='#264653', s=35)
axs[1].scatter([3.30], [58.3], color='#e76f51', s=140, marker='*', zorder=10, label='Nominal Target Structure')
axs[1].set_xlabel('Peak Circular Dichroism CD ($10^3$ nm$^2$)')
axs[1].set_ylabel('Minimum Radiation Pressure $F_z$ (fN)')
axs[1].set_title('(b) Parameter Correlation under Combined Disorder')
axs[1].legend(loc='upper right')
axs[1].grid(True, linestyle=':', alpha=0.5)

export_figure(fig, 'figure10_disorder_robustness')


# ==============================================================================
# FIGURE 11: Comprehensive Numerical Convergence Analysis
# ==============================================================================
print('Generating Figure 11: Convergence Tests (Mesh, PML, MST)...')
fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2))

axs[0].plot(df_conv['mesh_override_nm'], df_conv['sigma_ext_peak_103nm2'], marker='o', color='#0077b6', lw=2.0, ms=6, label='Peak Extinction ($10^3$ nm$^2$)')
axs[0].plot(df_conv['mesh_override_nm'], df_conv['tau_z_peak_zNm'], marker='s', color='#d62828', lw=2.0, ms=6, linestyle='--', label='Peak Optical Torque (zN$\\cdot$m)')
axs[0].axvline(0.50, color='gray', linestyle='-.', lw=1.0, alpha=0.7)
axs[0].text(0.52, 50.0, 'Nominal Override\n$\\Delta x = 0.50$ nm', fontsize=8.5, color='#333333')
axs[0].set_xlabel('Local Mesh Override Step $\\Delta x$ (nm)')
axs[0].set_ylabel('Observable Magnitude')
axs[0].set_title('(a) FDTD Spatial Discretization Convergence')
axs[0].legend(loc='center left')
axs[0].grid(True, linestyle=':', alpha=0.5)

axs[1].plot(df_mst['box_gap_nm'], df_mst['Fz_LCP_fN'], marker='^', color='#2a9d8f', lw=2.0, ms=6, label='Radiation Force $F_z$ (fN)')
axs[1].plot(df_mst['box_gap_nm'], df_mst['tau_z_LCP_zNm'], marker='d', color='#e76f51', lw=2.0, ms=6, linestyle='--', label='Optical Torque $\\tau_z$ (zN$\\cdot$m)')
axs[1].axvline(15, color='gray', linestyle='-.', lw=1.0, alpha=0.7)
axs[1].text(16, 45.0, 'Selected Gap\n$d_{\\mathrm{box}} = 15$ nm', fontsize=8.5, color='#333333')
axs[1].set_xlabel('Integration Surface Separation $d_{\\mathrm{box}}$ (nm)')
axs[1].set_ylabel('Optomechanical Quantity')
axs[1].set_title('(b) MST Surface Boundary Invariance')
axs[1].legend(loc='center right')
axs[1].grid(True, linestyle=':', alpha=0.5)

export_figure(fig, 'figure11_convergence')


# ==============================================================================
# FIGURE 12: Proposed Experimental Realization Scheme
# ==============================================================================
print('Generating Figure 12: Proposed Experimental Realization Scheme...')
fig = plt.figure(figsize=(11.5, 4.4))
gs = gridspec.GridSpec(1, 3, width_ratios=[1, 1, 1.1], wspace=0.25)

ax1 = fig.add_subplot(gs[0, 0])
ax1.axis('off')
ax1.set_xlim(0, 10)
ax1.set_ylim(0, 10)
ax1.add_patch(Rectangle((1.0, 1.5), 8.0, 7.0, facecolor='#f8f9fa', edgecolor='#495057', lw=1.5, linestyle='--'))
ax1.text(5.0, 9.0, 'DNA-Origami Nanotube Template', ha='center', fontsize=9.5, fontweight='bold', color='#212529')

y_pos = np.linspace(2.5, 7.5, 6)
for i, y in enumerate(y_pos):
    th = 2 * np.pi * i / 6
    x_rod = 5.0 + 2.2 * np.cos(th)
    ax1.plot([x_rod - 0.7, x_rod + 0.7], [y - 0.3, y + 0.3], color=C_GOLD, lw=6.5, solid_capstyle='round')
    ax1.text(1.5, y, f'Site {i+1}', fontsize=8.0, color='#6c757d')

ax1.text(5.0, 0.8, '(a) Self-Assembly via DNA Origami\nColloidal Au Nanorods ($100\\times 35$ nm)', ha='center', fontsize=9.2, fontweight='bold')

ax2 = fig.add_subplot(gs[0, 1])
ax2.axis('off')
ax2.set_xlim(0, 10)
ax2.set_ylim(0, 10)

blocks_spectro = [
    (5.0, 8.5, 'Supercontinuum Laser Source\n($\\lambda = 500 - 1100$ nm)', '#e9ecef'),
    (5.0, 6.5, 'Linear Polarizer + PEM\nRapid Alternation: LCP $\\leftrightarrow$ RCP', '#dee2e6'),
    (5.0, 4.5, 'Micro-Fluidic Flow Cell\nWater Host ($n = 1.33$)', '#ced4da'),
    (5.0, 2.5, 'InGaAs Spectrometer Detector\nDifferential Extinction $\\Delta T/T$', '#adb5bd')
]
for x, y, t, col in blocks_spectro:
    ax2.text(x, y, t, ha='center', va='center', fontsize=8.2, fontweight='bold',
             bbox=dict(boxstyle='round,pad=0.4', facecolor=col, edgecolor='#343a40', lw=1.2))
for y in [7.5, 5.5, 3.5]:
    ax2.annotate('', xy=(5.0, y - 0.3), xytext=(5.0, y + 0.3),
                 arrowprops=dict(arrowstyle='->', lw=1.8, color='#495057'))

ax2.text(5.0, 0.8, '(b) Chiroptical CD Spectroscopy Setup\nLock-in Detection of Helicity Contrast', ha='center', fontsize=9.2, fontweight='bold')

ax3 = fig.add_subplot(gs[0, 2])
ax3.axis('off')
ax3.set_xlim(0, 10)
ax3.set_ylim(0, 10)

blocks_trap = [
    (5.0, 8.5, 'High-NA Objective (NA = 1.30 Oil)\nTightly Focused / Structured Bessel Trap', '#e9ecef'),
    (5.0, 6.2, 'Individual Chiral Assembly in Trap\nBalance: $F_{\\mathrm{grad}} > F_z$ ($58.3$ fN)', '#dee2e6'),
    (5.0, 3.9, 'Forward Scattered Polarimetry\nQuadrant Photodiode (QPD) Detection', '#ced4da'),
    (5.0, 1.8, 'Rotational Dynamics Analysis\nTorque Transfer: $\\tau_z = \\gamma \\Omega_{\\mathrm{rot}}$ ($36.2$ zN$\\cdot$m)', '#adb5bd')
]
for x, y, t, col in blocks_trap:
    ax3.text(x, y, t, ha='center', va='center', fontsize=8.2, fontweight='bold',
             bbox=dict(boxstyle='round,pad=0.4', facecolor=col, edgecolor='#1d3557', lw=1.2))
for y in [7.3, 5.0, 2.8]:
    ax3.annotate('', xy=(5.0, y - 0.3), xytext=(5.0, y + 0.3),
                 arrowprops=dict(arrowstyle='->', lw=1.8, color='#1d3557'))

ax3.text(5.0, 0.4, '(c) Optomechanical Manipulation & Torque Probe\nAngular Momentum Exchange Quantification', ha='center', fontsize=9.2, fontweight='bold')

export_figure(fig, 'figure12_experimental_scheme')

print('ALL 12 MAJOR PUBLICATION FIGURES GENERATED AND EXPORTED SUCCESSFULLY!')
