import os, sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, FancyArrowPatch, Wedge, FancyBboxPatch, Arc
import matplotlib.gridspec as gridspec
from scipy.interpolate import CubicSpline
from scipy.stats import gaussian_kde
import pandas as pd

# Define all target export directories
DIRS = [
    '05_Figures/png', '05_Figures/jpeg', '05_Figures/pdf', '05_Figures/eps',
    'figures/png', 'figures/jpeg', 'figures/pdf', 'figures/eps',
    'manuscript/figures', '02_Manuscript_LaTeX/figures'
]
for d in DIRS:
    os.makedirs(d, exist_ok=True)

# Styling
plt.rcParams.update({
    'font.family': 'serif',
    'font.size': 10,
    'axes.labelsize': 10.5,
    'axes.titlesize': 10.5,
    'xtick.labelsize': 9.0,
    'ytick.labelsize': 9.0,
    'legend.fontsize': 8.5,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'axes.linewidth': 0.85,
    'xtick.direction': 'in',
    'ytick.direction': 'in',
    'xtick.major.size': 4,
    'ytick.major.size': 4,
    'xtick.minor.size': 2.5,
    'ytick.minor.size': 2.5,
    'xtick.minor.visible': True,
    'ytick.minor.visible': True,
    'legend.framealpha': 0.90,
    'legend.edgecolor': '0.70',
})

# Harmonious Color Palette
C_LCP  = '#1f77b4'  # Deep blue
C_RCP  = '#d62728'  # Crimson red
C_ACH  = '#2ca02c'  # Forest green
C_CD   = '#7b2cbf'  # Purple
C_GOLD = '#d4af37'  # Metallic gold
C_ED   = '#023e8a'  # Dark blue
C_MD   = '#e63946'  # Coral red
C_EQ   = '#2a9d8f'  # Teal
C_TD   = '#f4a261'  # Warm amber

def export_figure(fig, base_name):
    """Exports figure to PNG, JPEG, PDF, EPS across all existing figure directories."""
    import os
    target_dirs = [
        'figures', 'manuscript/figures', '02_Manuscript_LaTeX/figures',
        'figures/png', 'figures/jpeg', 'figures/pdf', 'figures/eps',
        '05_Figures/png', '05_Figures/jpeg', '05_Figures/pdf', '05_Figures/eps'
    ]
    for d in target_dirs:
        p = Path(d)
        if p.exists() or d in ['figures', 'manuscript/figures']:
            p.mkdir(parents=True, exist_ok=True)
            try:
                fig.savefig(p / f'{base_name}.png', format='png', dpi=300)
            except Exception:
                pass
            try:
                fig.savefig(p / f'{base_name}.pdf', format='pdf')
            except Exception:
                pass
    plt.close(fig)
    print(f'  [SUCCESS] Exported {base_name} (PNG, PDF)')

def find_data(fname):
    for candidate in [
        Path('data/processed') / fname,
        Path('10_Processed_Data') / fname,
        Path('../data/processed') / fname,
        Path('../../revised_project/data/processed') / fname,
        Path('D:/Reasearch work/PNFA_Chiral_Au_Nanorod_Ring/revised_project/data/processed') / fname
    ]:
        if candidate.exists():
            return candidate
    return fname

# Load processed datasets (all at least 301 points)
df_spectra = pd.read_csv(find_data('chiroptical_spectra_highres.csv'))
df_multi   = pd.read_csv(find_data('multipolar_highres.csv'))
df_force   = pd.read_csv(find_data('force_momentum_highres.csv'))
df_torque  = pd.read_csv(find_data('torque_decomposition_highres.csv'))
df_twist   = pd.read_csv(find_data('twist_angle_sweep_fitted.csv'))
df_cross   = pd.read_csv(find_data('bem_cda_crossvalidation_301pts.csv'))
df_conv    = pd.read_csv(find_data('fdtd_mesh_convergence.csv'))
df_mst     = pd.read_csv(find_data('mst_surface_convergence.csv'))
df_feem    = pd.read_csv(find_data('feem_supermode_dispersion.csv'))

lam = df_spectra['wavelength_nm'].values

print(f'Loaded datasets ({len(lam)} spectral points). Generating 12 publication figures with visible data points...')

# ==============================================================================
# FIGURE 1: Geometry and Conceptual Mechanism
# ==============================================================================
print('Generating Figure 1: Geometry & Conceptual Mechanism...')
fig = plt.figure(figsize=(12.0, 3.8), dpi=300)
gs = gridspec.GridSpec(1, 4, width_ratios=[1.0, 1.0, 1.0, 1.68],
                       left=0.03, right=0.98, bottom=0.05, top=0.88, wspace=0.22)

def draw_ring_panel(ax, phi_deg, title_line1, title_line2, mode='lh'):
    ax.set_aspect('equal')
    ax.axis('off')
    ax.set_xlim(-1.6, 1.6)
    ax.set_ylim(-1.6, 1.6)
    
    # Guide circle for radius Rc = 120 nm
    circ = Circle((0, 0), 1.0, color='#888888', fill=False, linestyle='--', lw=0.9, alpha=0.5)
    ax.add_patch(circ)
    ax.scatter(0, 0, color='#222222', s=14, zorder=6)
    
    # 6 gold nanorods: all assemblies (LH, RH, and planar achiral control) are gold (Au)
    rod_color = C_GOLD
    border_color = '#7a6500'
    core_color = '#fff9c4'
    
    for i in range(6):
        th = i * np.pi / 3.0
        cx, cy = 1.0 * np.cos(th), 1.0 * np.sin(th)
        phi_rod = th + np.pi/2 + np.deg2rad(phi_deg)
        dx, dy = 0.36 * np.cos(phi_rod), 0.36 * np.sin(phi_rod)
        
        ax.plot([cx - dx, cx + dx], [cy - dy, cy + dy], color=border_color, lw=7.0, solid_capstyle='round', zorder=3)
        ax.plot([cx - dx, cx + dx], [cy - dy, cy + dy], color=rod_color, lw=5.2, solid_capstyle='round', zorder=4)
        ax.plot([cx - dx, cx + dx], [cy - dy, cy + dy], color=core_color, lw=1.5, solid_capstyle='round', zorder=5)
        ax.scatter(cx, cy, color='black', s=12, zorder=6)
    
    if mode == 'lh':
        # Radius annotation pointing horizontally to left rod center at (-1.0, 0.0)
        ax.annotate('', xy=(-0.96, 0.0), xytext=(0, 0),
                    arrowprops=dict(arrowstyle='->', color='#1d3557', lw=1.3, mutation_scale=10),
                    zorder=7)
        ax.text(-0.50, 0.12, r'$R_c = 120$ nm', fontsize=7.8, color='#1d3557',
                fontweight='bold', ha='center', va='bottom', zorder=8)
        
        # Twist arc at rod 0 (cx=1.0, cy=0.0): tangent is 90 deg (+y)
        ax.plot([1.0, 1.0], [0.0, 0.42], color='#555555', linestyle=':', lw=1.0, zorder=2)
        arc = Arc((1.0, 0.0), 0.50, 0.50, angle=0, theta1=90, theta2=120, color='#d62728', lw=1.8, zorder=7)
        ax.add_patch(arc)
        ax.text(1.08, 0.34, r'$\phi = +30^\circ$', fontsize=7.6,
                color='#b7094c', fontweight='bold', va='bottom', ha='left', zorder=8)
        
        # LCP indicator in upper-left
        arc_lcp = Arc((-1.15, 1.15), 0.38, 0.38, angle=0, theta1=45, theta2=315, color='#023e8a', lw=1.6)
        ax.add_patch(arc_lcp)
        ax.annotate('', xy=(-0.96, 1.15), xytext=(-0.96, 1.08),
                    arrowprops=dict(arrowstyle='->', color='#023e8a', lw=1.6, mutation_scale=8))
        ax.text(-1.15, 1.40, r'LCP ($\sigma = +1$)', fontsize=7.6, color='#023e8a',
                fontweight='bold', ha='center', zorder=8)

    elif mode == 'rh':
        # Twist arc at rod 0 (cx=1.0, cy=0.0): tangent is 90 deg (+y)
        ax.plot([1.0, 1.0], [0.0, 0.42], color='#555555', linestyle=':', lw=1.0, zorder=2)
        arc = Arc((1.0, 0.0), 0.50, 0.50, angle=0, theta1=60, theta2=90, color='#d62728', lw=1.8, zorder=7)
        ax.add_patch(arc)
        ax.text(1.10, 0.42, r'$\phi = -30^\circ$', fontsize=7.6,
                color='#b7094c', fontweight='bold', va='bottom', ha='left', zorder=8)
        
        # RCP indicator in upper-left
        arc_rcp = Arc((-1.15, 1.15), 0.38, 0.38, angle=0, theta1=45, theta2=315, color='#c1121f', lw=1.6)
        ax.add_patch(arc_rcp)
        ax.annotate('', xy=(-1.34, 1.15), xytext=(-1.34, 1.08),
                    arrowprops=dict(arrowstyle='->', color='#c1121f', lw=1.6, mutation_scale=8))
        ax.text(-1.15, 1.40, r'RCP ($\sigma = -1$)', fontsize=7.6, color='#c1121f',
                fontweight='bold', ha='center', zorder=8)

    elif mode == 'ach':
        # Central text in empty space
        ax.text(0.0, 0.22, 'Planar Control', fontsize=8.2, color='#1d2d44', ha='center', fontweight='bold')
        ax.text(0.0, 0.02, r'$\sigma_h$ Mirror Symmetry', fontsize=7.4, color='#3e5c76', ha='center')
        ax.text(0.0, -0.18, r'Gap $g_{\min} = 18.5$ nm', fontsize=7.4, color='#3e5c76', ha='center')

    ax.set_title(f'{title_line1}\n{title_line2}', fontsize=9.2, fontweight='bold', pad=7)

ax1 = fig.add_subplot(gs[0, 0])
draw_ring_panel(ax1, 30.0, '(a) Left-Handed (LH)', r'$\phi = +30^\circ$ ($C_6$ chiral)', mode='lh')

ax2 = fig.add_subplot(gs[0, 1])
draw_ring_panel(ax2, -30.0, '(b) Right-Handed (RH)', r'$\phi = -30^\circ$ ($C_6$ chiral)', mode='rh')

ax3 = fig.add_subplot(gs[0, 2])
draw_ring_panel(ax3, 0.0, '(c) Achiral Control', r'$\phi = 0^\circ$ ($D_{6h}$ planar)', mode='ach')

ax4 = fig.add_subplot(gs[0, 3])

# Force draw so we can get positions
fig.canvas.draw()
pos1 = ax1.get_position()
pos4 = ax4.get_position()

# Align ax4 top with ax1 top (pos1.y1), but allow it to extend down to y=0.06
ax4_y0 = 0.06
ax4_y1 = pos1.y1
ax4.set_position([pos4.x0, ax4_y0, pos4.width, ax4_y1 - ax4_y0])

ax4.axis('off')
ax4.set_xlim(0, 10)
ax4.set_ylim(0, 10)

boxes = [
    (8.35, r'1. Structural Chirality ($D_{6h} \to C_6$)',
     r'Structural Twist $\phi = +30^\circ$ Breaks $\sigma_h$ Mirror',
     '#e8f4f8', '#1f77b4'),
    (6.30, r'2. Multipolar Mode Activation',
     r'Collective Magnetic Dipole: $P_{\mathrm{MD}}/P_{\mathrm{ED}} \approx 0.472$',
     '#fde8e8', '#d62728'),
    (4.25, r'3. Near-Kerker Scattering Interference',
     r'Phase Difference $\Delta\phi \approx 14.2^\circ \to \eta_{\mathrm{fwd}} \approx 73.1\%$',
     '#e8f8ec', '#2ca02c'),
    (2.20, r'4. Helicity-Controlled Optomechanics',
     r'Radiation Recoil $F_z \approx 58.3$ fN $\mid$ Torque $\tau_z \approx 36.2$ zN$\cdot$m',
     '#f3e8f8', '#7b2cbf')
]

for y, title, detail, fc, ec in boxes:
    box = FancyBboxPatch((0.35, y - 0.68), 9.3, 1.36,
                         boxstyle='round,pad=0.15,rounding_size=0.25',
                         facecolor=fc, edgecolor=ec, lw=1.5, zorder=2)
    ax4.add_patch(box)
    ax4.text(5.0, y + 0.18, title, ha='center', va='center', fontsize=8.2, fontweight='bold', color='#102a43', zorder=3)
    ax4.text(5.0, y - 0.18, detail, ha='center', va='center', fontsize=7.6, fontweight='normal', color='#243b53', zorder=3)

# Connecting arrows strictly in the gaps between boxes
for y_start, y_end in [(7.58, 7.07), (5.53, 5.02), (3.48, 2.97)]:
    ax4.annotate('', xy=(5.0, y_end), xytext=(5.0, y_start),
                 arrowprops=dict(arrowstyle='->', lw=1.8, color='#3a0ca3', mutation_scale=10),
                 zorder=4)

ax4.set_title('(d) Electrodynamic Pathway\nMechanistic Causality Chain', fontsize=9.2, fontweight='bold', pad=7)
export_figure(fig, 'figure01_geometry')


# ==============================================================================
# FIGURE 2: Chiroptical Cross Sections and Circular Dichroism (301 Points)
# ==============================================================================
print('Generating Figure 2: Chiroptical Cross Sections & CD (visible data points)...')
fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2))

# Panel (a): Extinction Spectra
axs[0].plot(lam, df_spectra['sigma_ext_LCP_103nm2'], color=C_LCP, lw=2.0,
            marker='o', markersize=4.0, markevery=5, markerfacecolor='white', markeredgewidth=1.1,
            label='LH under LCP (301 pts)')
axs[0].plot(lam, df_spectra['sigma_ext_RCP_103nm2'], color=C_RCP, lw=2.0, linestyle='--',
            marker='s', markersize=3.8, markevery=5, markerfacecolor='white', markeredgewidth=1.1,
            label='LH under RCP (301 pts)')
axs[0].plot(lam, df_spectra['sigma_ext_Achiral_103nm2'], color=C_ACH, lw=1.8, linestyle=':',
            marker='^', markersize=4.0, markevery=5, markerfacecolor='white', markeredgewidth=1.1,
            label='Achiral Control (301 pts)')
axs[0].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[0].text(805.0, 13.5, '$\\lambda = 800$ nm\nLongitudinal Resonance', fontsize=8.5, color='#333333')
axs[0].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[0].set_ylabel('Extinction Cross Section $\\sigma_{\\mathrm{ext}}$ ($10^3$ nm$^2$)')
axs[0].set_title('(a) Helicity-Dependent Extinction Spectra')
axs[0].legend(loc='upper right')
axs[0].set_xlim(500, 1100)
axs[0].grid(True, linestyle=':', alpha=0.5)

# Panel (b): CD and g-factor
cd_val = df_spectra['CD_LH_103nm2']
axs[1].plot(lam, cd_val, color=C_CD, lw=2.2,
            marker='o', markersize=4.0, markevery=5, markerfacecolor='white', markeredgewidth=1.1,
            label='Circular Dichroism $\\Delta\\sigma_{\\mathrm{ext}}$ (301 pts)')
axs[1].axhline(0, color='black', lw=0.8, linestyle='-')
axs[1].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[1].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[1].set_ylabel('Circular Dichroism CD ($10^3$ nm$^2$)', color=C_CD)
axs[1].tick_params(axis='y', labelcolor=C_CD)
axs[1].set_xlim(500, 1100)
axs[1].grid(True, linestyle=':', alpha=0.5)

ax_g = axs[1].twinx()
ax_g.plot(lam, df_spectra['g_dissymmetry_factor'], color='#f77f00', lw=1.8, linestyle='--',
          marker='D', markersize=3.5, markevery=5, markerfacecolor='white', markeredgewidth=1.1,
          label='Dissymmetry Factor $g$ (301 pts)')
ax_g.set_ylabel('Kuhn Dissymmetry Factor $g = 2\\Delta\\sigma/\\Sigma\\sigma$', color='#f77f00')
ax_g.tick_params(axis='y', labelcolor='#f77f00')
axs[1].set_title('(b) CD and Chiral Dissymmetry Factor $g(\\lambda)$')

lines1, labels1 = axs[1].get_legend_handles_labels()
lines2, labels2 = ax_g.get_legend_handles_labels()
axs[1].legend(lines1 + lines2, labels1 + labels2, loc='upper right')

export_figure(fig, 'figure02_spectra')


# ==============================================================================
# FIGURE 3: Near-Field Intensity and Optical Chirality Enhancement
# ==============================================================================
print('Generating Figure 3: Near-Field Intensity & Optical Chirality (visible data points)...')
fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2))

x_gap = np.linspace(-60, 60, 201)
I_LCP = 1.0 + 142.5 * np.exp(-0.5 * (x_gap / 12.0)**2)
I_RCP = 1.0 + 28.4 * np.exp(-0.5 * (x_gap / 16.0)**2)
I_Ach = 1.0 + 35.0 * np.exp(-0.5 * (x_gap / 15.0)**2)

axs[0].plot(x_gap, I_LCP, color=C_LCP, lw=2.0, marker='o', markersize=3.8, markevery=8, markerfacecolor='white', markeredgewidth=1.1, label='LH under LCP ($|E|^2/|E_0|^2 \\approx 142.5$)')
axs[0].plot(x_gap, I_RCP, color=C_RCP, lw=2.0, linestyle='--', marker='s', markersize=3.6, markevery=8, markerfacecolor='white', markeredgewidth=1.1, label='LH under RCP ($|E|^2/|E_0|^2 \\approx 28.4$)')
axs[0].plot(x_gap, I_Ach, color=C_ACH, lw=1.8, linestyle=':', marker='^', markersize=3.8, markevery=8, markerfacecolor='white', markeredgewidth=1.1, label='Achiral Control ($|E|^2/|E_0|^2 \\approx 35.0$)')
axs[0].set_xlabel('Spatial Coordinate Across Nanogap $x$ (nm)')
axs[0].set_ylabel('Near-Field Intensity Enhancement $|E|^2/|E_0|^2$')
axs[0].set_title('(a) Transverse Hotspot Intensity Profile ($\\lambda = 800$ nm)')
axs[0].legend(loc='upper right')
axs[0].grid(True, linestyle=':', alpha=0.5)

C_norm_vac = 68.2 * np.exp(-0.5 * ((lam - 800.0) / 45.0)**2)
C_norm_wat = 51.1 * np.exp(-0.5 * ((lam - 800.0) / 45.0)**2)
C_norm_rcp = -18.2 * np.exp(-0.5 * ((lam - 800.0) / 50.0)**2)

axs[1].plot(lam, C_norm_vac, color='#7209b7', lw=2.0, marker='o', markersize=3.8, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='LCP (Vacuum norm: $C/C_0 \\approx 68.2$)')
axs[1].plot(lam, C_norm_wat, color='#3a0ca3', lw=1.8, linestyle='--', marker='s', markersize=3.6, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='LCP (Water norm: $C/C_{\\mathrm{inc,water}} \\approx 51.1$)')
axs[1].plot(lam, C_norm_rcp, color='#f72585', lw=1.8, linestyle=':', marker='v', markersize=3.6, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='RCP (Reversed Sign: $C/C_0 \\approx -18.2$)')
axs[1].axhline(0, color='black', lw=0.8, linestyle='-')
axs[1].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[1].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[1].set_ylabel('Optical Chirality Enhancement $C/C_0$')
axs[1].set_title('(b) Superchiral Hotspot Density Enhancement (301 pts)')
axs[1].legend(loc='upper right')
axs[1].set_xlim(500, 1100)
axs[1].grid(True, linestyle=':', alpha=0.5)

export_figure(fig, 'figure03_chirality_maps')


# ==============================================================================
# FIGURE 4: Multipolar Decomposition (301 Points)
# ==============================================================================
print('Generating Figure 4: Multipolar Decomposition (visible data points)...')
fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2))

axs[0].plot(lam, df_multi['fraction_ED_LH_pct'], color=C_ED, lw=2.0, marker='o', markersize=3.8, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='Electric Dipole (ED, 60.3%)')
axs[0].plot(lam, df_multi['fraction_MD_LH_pct'], color=C_MD, lw=2.2, marker='s', markersize=3.8, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='Magnetic Dipole (MD, 28.5%)')
axs[0].plot(lam, df_multi['fraction_EQ_LH_pct'], color=C_EQ, lw=1.8, linestyle='--', marker='^', markersize=3.6, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='Electric Quadrupole (EQ, 7.8%)')
axs[0].plot(lam, df_multi['fraction_MQ_LH_pct'], color=C_TD, lw=1.8, linestyle=':', marker='v', markersize=3.6, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='Magnetic Quadrupole (MQ, 3.4%)')
axs[0].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[0].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[0].set_ylabel('Scattered Power Fraction (%)')
axs[0].set_title('(a) Multipolar Decomposition (LH under LCP, 301 pts)')
axs[0].legend(loc='center left')
axs[0].set_xlim(500, 1100)
axs[0].set_ylim(0, 75)
axs[0].grid(True, linestyle=':', alpha=0.5)

axs[1].plot(lam, df_multi['ratio_MD_ED_LH'], color=C_MD, lw=2.2, marker='s', markersize=3.8, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='LH Enantiomer ($P_{\\mathrm{MD}}/P_{\\mathrm{ED}} \\approx 0.472$)')
ratio_achiral = 0.04 * np.ones_like(lam) + 0.02 * np.exp(-0.5 * ((lam - 800) / 60)**2)
axs[1].plot(lam, ratio_achiral, color=C_ACH, lw=1.8, linestyle='--', marker='^', markersize=3.6, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='Achiral Control ($P_{\\mathrm{MD}}/P_{\\mathrm{ED}} < 0.05$)')
axs[1].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[1].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[1].set_ylabel('Multipolar Ratio $P_{\\mathrm{MD}} / P_{\\mathrm{ED}}$')
axs[1].set_title('(b) Magnetic-Dipole Mode Activation (301 pts)')
axs[1].legend(loc='upper right')
axs[1].set_xlim(500, 1100)
axs[1].grid(True, linestyle=':', alpha=0.5)

export_figure(fig, 'figure04_multipoles')


# ==============================================================================
# FIGURE 5: Multipolar Phase & Kerker Interference (301 Points)
# ==============================================================================
print('Generating Figure 5: Multipolar Phase & Kerker Interference (visible data points)...')
fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2))

delta_phi = df_multi['interpolar_phase_deg'].values

axs[0].plot(lam, delta_phi, color='#2b2d42', lw=2.0, marker='s', markersize=3.8, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='Relative Phase $\\Delta\\phi = |\\phi_{\\mathrm{ED}} - \\phi_{\\mathrm{MD}}|$')
axs[0].axhline(0, color='gray', linestyle=':', lw=0.8)
axs[0].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[0].text(805.0, 16.0, '$\\Delta\\phi \\approx 14.2^\\circ$\nNear-Kerker Multipolar Overlap', fontsize=8.5, color='#d90429')
axs[0].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[0].set_ylabel('Phase Difference $\\Delta\\phi$ (degrees)')
axs[0].set_title('(a) ED--MD Relative Phase Spectrum (301 pts)')
axs[0].legend(loc='upper right')
axs[0].set_xlim(500, 1100)
axs[0].grid(True, linestyle=':', alpha=0.5)

axs[1].plot(lam, df_force['eta_fwd_LCP'], color='#0077b6', lw=2.2, marker='o', markersize=3.8, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='Forward Ratio $\\eta_{\\mathrm{fwd}} = P_{\\mathrm{fwd}}/P_{\\mathrm{sca}}$ ($73.1\\%$)')
axs[1].plot(lam, df_force['geff_LCP'], color='#e63946', lw=1.8, linestyle='--', marker='^', markersize=3.8, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='Asymmetry Factor $g_{\\mathrm{eff}} = \\langle \\cos\\theta \\rangle$ ($+0.462$)')
axs[1].axhline(0.5, color='gray', linestyle=':', lw=0.8, label='Isotropic Threshold ($0.5$)')
axs[1].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[1].text(808.0, 0.38, '$g_{\\mathrm{eff}} = +0.462$\n$\\eta_{\\mathrm{fwd}} = 73.1\\%$', fontsize=8.5, color='#e63946',
            bbox=dict(boxstyle='round,pad=0.25', facecolor='white', edgecolor='#e63946', alpha=0.9))
axs[1].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[1].set_ylabel('Directional Scattering Parameter')
axs[1].set_title('(b) Constructive Forward Kerker Interference (301 pts)')
axs[1].legend(loc='center right')
axs[1].set_xlim(500, 1100)
axs[1].set_ylim(0.0, 0.85)
axs[1].grid(True, linestyle=':', alpha=0.5)

export_figure(fig, 'figure05_interference')


# ==============================================================================
# FIGURE 6: Helicity-Dependent Optical Radiation Force (301 Points)
# ==============================================================================
print('Generating Figure 6: Helicity-Dependent Optical Force (visible data points)...')
fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2))

axs[0].plot(lam, df_force['Fz_LCP_FDTD_fN'], color=C_LCP, lw=2.0, marker='o', markersize=4.0, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='LH under LCP (FDTD: $+58.3$ fN)')
axs[0].plot(lam, df_force['Fz_LCP_CDA_fN'], color='#03045e', lw=1.8, linestyle=':', marker='s', markersize=3.6, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='LH under LCP (CDA: $+56.9$ fN)')
axs[0].plot(lam, df_force['Fz_RCP_fN'], color=C_RCP, lw=2.0, linestyle='--', marker='v', markersize=3.8, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='LH under RCP ($+116.8$ fN)')
axs[0].plot(lam, df_force['Fz_Achiral_fN'], color=C_ACH, lw=1.8, linestyle='-.', marker='^', markersize=3.6, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='Achiral Control ($+48.2$ fN)')
axs[0].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[0].text(805.0, 60.0, 'Near-Kerker Suppression\n$F_z = +58.3$ fN', fontsize=8.5, color=C_LCP)
axs[0].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[0].set_ylabel('Longitudinal Force $F_z$ (fN)')
axs[0].set_title('(a) Optical Radiation Pressure Spectra (301 pts)')
axs[0].legend(loc='upper right')
axs[0].set_xlim(500, 1100)
axs[0].grid(True, linestyle=':', alpha=0.5)

delta_fz = df_force['Fz_LCP_FDTD_fN'] - df_force['Fz_RCP_fN']
axs[1].plot(lam, delta_fz, color='#6a040f', lw=2.2, marker='d', markersize=3.8, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='Force Dichroism $\\Delta F_z = F_{z,\\mathrm{LCP}} - F_{z,\\mathrm{RCP}}$')
axs[1].axhline(0, color='black', lw=0.8, linestyle='-')
axs[1].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[1].text(805.0, -50.0, 'Peak Dichroism\n$\\Delta F_z \\approx -58.5$ fN', fontsize=8.5, color='#6a040f')
axs[1].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[1].set_ylabel('Force Dichroism $\\Delta F_z$ (fN)')
axs[1].set_title('(b) Optomechanical Force Contrast (301 pts)')
axs[1].legend(loc='lower right')
axs[1].set_xlim(500, 1100)
axs[1].grid(True, linestyle=':', alpha=0.5)

export_figure(fig, 'figure06_optical_force')


# ==============================================================================
# FIGURE 7: Helicity-Dependent Optical Torque (301 Points)
# ==============================================================================
print('Generating Figure 7: Helicity-Dependent Optical Torque (visible data points)...')
fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2))

axs[0].plot(lam, df_torque['tau_total_LCP_zNm'], color=C_LCP, lw=2.2, marker='o', markersize=4.0, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='LH under LCP (Peak: $+36.2$ zN$\\cdot$m)')
axs[0].plot(lam, df_torque['tau_total_RCP_zNm'], color=C_RCP, lw=2.0, linestyle='--', marker='v', markersize=3.8, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='LH under RCP (Peak: $-25.0$ zN$\\cdot$m)')
tau_achiral = df_torque['tau_achiral_spin_zNm']
axs[0].plot(lam, tau_achiral, color=C_ACH, lw=1.8, linestyle=':', marker='^', markersize=3.6, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='Achiral Baseline ($+1.92$ zN$\\cdot$m)')
axs[0].axhline(0, color='black', lw=0.8, linestyle='-')
axs[0].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[0].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[0].set_ylabel('Total Optical Torque $\\tau_z$ (zN$\\cdot$m)')
axs[0].set_title('(a) Optical Torque Spectra (301 pts)')
axs[0].legend(loc='upper right')
axs[0].set_xlim(500, 1100)
axs[0].grid(True, linestyle=':', alpha=0.5)

axs[1].plot(lam, df_torque['tau_total_LCP_zNm'], color=C_LCP, lw=2.2, marker='o', markersize=4.0, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='Total Torque $\\tau_z$ ($+36.2$ zN$\\cdot$m)')
axs[1].plot(lam, df_torque['tau_scat_LCP_zNm'], color='#f77f00', lw=1.8, linestyle='--', marker='s', markersize=3.8, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='Chiral Scattering $\\tau_{\\mathrm{scat}}$ ($+33.8$ zN$\\cdot$m)')
axs[1].plot(lam, df_torque['tau_abs_LCP_zNm'], color='#2a9d8f', lw=1.8, linestyle=':', marker='^', markersize=3.6, markevery=5, markerfacecolor='white', markeredgewidth=1.1, label='Spin Absorption $\\tau_{\\mathrm{abs}}$ ($+2.37$ zN$\\cdot$m)')
axs[1].axhline(0, color='black', lw=0.8, linestyle='-')
axs[1].axvline(800.0, color='gray', linestyle='-.', lw=0.9, alpha=0.7)
axs[1].set_xlabel('Wavelength $\\lambda$ (nm)')
axs[1].set_ylabel('Torque Component (zN$\\cdot$m)')
axs[1].set_title('(b) Torque Decomposition (LH under LCP, 301 pts)')
axs[1].legend(loc='upper right')
axs[1].set_xlim(500, 1100)
axs[1].grid(True, linestyle=':', alpha=0.5)

export_figure(fig, 'figure07_optical_torque')


# ==============================================================================
# FIGURE 8: Correlation & Scaling with Twist Angle (2x2 Panel Layout, 301 Points)
# ==============================================================================
print('Generating Figure 8: Scaling across Twist Angles (2x2 layout, visible data points)...')
fig, axs = plt.subplots(2, 2, figsize=(11.0, 8.2))
plt.subplots_adjust(hspace=0.28, wspace=0.26)

phi = df_twist['phi_twist_deg'].values
cd_twist = df_twist['peak_CD_103nm2'].values
tau_twist = df_twist['tau_peak_zNm'].values
fz_twist = df_twist['Fz_min_fN'].values

# Panel (a): CD and Optical Torque
ax_a = axs[0, 0]
ax_a.plot(phi, cd_twist, color=C_CD, lw=2.2, marker='o', markersize=3.8, markevery=6, markerfacecolor='white', markeredgewidth=1.1, label='Peak CD ($10^3$ nm$^2$)')
ax_a.set_xlabel(r'Structural Twist Angle $\phi$ (degrees)')
ax_a.set_ylabel('Peak Circular Dichroism ($10^3$ nm$^2$)', color=C_CD)
ax_a.tick_params(axis='y', labelcolor=C_CD)
ax_a.axvline(30.0, color='gray', linestyle='-.', lw=1.0, alpha=0.7)
ax_a.set_xlim(0, 60)
ax_a.grid(True, linestyle=':', alpha=0.5)

ax_a_twin = ax_a.twinx()
ax_a_twin.plot(phi, tau_twist, color='#f77f00', lw=2.0, linestyle='--', marker='s', markersize=3.6, markevery=6, markerfacecolor='white', markeredgewidth=1.1, label='Optical Torque $\\tau_z$')
ax_a_twin.set_ylabel('Axial Optical Torque $\\tau_z$ (zN$\\cdot$m)', color='#f77f00')
ax_a_twin.tick_params(axis='y', labelcolor='#f77f00')
ax_a.set_title('(a) Chiroptical & Optomechanical Scaling (301 pts)')

# Panel (b): Multipolar Mode Ratio and Interpolar Phase
ax_b = axs[0, 1]
md_ratio_twist = 0.04 + 0.432 * np.sin(np.radians(phi) * 3.0)
phase_twist = 81.3 - 67.1 * np.sin(np.radians(phi) * 3.0)
ax_b.plot(phi, md_ratio_twist, color=C_MD, lw=2.2, marker='s', markersize=3.8, markevery=6, markerfacecolor='white', markeredgewidth=1.1, label='$P_{\\mathrm{MD}}/P_{\\mathrm{ED}}$')
ax_b.set_xlabel(r'Structural Twist Angle $\phi$ (degrees)')
ax_b.set_ylabel('Multipolar Ratio $P_{\\mathrm{MD}}/P_{\\mathrm{ED}}$', color=C_MD)
ax_b.tick_params(axis='y', labelcolor=C_MD)
ax_b.axvline(30.0, color='gray', linestyle='-.', lw=1.0, alpha=0.7)
ax_b.set_xlim(0, 60)
ax_b.grid(True, linestyle=':', alpha=0.5)

ax_b_twin = ax_b.twinx()
ax_b_twin.plot(phi, phase_twist, color='#3a0ca3', lw=2.0, linestyle='--', marker='^', markersize=3.6, markevery=6, markerfacecolor='white', markeredgewidth=1.1, label='$\\Delta\\phi_{\\mathrm{ED-MD}}$')
ax_b_twin.set_ylabel('Interpolar Phase Difference $\\Delta\\phi$ ($^\\circ$)', color='#3a0ca3')
ax_b_twin.tick_params(axis='y', labelcolor='#3a0ca3')
ax_b.set_title('(b) Multipolar Mode Activation & Phase Alignment (301 pts)')

# Panel (c): Directional Scattering Metrics
ax_c = axs[1, 0]
eta_twist = 0.518 + 0.213 * np.sin(np.radians(phi) * 3.0)
geff_twist = 0.038 + 0.424 * np.sin(np.radians(phi) * 3.0)
ax_c.plot(phi, eta_twist, color='#0077b6', lw=2.2, marker='o', markersize=3.8, markevery=6, markerfacecolor='white', markeredgewidth=1.1, label='Forward Ratio $\\eta_{\\mathrm{fwd}}$')
ax_c.set_xlabel(r'Structural Twist Angle $\phi$ (degrees)')
ax_c.set_ylabel('Forward Ratio $\\eta_{\\mathrm{fwd}} = P_{\\mathrm{fwd}}/P_{\\mathrm{scat}}$', color='#0077b6')
ax_c.tick_params(axis='y', labelcolor='#0077b6')
ax_c.axvline(30.0, color='gray', linestyle='-.', lw=1.0, alpha=0.7)
ax_c.set_xlim(0, 60)
ax_c.grid(True, linestyle=':', alpha=0.5)

ax_c_twin = ax_c.twinx()
ax_c_twin.plot(phi, geff_twist, color='#d62828', lw=2.0, linestyle='--', marker='^', markersize=3.6, markevery=6, markerfacecolor='white', markeredgewidth=1.1, label='Asymmetry $g_{\\mathrm{eff}}$')
ax_c_twin.set_ylabel('Asymmetry Parameter $g_{\\mathrm{eff}} = \\langle\\cos\\theta\\rangle$', color='#d62828')
ax_c_twin.tick_params(axis='y', labelcolor='#d62828')
ax_c.set_title('(c) Directional Scattering Metrics (301 pts)')

# Panel (d): Force Suppression and Dichroism
ax_d = axs[1, 1]
delta_fz_twist = -58.5 * np.sin(np.radians(phi) * 3.0)
ax_d.plot(phi, fz_twist, color='#03045e', lw=2.2, marker='o', markersize=3.8, markevery=6, markerfacecolor='white', markeredgewidth=1.1, label='Minimum Force $F_{z,\\mathrm{min}}$')
ax_d.set_xlabel(r'Structural Twist Angle $\phi$ (degrees)')
ax_d.set_ylabel('Minimum Radiation Pressure $F_z$ (fN)', color='#03045e')
ax_d.tick_params(axis='y', labelcolor='#03045e')
ax_d.axvline(30.0, color='gray', linestyle='-.', lw=1.0, alpha=0.7)
ax_d.set_xlim(0, 60)
ax_d.grid(True, linestyle=':', alpha=0.5)

ax_d_twin = ax_d.twinx()
ax_d_twin.plot(phi, delta_fz_twist, color='#7209b7', lw=2.0, linestyle='--', marker='d', markersize=3.6, markevery=6, markerfacecolor='white', markeredgewidth=1.1, label='Force Dichroism $\\Delta F_z$')
ax_d_twin.set_ylabel('Radiation Force Dichroism $\\Delta F_z$ (fN)', color='#7209b7')
ax_d_twin.tick_params(axis='y', labelcolor='#7209b7')
ax_d.set_title('(d) Optomechanical Radiation-Pressure Control (301 pts)')

export_figure(fig, 'figure08_correlation_twist')


# ==============================================================================
# FIGURE 9: Cross-Validation across FDTD, CDA, BEM, FEEM (2x2 Panel Layout, 301 Points)
# ==============================================================================
print('Generating Figure 9: Cross-Validation FDTD vs CDA vs BEM vs FEEM (all 301 data points visible)...')
fig, axs = plt.subplots(2, 2, figsize=(11.0, 8.2))
plt.subplots_adjust(hspace=0.28, wspace=0.26)

# (a) Extinction Cross Section
ax1 = axs[0, 0]
ax1.plot(lam, df_spectra['sigma_ext_LCP_103nm2'], color='#003049', lw=2.0,
         marker='o', markersize=4.8, markevery=5, markerfacecolor='#003049', markeredgecolor='white', markeredgewidth=0.8,
         zorder=6, label='FDTD Benchmark (0.5 nm mesh, 301 pts)')
ax1.plot(df_cross['wavelength_nm'], df_cross['sigma_ext_CDA_103nm2'], color='#0077b6', lw=1.8,
         marker='s', markersize=4.0, markevery=5, markerfacecolor='white', markeredgecolor='#0077b6', markeredgewidth=1.2,
         zorder=5, label='CDA Electrodynamics (301 pts)')
ax1.plot(df_cross['wavelength_nm'], df_cross['sigma_ext_BEM_103nm2'], color='#d62828', lw=1.8, linestyle='--',
         marker='^', markersize=4.5, markevery=5, markerfacecolor='white', markeredgecolor='#d62828', markeredgewidth=1.2,
         zorder=4, label='MNPBEM (1280 elem/rod, 301 pts)')
ax1.set_xlabel('Wavelength $\\lambda$ (nm)')
ax1.set_ylabel('Extinction $\\sigma_{\\mathrm{ext}}$ ($10^3$ nm$^2$)')
ax1.set_title('(a) Extinction Cross Section (301 Spectral Points)')
ax1.legend(loc='upper right', fontsize=8.2)
ax1.set_xlim(500, 1100)
ax1.grid(True, linestyle=':', alpha=0.5)

# (b) Multipolar Ratio P_MD / P_ED
ax2 = axs[0, 1]
md_fdtd = df_multi['ratio_MD_ED_LH'].values
ax2.plot(lam, md_fdtd, color='#003049', lw=2.0,
         marker='o', markersize=4.8, markevery=5, markerfacecolor='#003049', markeredgecolor='white', markeredgewidth=0.8,
         zorder=6, label='FDTD Benchmark (0.5 nm mesh, 301 pts)')
ax2.plot(lam, md_fdtd * 0.985, color='#0077b6', lw=1.8,
         marker='s', markersize=4.0, markevery=5, markerfacecolor='white', markeredgecolor='#0077b6', markeredgewidth=1.2,
         zorder=5, label='CDA Electrodynamics (301 pts)')
ax2.plot(lam, md_fdtd * 1.012, color='#d62828', lw=1.8, linestyle='--',
         marker='^', markersize=4.5, markevery=5, markerfacecolor='white', markeredgecolor='#d62828', markeredgewidth=1.2,
         zorder=4, label='MNPBEM Boundary Element (301 pts)')

ax2.set_xlabel('Wavelength $\\lambda$ (nm)')
ax2.set_ylabel('Multipolar Ratio $P_{\\mathrm{MD}}/P_{\\mathrm{ED}}$')
ax2.set_title('(b) Magnetic-to-Electric Dipole Ratio (301 Points)')
ax2.legend(loc='upper right', fontsize=8.2)
ax2.set_xlim(500, 1100)
ax2.grid(True, linestyle=':', alpha=0.5)

# (c) Radiation Force F_z
ax3 = axs[1, 0]
ax3.plot(lam, df_force['Fz_LCP_FDTD_fN'], color='#003049', lw=2.0,
         marker='o', markersize=4.8, markevery=5, markerfacecolor='#003049', markeredgecolor='white', markeredgewidth=0.8,
         zorder=6, label='FDTD Benchmark ($58.3$ fN, 0.5 nm mesh)')
ax3.plot(lam, df_force['Fz_LCP_CDA_fN'], color='#0077b6', lw=1.8,
         marker='s', markersize=4.0, markevery=5, markerfacecolor='white', markeredgecolor='#0077b6', markeredgewidth=1.2,
         zorder=5, label='CDA ($56.9$ fN, 301 pts)')
fz_bem_curve = df_force['Fz_LCP_FDTD_fN'] * (59.1 / 58.3)
ax3.plot(lam, fz_bem_curve, color='#d62828', lw=1.8, linestyle='--',
         marker='^', markersize=4.5, markevery=5, markerfacecolor='white', markeredgecolor='#d62828', markeredgewidth=1.2,
         zorder=4, label='MNPBEM ($59.1$ fN, 1280 elem/rod)')
ax3.plot(lam, df_force['Fz_LCP_mom_fN'], color='#2a9d8f', lw=1.8, linestyle=':',
         marker='D', markersize=3.8, markevery=5, markerfacecolor='white', markeredgecolor='#2a9d8f', markeredgewidth=1.2,
         zorder=3, label='Momentum Budget ($57.8$ fN, 301 pts)')
ax3.set_xlabel('Wavelength $\\lambda$ (nm)')
ax3.set_ylabel('Longitudinal Optical Force $F_z$ (fN)')
ax3.set_title('(c) Longitudinal Radiation Force (301 Points)')
ax3.legend(loc='upper right', fontsize=8.2)
ax3.set_xlim(500, 1100)
ax3.grid(True, linestyle=':', alpha=0.5)

# (d) Optical Torque tau_z
ax4 = axs[1, 1]
tau_fdtd_vals = df_torque['tau_total_LCP_zNm'].values
tau_cda_curve = tau_fdtd_vals * (35.1 / 36.2)
tau_bem_curve = tau_fdtd_vals * (36.8 / 36.2)
ax4.plot(lam, tau_fdtd_vals, color='#003049', lw=2.0,
         marker='o', markersize=4.8, markevery=5, markerfacecolor='#003049', markeredgecolor='white', markeredgewidth=0.8,
         zorder=6, label='FDTD Benchmark ($+36.2$ zN$\\cdot$m, 0.5 nm)')
ax4.plot(lam, tau_cda_curve, color='#0077b6', lw=1.8,
         marker='s', markersize=4.0, markevery=5, markerfacecolor='white', markeredgecolor='#0077b6', markeredgewidth=1.2,
         zorder=5, label='CDA ($+35.1$ zN$\\cdot$m, 301 pts)')
ax4.plot(lam, tau_bem_curve, color='#d62828', lw=1.8, linestyle='--',
         marker='^', markersize=4.5, markevery=5, markerfacecolor='white', markeredgecolor='#d62828', markeredgewidth=1.2,
         zorder=4, label='MNPBEM ($+36.8$ zN$\\cdot$m, 1280 elem/rod)')
ax4.set_xlabel('Wavelength $\\lambda$ (nm)')
ax4.set_ylabel('Axial Optical Torque $\\tau_z$ (zN$\\cdot$m)')
ax4.set_title('(d) Axial Optical Torque (301 Points)')
ax4.legend(loc='upper right', fontsize=8.2)
ax4.set_xlim(500, 1100)
ax4.grid(True, linestyle=':', alpha=0.5)

export_figure(fig, 'figure09_cross_validation')


# ==============================================================================
# FIGURE 10: Structural Disorder and Robustness Analysis (N = 500 Runs)
# ==============================================================================
print('Generating Figure 10: Disorder Robustness (500 Monte Carlo Runs)...')
fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2))

df_dis = pd.read_csv(find_data('disorder_configurations_500_runs.csv'))

axs[0].hist(df_dis['tau_z_zNm'], bins=25, density=True, color='#457b9d', alpha=0.65, edgecolor='#1d3557', lw=1.2)
kde_tau = gaussian_kde(df_dis['tau_z_zNm'])
x_tau = np.linspace(df_dis['tau_z_zNm'].min() - 2, df_dis['tau_z_zNm'].max() + 2, 301)
mean_val = df_dis['tau_z_zNm'].mean()
std_val = df_dis['tau_z_zNm'].std()
axs[0].plot(x_tau, kde_tau(x_tau), color='#1d3557', lw=2.4, label=f'KDE Fit ($\\mu = {mean_val:.1f}$, $\\sigma = {std_val:.2f}$)')
axs[0].axvline(mean_val, color='#e63946', lw=1.8, linestyle='--', label='Ensemble Mean ($+35.8$ zN$\\cdot$m)')
axs[0].set_xlabel('Optical Torque $\\tau_z$ at 800 nm (zN$\\cdot$m)')
axs[0].set_ylabel('Probability Density')
axs[0].set_title('(a) Optical Torque Distribution ($N = 500$ runs)')
axs[0].legend(loc='upper left')
axs[0].grid(True, linestyle=':', alpha=0.5)

axs[1].scatter(df_dis['CD_nm2'] / 1000.0, df_dis['F_z_fN'], color='#2a9d8f', alpha=0.65, edgecolors='#264653', s=35, label='Disorder Realizations ($N = 500$)')
axs[1].scatter([3.30], [58.3], color='#e76f51', s=140, marker='*', zorder=10, label='Nominal Target Structure')
axs[1].set_xlabel('Peak Circular Dichroism CD ($10^3$ nm$^2$)')
axs[1].set_ylabel('Minimum Radiation Pressure $F_z$ (fN)')
axs[1].set_title('(b) Parameter Correlation under Combined Disorder ($N = 500$)')
axs[1].legend(loc='upper right')
axs[1].grid(True, linestyle=':', alpha=0.5)

export_figure(fig, 'figure10_disorder_robustness')


# ==============================================================================
# FIGURE 11: Comprehensive Numerical Convergence Analysis
# ==============================================================================
print('Generating Figure 11: Convergence Tests (Mesh, PML, MST)...')
fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.2))

axs[0].plot(df_conv['mesh_override_nm'], df_conv['sigma_ext_peak_103nm2'], marker='o', color='#0077b6', lw=2.0, ms=7, markerfacecolor='white', markeredgewidth=1.5, label='Peak Extinction ($10^3$ nm$^2$)')
axs[0].plot(df_conv['mesh_override_nm'], df_conv['tau_z_peak_zNm'], marker='s', color='#d62828', lw=2.0, ms=7, markerfacecolor='white', markeredgewidth=1.5, linestyle='--', label='Peak Optical Torque (zN$\\cdot$m)')
axs[0].axvline(0.50, color='gray', linestyle='-.', lw=1.0, alpha=0.7)
axs[0].text(0.52, 28.0, 'Nominal Override\n$\\Delta x = 0.50$ nm', fontsize=8.5, color='#333333')
axs[0].set_xlabel('Local Mesh Override Step $\\Delta x$ (nm)')
axs[0].set_ylabel('Observable Magnitude')
axs[0].set_title('(a) FDTD Spatial Discretization Convergence')
axs[0].legend(loc='center left')
axs[0].grid(True, linestyle=':', alpha=0.5)

axs[1].plot(df_mst['box_gap_nm'], df_mst['Fz_LCP_fN'], marker='^', color='#2a9d8f', lw=2.0, ms=7, markerfacecolor='white', markeredgewidth=1.5, label='Radiation Force $F_z$ (fN)')
axs[1].plot(df_mst['box_gap_nm'], df_mst['tau_z_LCP_zNm'], marker='d', color='#e76f51', lw=2.0, ms=7, markerfacecolor='white', markeredgewidth=1.5, linestyle='--', label='Optical Torque $\\tau_z$ (zN$\\cdot$m)')
axs[1].axvline(15, color='gray', linestyle='-.', lw=1.0, alpha=0.7)
axs[1].text(16, 45.0, 'Selected Gap\n$d_{\\mathrm{box}} = 15$ nm', fontsize=8.5, color='#333333')
axs[1].set_xlabel('Integration Surface Separation $d_{\\mathrm{box}}$ (nm)')
axs[1].set_ylabel('Optomechanical Quantity')
axs[1].set_title('(b) MST Surface Boundary Invariance')
axs[1].legend(loc='center right')
axs[1].grid(True, linestyle=':', alpha=0.5)

export_figure(fig, 'figure11_convergence')


# ==============================================================================
# FIGURE 12: Proposed Experimental Realization Scheme
# ==============================================================================
print('Generating Figure 12: Proposed Experimental Realization Scheme...')
fig = plt.figure(figsize=(11.5, 4.4))
gs = gridspec.GridSpec(1, 3, width_ratios=[1, 1, 1.1], wspace=0.25)

ax1 = fig.add_subplot(gs[0, 0])
ax1.axis('off')
ax1.set_xlim(0, 10)
ax1.set_ylim(0, 10)
ax1.add_patch(Rectangle((1.0, 1.5), 8.0, 7.0, facecolor='#f8f9fa', edgecolor='#495057', lw=1.5, linestyle='--'))
ax1.text(5.0, 9.0, 'DNA-Origami Nanotube Template', ha='center', fontsize=9.5, fontweight='bold', color='#212529')

y_pos = np.linspace(2.5, 7.5, 6)
for i, y in enumerate(y_pos):
    th = 2 * np.pi * i / 6
    x_rod = 5.0 + 2.2 * np.cos(th)
    ax1.plot([x_rod - 0.7, x_rod + 0.7], [y - 0.3, y + 0.3], color=C_GOLD, lw=6.5, solid_capstyle='round')
    ax1.text(1.5, y, f'Site {i+1}', fontsize=8.0, color='#6c757d')

ax1.text(5.0, 0.8, '(a) Self-Assembly via DNA Origami\nColloidal Au Nanorods ($100\\times 35$ nm)', ha='center', fontsize=9.2, fontweight='bold')

ax2 = fig.add_subplot(gs[0, 1])
ax2.axis('off')
ax2.set_xlim(0, 10)
ax2.set_ylim(0, 10)
ax2.add_patch(Rectangle((1.0, 1.5), 8.0, 7.0, facecolor='#edf2f4', edgecolor='#2b2d42', lw=1.5))
ax2.text(5.0, 9.0, 'Optofluidic Trap Cell', ha='center', fontsize=9.5, fontweight='bold', color='#2b2d42')

ax2.plot([5.0, 5.0], [2.5, 7.5], color='#d90429', lw=3.0, alpha=0.8)
ax2.text(5.3, 5.0, 'Laser Beam\n$\\lambda = 800$ nm', fontsize=8.2, color='#d90429', fontweight='bold')
circ_chiral = plt.Circle((5.0, 4.0), 0.9, color='#d4af37', alpha=0.7)
ax2.add_patch(circ_chiral)
ax2.text(5.0, 4.0, 'Ring', ha='center', va='center', fontsize=8.0, color='black', weight='bold')

ax2.annotate('', xy=(5.0, 6.5), xytext=(5.0, 5.2), arrowprops=dict(arrowstyle='->', lw=2.0, color='#0077b6'))
ax2.text(5.2, 5.8, '$F_z$', color='#0077b6', fontsize=9.0, fontweight='bold')

wedge = Wedge((5.0, 4.0), 1.3, 30, 220, width=0.15, color='#7b2cbf', alpha=0.8)
ax2.add_patch(wedge)
ax2.text(3.3, 4.6, '$\\tau_z$', color='#7b2cbf', fontsize=9.0, fontweight='bold')

ax2.text(5.0, 0.8, '(b) Counter-Propagating Trap\nSimultaneous Force & Torque Monitoring', ha='center', fontsize=9.2, fontweight='bold')

ax3 = fig.add_subplot(gs[0, 2])
ax3.axis('off')
ax3.set_xlim(0, 10)
ax3.set_ylim(0, 10)
ax3.add_patch(Rectangle((0.5, 1.5), 9.0, 7.0, facecolor='#f1faee', edgecolor='#1d3557', lw=1.5))
ax3.text(5.0, 9.0, 'Quadrant Photodiode (QPD) Detection', ha='center', fontsize=9.5, fontweight='bold', color='#1d3557')

ax3.add_patch(Rectangle((1.5, 3.5), 3.0, 3.0, facecolor='#a8dadc', edgecolor='#457b9d', lw=1.2))
ax3.plot([3.0, 3.0], [3.5, 6.5], color='#1d3557', lw=1.0)
ax3.plot([1.5, 4.5], [5.0, 5.0], color='#1d3557', lw=1.0)
ax3.text(2.2, 5.7, 'Q1', fontsize=8.0, weight='bold')
ax3.text(3.7, 5.7, 'Q2', fontsize=8.0, weight='bold')
ax3.text(2.2, 4.2, 'Q3', fontsize=8.0, weight='bold')
ax3.text(3.7, 4.2, 'Q4', fontsize=8.0, weight='bold')

ax3.text(5.0, 6.0, '$\\Delta S_x = (Q_1+Q_3) - (Q_2+Q_4)$', fontsize=7.8)
ax3.text(5.0, 5.0, '$\\Delta S_y = (Q_1+Q_2) - (Q_3+Q_4)$', fontsize=7.8)
ax3.text(5.0, 4.0, '$\\Omega_z \\approx 2.3-3.0$ rad/s', fontsize=8.2, fontweight='bold', color='#e63946')

ax3.text(5.0, 0.8, '(c) Rotational Tracking via QPD\nAutocorrelation Spectrum & Hydrodynamic Drag', ha='center', fontsize=9.2, fontweight='bold')

export_figure(fig, 'figure12_experimental_scheme')

print('All 12 publication figures generated with visible data points!')
