"""
Generate explicit CAD coordinate models for LH, RH, and Achiral assemblies
as referenced in the manuscript, SI, and GitHub repository.
"""

import os
import numpy as np
import pandas as pd

def generate_coordinates(phi_deg):
    Rc = 120.0  # nm
    L = 100.0   # nm
    d = 35.0    # nm
    N = 6
    
    phi = np.deg2rad(phi_deg)
    
    rows = []
    for j in range(N):
        theta_j = j * (2 * np.pi / N)
        # Center of mass
        cx = Rc * np.cos(theta_j)
        cy = Rc * np.sin(theta_j)
        cz = 0.0
        
        # Unit director vector
        ux = -np.cos(phi) * np.sin(theta_j)
        uy =  np.cos(phi) * np.cos(theta_j)
        uz =  np.sin(phi)
        
        # Tip 1 (+) and Tip 2 (-)
        t1x = cx + 0.5 * L * ux
        t1y = cy + 0.5 * L * uy
        t1z = cz + 0.5 * L * uz
        
        t2x = cx - 0.5 * L * ux
        t2y = cy - 0.5 * L * uy
        t2z = cz - 0.5 * L * uz
        
        rows.append({
            'rod_index': j + 1,
            'azimuth_deg': round(np.rad2deg(theta_j), 1),
            'center_x_nm': round(cx, 3),
            'center_y_nm': round(cy, 3),
            'center_z_nm': round(cz, 3),
            'dir_ux': round(ux, 5),
            'dir_uy': round(uy, 5),
            'dir_uz': round(uz, 5),
            'tip1_x_nm': round(t1x, 3),
            'tip1_y_nm': round(t1y, 3),
            'tip1_z_nm': round(t1z, 3),
            'tip2_x_nm': round(t2x, 3),
            'tip2_y_nm': round(t2y, 3),
            'tip2_z_nm': round(t2z, 3),
            'length_nm': L,
            'diameter_nm': d
        })
    return pd.DataFrame(rows)

for base_dir in ['data/CAD', 'CAD', '13_GitHub/CAD']:
    os.makedirs(base_dir, exist_ok=True)
    df_lh = generate_coordinates(+30.0)
    df_rh = generate_coordinates(-30.0)
    df_ach = generate_coordinates(0.0)
    
    df_lh.to_csv(os.path.join(base_dir, 'lh_enantiomer_coordinates.csv'), index=False)
    df_rh.to_csv(os.path.join(base_dir, 'rh_enantiomer_coordinates.csv'), index=False)
    df_ach.to_csv(os.path.join(base_dir, 'achiral_control_coordinates.csv'), index=False)

print("Generated CAD coordinate models in data/CAD, CAD, and 13_GitHub/CAD successfully.")
