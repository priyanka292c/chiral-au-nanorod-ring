# Declaration of Generative AI and AI-Assisted Technologies in the Writing Process
## Author Consent & Compliance Declaration

**Journal:** *Journal of the Optical Society of America B* (JOSA B)  
**Publisher:** Optica Publishing Group  
**Manuscript Title:** *Helicity-Selective Multipolar Interference Governs Optical Force and Torque in Structurally Chiral Plasmonic Nanorod Rings*  
**Authors:** Priyanka$^1$ and Ram Soorat$^2$  
$^1$*Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India*  
$^2$*School of Technology, Woxsen University, Hyderabad 502345, Telangana, India*  
**Corresponding Author:** Ram Soorat (`rsoorat@gmail.com`)  
**Date of Declaration:** 21 October 2026  

---

### 1. Compliance with Optica Publishing Group Policy

In accordance with the **Optica Publishing Group Policy on Generative AI and Large Language Models (LLMs)**:

1. **Non-Authorship of AI:** Generative AI tools and large language models do not qualify for authorship. No AI technology is listed as an author or co-author.
2. **Mandatory Disclosure:** The authors formally disclose the specific scope and nature of AI tools used in the preparation of this manuscript.
3. **Human Authorship & Accountability:** The authors have thoroughly reviewed and edited the manuscript content, verify all scientific results, equations, models, and references, and take full and sole intellectual, technical, and ethical responsibility for the content of the published article.

---

### 2. Statement of AI Usage

> **Declaration on the Use of Artificial Intelligence and Author Consent:**  
> During the preparation of this manuscript, the authors utilized AI-assisted technologies solely for stylistic language refinement, grammatical editing, typography template formatting, and automation script documentation under direct author supervision. 
>
> All core physical hypotheses, theoretical derivations, electromagnetic simulations (FDTD, CDA, and MNPBEM), multipolar decompositions, Maxwell stress tensor evaluations, and 500-sample Monte Carlo disorder calculations were conceived, configured, executed, and validated by the human authors from authentic numerical data. No generative AI tools were used to fabricate or manipulate research data, generate physical interpretations, or synthesize conclusions.

---

### 3. Formal Author Consent and Approval

Both authors give formal, unanimous consent to this declaration and confirm that:
- The manuscript represents original research not published or under review elsewhere.
- All 85 bibliographic references cite peer-reviewed Versions of Record with resolving digital object identifiers (DOIs).
- All simulation scripts, CAD models, and processed datasets are publicly available in the referenced GitHub repository.

| Author Name | Role | Affiliation | Consent Status | Date |
| :--- | :--- | :--- | :--- | :--- |
| **Priyanka** | First Author | University of Delhi, India | **Approved & Consented** | 21 October 2026 |
| **Ram Soorat** | Corresponding Author | Woxsen University, India | **Approved & Consented** | 21 October 2026 |

---
*This declaration complies with Optica Publishing Group's Guidelines Concerning Ethical Practices in the Publication of Research and the Committee on Publication Ethics (COPE) position on AI tools.*
