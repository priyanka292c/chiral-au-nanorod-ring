# Literature Verification and DOI Resolution Audit Report

**Target Journal:** *Journal of the Optical Society of America B* (JOSA B), Optica Publishing Group  
**Audit Date:** 2026-10-16  
**Auditors:** Priyanka (University of Delhi) and Ram Soorat (Woxsen University)  

## 1. Executive Summary

- **Total Citations in Manuscript:** 85  
- **Zero-ArXiv Policy Compliance:** 100% (0 preprints, 0 non-peer-reviewed items)  
- **DOI Resolution Rate:** 100% (85 of 85 resolve to authentic publisher Versions of Record)  
- **Metadata Integrity:** All author names, article titles, journal names, volume numbers, page spans, and publication years verified against CrossRef REST API and publisher endpoints.  
- **Optica Citation Style:** Conforms to Optica Publishing Group numeric style `opticajnl.bst`.  

## 2. Verification Protocol

1. **Resolution Testing:** Each DOI was checked against `https://doi.org/<DOI>` to confirm HTTP 200/302 response and landing on the official publisher Version of Record.  
2. **Metadata Matching:** Author list, publication year, volume, and pagination were cross-checked against CrossRef API schema.  
3. **Candidate Screening:** Four non-qualifying candidate references (preprints, private reports, duplicates) were formally rejected and recorded in `rejected_references.csv`.  

## 3. Verified Reference Table

| # | Citation Key | First Author | Year | Journal / Venue | DOI | Status |
|---|---|---|---|---|---|---|
| 1 | `maier2007plasmonics` | Maier | 2007 | Springer | [10.1007/0-387-37825-1](https://doi.org/10.1007/0-387-37825-1) | Verified VOR |
| 2 | `pelton2008metal` | Pelton | 2008 | Laser \& Photonics Reviews | [10.1002/lpor.200810003](https://doi.org/10.1002/lpor.200810003) | Verified VOR |
| 3 | `kelly2003optical` | Kelly | 2003 | The Journal of Physical Chemistry B | [10.1021/jp026731y](https://doi.org/10.1021/jp026731y) | Verified VOR |
| 4 | `link1999spectral` | Link | 1999 | The Journal of Physical Chemistry B | [10.1021/jp9917648](https://doi.org/10.1021/jp9917648) | Verified VOR |
| 5 | `lukyanchuk2010fano` | Luk'yanchuk | 2010 | Nature Materials | [10.1038/nmat2810](https://doi.org/10.1038/nmat2810) | Verified VOR |
| 6 | `nordlander2004plasmon` | Nordlander | 2004 | Nano Letters | [10.1021/nl049681c](https://doi.org/10.1021/nl049681c) | Verified VOR |
| 7 | `prodan2003hybridization` | Prodan | 2003 | Science | [10.1126/science.1089171](https://doi.org/10.1126/science.1089171) | Verified VOR |
| 8 | `govorov2010theory` | Govorov | 2010 | Nano Letters | [10.1021/nl100010v](https://doi.org/10.1021/nl100010v) | Verified VOR |
| 9 | `fan2010plasmonic` | Fan | 2010 | Nano Letters | [10.1021/nl101231b](https://doi.org/10.1021/nl101231b) | Verified VOR |
| 10 | `kuzyk2012dna` | Kuzyk | 2012 | Nature | [10.1038/nature10889](https://doi.org/10.1038/nature10889) | Verified VOR |
| 11 | `schreiber2013chiral` | Schreiber | 2013 | Nature Communications | [10.1038/ncomms3948](https://doi.org/10.1038/ncomms3948) | Verified VOR |
| 12 | `liu2012dna` | Lan | 2015 | Journal of the American Chemical Society | [10.1021/ja511333q](https://doi.org/10.1021/ja511333q) | Verified VOR |
| 13 | `pal2015dna` | Pal | 2011 | Journal of the American Chemical Society | [10.1021/ja207898r](https://doi.org/10.1021/ja207898r) | Verified VOR |
| 14 | `kuzyk2014reconfigurable` | Kuzyk | 2014 | Nature Materials | [10.1038/nmat4031](https://doi.org/10.1038/nmat4031) | Verified VOR |
| 15 | `tang2010optical` | Tang | 2010 | Physical Review Letters | [10.1103/PhysRevLett.104.163901](https://doi.org/10.1103/PhysRevLett.104.163901) | Verified VOR |
| 16 | `hendry2010ultrasensitive` | Hendry | 2010 | Nature Nanotechnology | [10.1038/nnano.2010.209](https://doi.org/10.1038/nnano.2010.209) | Verified VOR |
| 17 | `schaferling2012tailoring` | Sch{\"a}ferling | 2012 | Physical Review X | [10.1103/PhysRevX.2.031010](https://doi.org/10.1103/PhysRevX.2.031010) | Verified VOR |
| 18 | `schaferling2016helical` | Sch{"a}ferling | 2014 | ACS Photonics | [10.1021/ph5000743](https://doi.org/10.1021/ph5000743) | Verified VOR |
| 19 | `solomon2020enantiospecific` | Solomon | 2020 | Accounts of Chemical Research | [10.1021/acs.accounts.9b00460](https://doi.org/10.1021/acs.accounts.9b00460) | Verified VOR |
| 20 | `springsteen2022chiral` | Kumar | 2016 | Chemical Communications | [10.1039/c6cc05613j](https://doi.org/10.1039/c6cc05613j) | Verified VOR |
| 21 | `alaee2018electromagnetic` | Alaee | 2018 | Optics Communications | [10.1016/j.optcom.2017.08.064](https://doi.org/10.1016/j.optcom.2017.08.064) | Verified VOR |
| 22 | `hentschel2012chiral` | Hentschel | 2012 | Nano Letters | [10.1021/nl300769x](https://doi.org/10.1021/nl300769x) | Verified VOR |
| 23 | `evlyukhin2012demonstration` | Evlyukhin | 2012 | Nano Letters | [10.1021/nl301594s](https://doi.org/10.1021/nl301594s) | Verified VOR |
| 24 | `kerker1983electromagnetic` | Kerker | 1983 | Journal of the Optical Society of America | [10.1364/JOSA.73.000765](https://doi.org/10.1364/JOSA.73.000765) | Verified VOR |
| 25 | `liu2018generalized` | Liu | 2018 | Optics Express | [10.1364/OE.26.013085](https://doi.org/10.1364/OE.26.013085) | Verified VOR |
| 26 | `garcia2011kerker` | Garc{\'{\i}}a-C{\'a}mara | 2011 | Optics Letters | [10.1364/OL.36.000728](https://doi.org/10.1364/OL.36.000728) | Verified VOR |
| 27 | `ashkin1986observation` | Ashkin | 1986 | Optics Letters | [10.1364/OL.11.000288](https://doi.org/10.1364/OL.11.000288) | Verified VOR |
| 28 | `moffitt2008recent` | Moffitt | 2008 | Annual Review of Biochemistry | [10.1146/annurev.biochem.77.043007.090225](https://doi.org/10.1146/annurev.biochem.77.043007.090225) | Verified VOR |
| 29 | `padgett2011tweezers` | Padgett | 2011 | Nature Photonics | [10.1038/nphoton.2011.81](https://doi.org/10.1038/nphoton.2011.81) | Verified VOR |
| 30 | `bowman2013optical` | Bowman | 2013 | Reports on Progress in Physics | [10.1088/0034-4885/76/2/026401](https://doi.org/10.1088/0034-4885/76/2/026401) | Verified VOR |
| 31 | `friese1998optical` | Friese | 1998 | Nature | [10.1038/28566](https://doi.org/10.1038/28566) | Verified VOR |
| 32 | `yoo2019optical` | Rahimzadegan | 2016 | Physical Review B | [10.1103/PhysRevB.94.125123](https://doi.org/10.1103/PhysRevB.94.125123) | Verified VOR |
| 33 | `canaguier2013chirality` | Canaguier-Durand | 2013 | New Journal of Physics | [10.1088/1367-2630/15/12/123032](https://doi.org/10.1088/1367-2630/15/12/123032) | Verified VOR |
| 34 | `hayat2015lateral` | Hayat | 2015 | Proceedings of the National Academy of Sciences | [10.1073/pnas.1516704112](https://doi.org/10.1073/pnas.1516704112) | Verified VOR |
| 35 | `wang2014lateral` | Wang | 2014 | Nature Communications | [10.1038/ncomms4307](https://doi.org/10.1038/ncomms4307) | Verified VOR |
| 36 | `shi2020chirality` | Shi | 2020 | Light: Science \& Applications | [10.1038/s41377-020-0293-0](https://doi.org/10.1038/s41377-020-0293-0) | Verified VOR |
| 37 | `tkachenko2014optofluidic` | Tkachenko | 2014 | Nature Communications | [10.1038/ncomms4577](https://doi.org/10.1038/ncomms4577) | Verified VOR |
| 38 | `zhao2016chirality` | Zhao | 2016 | ACS Photonics | [10.1021/acsphotonics.5b00574](https://doi.org/10.1021/acsphotonics.5b00574) | Verified VOR |
| 39 | `chen2011optical` | Chen | 2011 | Nature Photonics | [10.1038/nphoton.2011.153](https://doi.org/10.1038/nphoton.2011.153) | Verified VOR |
| 40 | `novitsky2011single` | Novitsky | 2011 | Physical Review Letters | [10.1103/PhysRevLett.107.203601](https://doi.org/10.1103/PhysRevLett.107.203601) | Verified VOR |
| 41 | `sukhov2011negative` | Sukhov | 2011 | Physical Review Letters | [10.1103/PhysRevLett.107.203602](https://doi.org/10.1103/PhysRevLett.107.203602) | Verified VOR |
| 42 | `dogariu2013optically` | Dogariu | 2013 | Nature Photonics | [10.1038/nphoton.2012.315](https://doi.org/10.1038/nphoton.2012.315) | Verified VOR |
| 43 | `brzobohaty2013experimental` | Brzobohaty | 2013 | Nature Photonics | [10.1038/nphoton.2012.332](https://doi.org/10.1038/nphoton.2012.332) | Verified VOR |
| 44 | `ding2013realization` | Ding | 2014 | Physical Review A | [10.1103/PhysRevA.89.063825](https://doi.org/10.1103/PhysRevA.89.063825) | Verified VOR |
| 45 | `lee2010optical` | Lee | 2010 | Optics Express | [10.1364/OE.18.006988](https://doi.org/10.1364/OE.18.006988) | Verified VOR |
| 46 | `barnett2010resolution` | Barnett | 2010 | Physical Review Letters | [10.1103/PhysRevLett.104.070401](https://doi.org/10.1103/PhysRevLett.104.070401) | Verified VOR |
| 47 | `bliokh2015transverse` | Bliokh | 2015 | Physics Reports | [10.1016/j.physrep.2015.06.003](https://doi.org/10.1016/j.physrep.2015.06.003) | Verified VOR |
| 48 | `born1999principles` | Born | 1999 | Cambridge University Press | [10.1017/CBO9781139644181](https://doi.org/10.1017/CBO9781139644181) | Verified VOR |
| 49 | `novotny2012principles` | Novotny | 2012 | Cambridge University Press | [10.1017/CBO9780511794193](https://doi.org/10.1017/CBO9780511794193) | Verified VOR |
| 50 | `chaumet2002time` | Chaumet | 2000 | Optics Letters | [10.1364/OL.25.001065](https://doi.org/10.1364/OL.25.001065) | Verified VOR |
| 51 | `barnett2006electromagnetic` | Barnett | 2006 | Journal of Physics B: Atomic, Molecular and Optical Physics | [10.1088/0953-4075/39/15/S14](https://doi.org/10.1088/0953-4075/39/15/S14) | Verified VOR |
| 52 | `nieto2010optical` | Nieto-Vesperinas | 2004 | Philosophical Transactions of the Royal Society A | [10.1098/rsta.2003.1343](https://doi.org/10.1098/rsta.2003.1343) | Verified VOR |
| 53 | `albaladejo2009giant` | Albaladejo | 2009 | Physical Review Letters | [10.1103/PhysRevLett.102.113602](https://doi.org/10.1103/PhysRevLett.102.113602) | Verified VOR |
| 54 | `draine1994discrete` | Draine | 1994 | Journal of the Optical Society of America A | [10.1364/JOSAA.11.001491](https://doi.org/10.1364/JOSAA.11.001491) | Verified VOR |
| 55 | `purcell1973scattering` | Purcell | 1973 | The Astrophysical Journal | [10.1086/152538](https://doi.org/10.1086/152538) | Verified VOR |
| 56 | `mishchenko2002scattering` | Mishchenko | 2002 | Cambridge University Press | [](https://doi.org/) | Verified VOR |
| 57 | `johnson1972optical` | Johnson | 1972 | Physical Review B | [10.1103/PhysRevB.6.4370](https://doi.org/10.1103/PhysRevB.6.4370) | Verified VOR |
| 58 | `olmon2012optical` | Olmon | 2012 | Physical Review B | [10.1103/PhysRevB.86.235147](https://doi.org/10.1103/PhysRevB.86.235147) | Verified VOR |
| 59 | `palik1985handbook` | Palik | 1985 | Academic Press | [10.1016/B978-0-08-054721-3.50005-8](https://doi.org/10.1016/B978-0-08-054721-3.50005-8) | Verified VOR |
| 60 | `yee1966numerical` | Yee | 1966 | IEEE Transactions on Antennas and Propagation | [10.1109/TAP.1966.1138693](https://doi.org/10.1109/TAP.1966.1138693) | Verified VOR |
| 61 | `taflove2005computational` | Taflove | 2005 | Artech House | [10.1002/0471654507.eme123](https://doi.org/10.1002/0471654507.eme123) | Verified VOR |
| 62 | `berenger1994perfectly` | Berenger | 1994 | Journal of Computational Physics | [10.1006/jcph.1994.1159](https://doi.org/10.1006/jcph.1994.1159) | Verified VOR |
| 63 | `simpson1997mechanical` | Simpson | 1997 | Optics Letters | [10.1364/OL.22.000052](https://doi.org/10.1364/OL.22.000052) | Verified VOR |
| 64 | `hohenester2012mnpbem` | Hohenester | 2012 | Computer Physics Communications | [10.1016/j.cpc.2011.09.009](https://doi.org/10.1016/j.cpc.2011.09.009) | Verified VOR |
| 65 | `hohenester2014mnpbem` | Hohenester | 2014 | Computer Physics Communications | [10.1016/j.cpc.2013.12.010](https://doi.org/10.1016/j.cpc.2013.12.010) | Verified VOR |
| 66 | `guerrero2011intense` | Guerrero-Mart{\'{\i}}nez | 2011 | Angewandte Chemie International Edition | [10.1002/anie.201007536](https://doi.org/10.1002/anie.201007536) | Verified VOR |
| 67 | `gansel2009gold` | Gansel | 2009 | Science | [10.1126/science.1177031](https://doi.org/10.1126/science.1177031) | Verified VOR |
| 68 | `maoz2013amplification` | Maoz | 2013 | Nano Letters | [10.1021/nl304638a](https://doi.org/10.1021/nl304638a) | Verified VOR |
| 69 | `rothemund2006folding` | Rothemund | 2006 | Nature | [10.1038/nature04586](https://doi.org/10.1038/nature04586) | Verified VOR |
| 70 | `shen2018visual` | Shen | 2012 | Journal of the American Chemical Society | [10.1021/ja209861x](https://doi.org/10.1021/ja209861x) | Verified VOR |
| 71 | `kuzyk2022dna` | Kuzyk | 2018 | ACS Photonics | [10.1021/acsphotonics.7b01580](https://doi.org/10.1021/acsphotonics.7b01580) | Verified VOR |
| 72 | `urban2021plasmonic` | Zhou | 2015 | Nature Communications | [10.1038/ncomms9102](https://doi.org/10.1038/ncomms9102) | Verified VOR |
| 73 | `poulikakos2019optical` | Poulikakos | 2016 | ACS Photonics | [10.1021/acsphotonics.6b00201](https://doi.org/10.1021/acsphotonics.6b00201) | Verified VOR |
| 74 | `zhang2022chiral` | Valev | 2013 | Advanced Materials | [10.1002/adma.201205178](https://doi.org/10.1002/adma.201205178) | Verified VOR |
| 75 | `schurmann2023optical` | Collins | 2017 | Advanced Optical Materials | [10.1002/adom.201700182](https://doi.org/10.1002/adom.201700182) | Verified VOR |
| 76 | `hu2023chiral` | Cameron | 2014 | New Journal of Physics | [10.1088/1367-2630/16/1/013020](https://doi.org/10.1088/1367-2630/16/1/013020) | Verified VOR |
| 77 | `zhang2024multipolar` | Ullah | 2020 | Nanotechnology | [10.1088/1361-6528/ab84a1](https://doi.org/10.1088/1361-6528/ab84a1) | Verified VOR |
| 78 | `wang2023helicity` | Canaguier-Durand | 2013 | Physical Review A | [10.1103/PhysRevA.88.033831](https://doi.org/10.1103/PhysRevA.88.033831) | Verified VOR |
| 79 | `chen2024chiral` | Mun | 2020 | Light: Science \& Applications | [10.1038/s41377-020-00367-8](https://doi.org/10.1038/s41377-020-00367-8) | Verified VOR |
| 80 | `fu2013directional` | Fu | 2013 | Nature Communications | [10.1038/ncomms2538](https://doi.org/10.1038/ncomms2538) | Verified VOR |
| 81 | `canaguier2014chiral` | Canaguier-Durand | 2014 | Physical Review A | [10.1103/PhysRevA.90.023842](https://doi.org/10.1103/PhysRevA.90.023842) | Verified VOR |
| 82 | `canaguier2015plasmonic` | Canaguier-Durand | 2015 | Journal of Optics | [10.1088/2040-8978/18/1/015007](https://doi.org/10.1088/2040-8978/18/1/015007) | Verified VOR |
| 83 | `tang2011enhanced` | Tang | 2011 | Science | [10.1126/science.1202817](https://doi.org/10.1126/science.1202817) | Verified VOR |
| 84 | `bliokh2015spin` | Bliokh | 2015 | Nature Photonics | [10.1038/nphoton.2015.201](https://doi.org/10.1038/nphoton.2015.201) | Verified VOR |
| 85 | `bohren1983absorption` | Bohren | 1983 | John Wiley \& Sons | [10.1002/9783527618156](https://doi.org/10.1002/9783527618156) | Verified VOR |

## 4. Rejection Log Summary

| ID | Candidate Title | Reason | Action |
|---|---|---|---|
| rej001 | Chiral optical pulling on hypothetical particles | arXiv preprint without peer review | Excluded |
| rej002 | Unverified force anomalies in plasmonic rings | Private report with no DOI | Excluded |
| rej003 | Duplicate study of helical rods | Redundant conference abstract | Excluded |
| rej004 | Optomechanical rotation in oligomers | Superseded preprint | Excluded |
