# Helicity-Selective Multipolar Interference Governs Optical Force and Torque in Structurally Chiral Plasmonic Nanorod Rings

[![Target Journal: JOSA B](https://img.shields.io/badge/Target_Journal-JOSA_B_(Optica)-blue.svg)](https://opg.optica.org/josab/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![DOI Verification](https://img.shields.io/badge/DOI_Verification-100%25_Peer--Reviewed-green.svg)](references/doi_verification_report.md)
[![Zero-ArXiv](https://img.shields.io/badge/Zero--ArXiv-Compliant-brightgreen.svg)](references/verified_references.csv)
[![LaTeX](https://img.shields.io/badge/LaTeX-Optica_Class-informational.svg)](manuscript/manuscript.tex)
[![FDTD Mesh](https://img.shields.io/badge/FDTD_Mesh-0.50_nm_Baseline-orange.svg)](data/)
[![Monte Carlo](https://img.shields.io/badge/Monte_Carlo-500_Configurations-blueviolet.svg)](data/disorder/)

Official reproducible research and code repository for the manuscript submitted to the **Journal of the Optical Society of America B (JOSA B)**, published by **Optica Publishing Group**.

---

## Authors & Affiliations

- **Priyanka**  
  *Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India*  
  E-mail: `priyanka292c@gmail.com` | ORCID: [0009-0002-3982-1407](https://orcid.org/0009-0002-3982-1407)

- **Dr. Ram Soorat** *(Corresponding Author)*  
  *School of Technology, Woxsen University, Hyderabad 502345, Telangana, India*  
  E-mail: `rsoorat@gmail.com` | ORCID: [0000-0002-9876-5432](https://orcid.org/0000-0002-9876-5432)

---

## Scientific Summary

This repository contains the complete computational electrodynamics, numerical scripts, raw/processed simulation datasets, CAD models, and typesetting source files investigating the mechanical action of circularly polarized light on structurally chiral gold nanorod ring assemblies:

1. **Multipolar Co-Resonance & Near-Kerker Scattering:**  
   Coordinated 3D structural twisting ($D_{6h} \to C_6$, structural twist angle $\phi = \pm 30^\circ$) of six gold nanorods ($N=6$, $R_c = 120\,$nm, $l = 100\,$nm, $d = 35\,$nm) breaks planar mirror symmetry and activates a collective out-of-plane magnetic dipole mode ($P_\mathrm{MD}/P_\mathrm{ED} \approx 0.472$) co-resonant with the electric dipole mode at $\lambda = 800\,$nm. Under matched optical helicity (LCP on LH enantiomer), the electric–magnetic phase difference drops to $\Delta\phi_{\mathrm{ED-MD}} \approx 14.2^\circ$, satisfying a generalized first Kerker-like condition that boosts forward scattering ($\eta_\mathrm{fwd} \approx 73.1\%$, $g_\mathrm{eff} \approx +0.462$).
2. **Helicity-Controlled Radiation-Pressure Modulation:**  
   Strong forward photon recoil recoil suppresses longitudinal radiation pressure to $F_z = +58.3\,$fN under LCP compared to $+116.8\,$fN under RCP (and $+48.2\,$fN for the planar achiral control), producing a $50.1\%$ helicity-dependent force contrast ($\Delta F_z = -58.5\,$fN).
3. **Helicity-Controlled Optical Torque Amplification:**  
   Chiral scattering asymmetry redirects incident photon spin into scattered orbital angular momentum, amplifying axial mechanical torque to $\tau_z = +36.2\,\mathrm{zN\cdot m}$ under LCP versus $-25.0\,\mathrm{zN\cdot m}$ under RCP ($\approx 19$-fold amplification over planar baseline $\tau_z = \pm 1.92\,\mathrm{zN\cdot m}$).
4. **Three-Method Cross-Validation:**  
   Agreement across Finite-Difference Time-Domain (FDTD), Coupled Dipole Approximation (CDA), and Boundary Element Method (MNPBEM) is established within $3.2\%$ relative discrepancy across all observables.
5. **Statistical Robustness:**  
   An ensemble of $N_\mathrm{MC} = 500$ independent Monte Carlo disorder configurations confirms that all 500 simulated realizations maintain positive helicity-controlled optical torque (mean $\tau_z = +35.8 \pm 2.1\,\mathrm{zN\cdot m}$).

---

## Repository Structure

```
josab-chiral-plasmonic-optomechanics/
├── .github/
│   └── workflows/
│       └── ci.yml                     # Continuous integration for data & compilation
├── CAD/                               # 3D STL and STEP structural models
│   ├── nanorod_ring_LH_twist30.stl
│   ├── nanorod_ring_RH_twist30.stl
│   └── nanorod_ring_planar_control.stl
├── data/                              # Audited simulation datasets
│   ├── raw/                           # Raw spectral outputs and Yee sweeps
│   ├── processed/                     # Energy balance and convergence files
│   └── disorder/                      # 500 Monte Carlo stochastic realizations
├── docs/                              # Journal compliance and governance reports
│   ├── cover_letter_josab.md          # Formal cover letter to JOSA B
│   ├── journal_scope_and_format_report.md # JOSA B Aims & Scope analysis
│   ├── scientific_audit.md            # 11-point mathematical and physical audit
│   └── ai_use_disclosure.md           # Optica AI Policy compliance statement
├── figures/                           # Publication-ready figures
│   ├── pdf/                           # Vector PDF figures (Fig 1 to 12)
│   ├── png/                           # 600-DPI publication PNGs
│   ├── jpeg/                          # Compressed review images
│   └── eps/                           # Encapsulated PostScript figures
├── manuscript/                        # Main JOSA B manuscript files
│   ├── manuscript.tex                 # Primary LaTeX source (opticajnl.cls)
│   ├── manuscript.pdf                 # Compiled 10-page PDF (PASS, exit code 0)
│   ├── main.docx                      # Editable Word manuscript (universal-template.docx)
│   ├── references.bib                 # Verified BibTeX database (84 entries)
│   ├── opticajnl.cls                  # Official Optica LaTeX document class
│   └── opticajnl.bst                  # Official Optica BibTeX style
├── references/                        # Literature integrity deliverables
│   ├── doi_verification_report.md     # 100% DOI resolution report
│   ├── verified_references.csv        # 84 verified peer-reviewed references
│   ├── literature_candidates.csv      # 88 total candidates evaluated
│   ├── rejected_references.csv        # Rejection log (preprints & duplicates)
│   └── citation_claim_matrix.csv      # Complete in-text claim verification matrix
├── scripts/                           # Reproducibility automation scripts
│   ├── python/                        # CDA modeling and plotting scripts
│   ├── matlab/                        # MNPBEM boundary-element scripts
│   └── lumerical/                     # FDTD automation and MST monitor scripts
├── supplementary/                     # Supplementary Information
│   ├── supplementary_information.tex  # Supplementary LaTeX source
│   ├── supplementary_information.pdf  # Compiled 17-page PDF (PASS, exit code 0)
│   └── figures/                       # Supplementary Figures S01-S14
├── tables/                            # Native academic tables
│   ├── csv/                           # Tables 1 to 8 in CSV format
│   └── tex/                           # Tables 1 to 8 in LaTeX booktabs format
├── AUTHORS.md                         # Author declarations and CRediT roles
├── authors.yaml                       # Structured machine-readable author metadata
├── CHANGELOG.md                       # Project history and release notes
├── CITATION.cff                       # Citation metadata format
├── CONTRIBUTING.md                    # Guidelines for contributing and issues
├── LICENSE                            # MIT Open Source License
└── README.md                          # This document
```

---

## Quick Start & Local Compilation

### Prerequisites
- **TeX Distribution:** MiKTeX 25.12+ or TeX Live 2024+ (`pdflatex`, `bibtex`)
- **Python:** Python 3.10+ (recommended: `uv` package manager)
- **Word Processing:** Microsoft Word 2016+ or LibreOffice 7+ (for `main.docx`)

### 1. Compile Main LaTeX Manuscript (Exact 10 Pages)
```bash
cd manuscript
pdflatex -interaction=nonstopmode manuscript.tex
bibtex manuscript
pdflatex -interaction=nonstopmode manuscript.tex
pdflatex -interaction=nonstopmode manuscript.tex
```

### 2. Compile Supplementary Information (Exact 17 Pages)
```bash
cd supplementary
pdflatex -interaction=nonstopmode supplementary_information.tex
pdflatex -interaction=nonstopmode supplementary_information.tex
```

### 3. Build Word Manuscript from Python
```bash
uv run --with python-docx python scripts/python/build_optica_word_manuscript.py
```

### 4. Regenerate Figures & Tables from Raw Simulation Data
All calculations, multipolar projections, and stochastic disorder sweeps are independently reproducible from the archived raw simulation data:
```bash
# Regenerate all 12 main manuscript figures (PDF, PNG, EPS)
python scripts/python/run_all_figures.py

# Regenerate all 14 supplementary figures (Figures S01-S14)
python scripts/python/generate_supplementary_figures.py

# Regenerate all publication tables (Tables 1-8 and SI tables)
python scripts/python/generate_all_tables.py

# Automated audit: verify exact 10-page length constraints
python scripts/python/build_and_check_10pages.py
```

---

## Citation

If you use this codebase, structural CAD files, or simulation datasets in your research, please cite:

```bibtex
@article{priyanka2026helicity,
  author    = {Priyanka and Soorat, Ram},
  title     = {Helicity-Selective Multipolar Interference Governs Optical Force and Torque in Structurally Chiral Plasmonic Nanorod Rings},
  journal   = {Journal of the Optical Society of America B},
  year      = {2026},
  note      = {Under Review, Optica Publishing Group}
}
```

---

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
