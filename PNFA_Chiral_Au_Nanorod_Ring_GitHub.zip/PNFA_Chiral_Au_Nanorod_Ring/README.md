﻿# PNFA Chiral Au Nanorod Ring — Reproducibility Package

## Project Overview

**Title:** Chiral Plasmonic Coupling, Multipolar Excitation, and Helicity-Locked
Optomechanics in Structurally Chiral Gold Nanorod Ring Assemblies

**Target Journal:** Photonics and Nanostructures — Fundamentals and Applications (PNFA)

**Primary FDTD mesh: 0.5 nm (mandatory)**

---

## Software Requirements

| Software | Version | Purpose |
|---|---|---|
| Python | >= 3.10 | CDA engine, automation, plotting |
| NumPy | >= 1.24 | Numerical computation |
| SciPy | >= 1.10 | Linear algebra, interpolation |
| Matplotlib | >= 3.7 | Figure generation |
| PyYAML | >= 6.0 | Config file parsing |
| Pandas | >= 2.0 | Data tables and CSV export |
| Ansys Lumerical FDTD | 2023+ | FDTD simulation |
| MATLAB | R2022b+ | BEM/MNPBEM calculations |
| MNPBEM Toolbox | 14+ | Boundary element method |
| MiKTeX | 23.x | LaTeX compilation |
| TeXmaker | 5.x | LaTeX editor |

---

## Directory Structure

```
PNFA_Chiral_Au_Nanorod_Ring/
├── config/
│   └── config.yaml              ← ALL parameters here
├── lumerical/
│   ├── scripts/                 ← Lumerical .lsf scripts
│   └── FDTD/                    ← Saved .fsp files
├── matlab/
│   └── BEM/bem_chiral_ring.m    ← MNPBEM automation
├── python/
│   ├── analysis/physics_engine.py  ← CDA physics (audited)
│   └── automation/
│       ├── master_pipeline.py   ← Master controller
│       └── fdtd_lumapi_controller.py ← Lumerical API
├── data/
│   ├── raw/                     ← Raw simulation outputs
│   ├── processed/               ← Analysed results (CSV)
│   └── validation/              ← Cross-validation data
├── figures/
│   ├── PNG/                     ← 600 dpi PNG figures
│   ├── PDF/                     ← Vector PDF figures
│   └── source/                  ← Figure generation scripts
├── references/
│   ├── references.bib           ← 80 BibTeX references
│   └── scholar_verified.csv     ← Verification database
├── manuscript/
│   ├── main.tex                 ← Main LaTeX document
│   └── sections/                ← Section .tex files
└── build_manuscript.bat         ← Automated compilation
```

---

## Running CDA Calculations

```bash
cd python/automation
pip install numpy scipy matplotlib pyyaml pandas
python master_pipeline.py --sweep all --disorder
```

---

## Running FDTD Simulations

```bash
# Requires Ansys Lumerical installed
cd python/automation
python fdtd_lumapi_controller.py --mode baseline
python fdtd_lumapi_controller.py --mode convergence
python fdtd_lumapi_controller.py --mode sweep_twist
```
Or use the Lumerical script directly:
- Open Lumerical FDTD
- Run `lumerical/scripts/build_chiral_ring_FDTD.lsf`

**Primary mesh: 0.5 nm**

---

## Running BEM Calculations

```matlab
% In MATLAB with MNPBEM toolbox installed:
cd matlab/BEM
run_mode = 'baseline';
bem_chiral_ring
```

---

## Compiling the Manuscript

```batch
build_manuscript.bat         REM Windows (MiKTeX)
build_manuscript.bat clean   REM Clean auxiliary files
```
Or open `manuscript/main.tex` in TeXmaker.

---

## Physics Audit Notes

**CRITICAL:** The existing scattering force expression `Re(p_i x p_i*)` was
found to be zero identically (the cross product of a complex vector with its
conjugate is purely imaginary). The corrected expression uses the momentum-flux
method: F_z = (n_m I_0/c)(sigma_ext - sigma_sca * g_eff). See `physics_engine.py`.

**Optical pulling under plane wave:** Physically impossible for a passive particle
(beta <= 1 always). Pulling requires focused illumination (xi_inc < 1).
This is explicitly stated in the manuscript.

---

## Reference Verification

All 80 references require Google Scholar and DOI verification before submission.
Check `references/scholar_verified.csv` for status.
References marked [VERIFY] in the BibTeX file need DOI confirmation.

---

## Key Results (Baseline: N=6, phi=30deg, LH, LCP, 800nm)

| Quantity | Value |
|---|---|
| CD | 3300 nm² |
| g-factor | 0.28 |
| C/C0 peak | ~68 |
| F_z (CDA) | -44.8 fN |
| F_z (FDTD, 0.5nm) | -46.2 fN |
| CDA-FDTD deviation | 3.1% |
| tau_z (LCP) | +35 aN·m |
| MD/ED ratio | 0.47 |
| eta_fwd | 0.73 |

---

## Reproducibility

All random disorder configurations use seeds: seed = 42 + config_id (0-99).
All parameters read from `config/config.yaml`.
No hard-coded parameters in simulation scripts.
