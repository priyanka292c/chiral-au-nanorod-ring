@echo off
:: ============================================================
:: build_manuscript.bat  --  PNFA Chiral Au Nanorod Ring
:: Automated LaTeX compilation script for Windows MiKTeX
:: ============================================================
:: Usage:
::   build_manuscript.bat           -- full build
::   build_manuscript.bat clean     -- clean aux files only
:: ============================================================

SET MAIN=main
SET BIBFILE=../references/references
SET LOGFILE=compilation.log

pushd "%~dp0manuscript"

IF "%1"=="clean" GOTO CLEAN

echo ============================================================
echo Building PNFA Chiral Au Nanorod Ring Manuscript
echo Primary FDTD mesh: 0.5 nm
echo Target: Photonics and Nanostructures
echo ============================================================

:: Pass 1: pdflatex
echo [1/4] pdflatex pass 1...
pdflatex -interaction=nonstopmode -file-line-error %MAIN%.tex > %LOGFILE% 2>&1
IF ERRORLEVEL 1 GOTO ERROR

:: BibTeX
echo [2/4] bibtex...
bibtex %MAIN% >> %LOGFILE% 2>&1

:: Pass 2: pdflatex
echo [3/4] pdflatex pass 2...
pdflatex -interaction=nonstopmode %MAIN%.tex >> %LOGFILE% 2>&1

:: Pass 3: pdflatex (resolve references)
echo [4/4] pdflatex pass 3...
pdflatex -interaction=nonstopmode %MAIN%.tex > pass3.log 2>&1
IF ERRORLEVEL 1 GOTO ERROR

:: Quality checks on the final resolved pass
echo.
echo ============================================================
echo Running quality checks...
echo ============================================================
findstr /i "undefined" pass3.log && echo WARNING: Undefined references found
findstr /i "citation" pass3.log | findstr /i "undefined" && echo WARNING: Undefined citations found
findstr /i "Missing" pass3.log && echo WARNING: Missing elements found
findstr /i "Overfull" pass3.log | find "" /c > nul && echo INFO: Check overfull boxes in log

type pass3.log >> %LOGFILE%
del pass3.log 2>nul

echo.
echo BUILD SUCCESSFUL: %MAIN%.pdf generated.
echo Compilation log: manuscript\%LOGFILE%
popd
GOTO END

:ERROR
echo.
echo BUILD FAILED. Check manuscript\%LOGFILE% for errors.
popd
exit /b 1

:CLEAN
echo Cleaning auxiliary files...
del /f /q *.aux *.bbl *.blg *.log *.out *.toc *.lof *.lot *.spl 2>nul
del /f /q sections\*.aux 2>nul
echo Clean complete.
popd
GOTO END

:END
