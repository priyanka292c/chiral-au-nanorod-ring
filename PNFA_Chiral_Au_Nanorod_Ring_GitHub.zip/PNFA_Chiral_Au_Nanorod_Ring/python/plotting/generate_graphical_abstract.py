#!/usr/bin/env python3
"""
generate_graphical_abstract.py
================================
Generates a publication-quality Graphical Abstract for the PNFA manuscript:
  "Helicity-Dependent Chiroptical and Optomechanical Response of
   Structurally Chiral Gold Nanorod Ring Assemblies"

Outputs:
  - final/graphical_abstract.png (600 dpi, Elsevier standard 16:9 ratio)
  - final/graphical_abstract.pdf (vector)
  - final/submission_package/graphical_abstract.png
  - final/submission_package/graphical_abstract.pdf
  - final/graphical_abstract_caption.txt
  - final/submission_package/graphical_abstract_caption.txt
"""

import os
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, Circle, FancyArrowPatch, Wedge, Arc
import matplotlib.patheffects as pe

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent.parent
FINAL_DIR = PROJECT_ROOT / 'final'
SUB_DIR = FINAL_DIR / 'submission_package'
DATA_DIR = PROJECT_ROOT / 'data' / 'processed'

for d in [FINAL_DIR, SUB_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# Load real 301-point datasets for insets
df_chiro = pd.read_csv(DATA_DIR / 'chiroptical_spectra_highres.csv')
df_force = pd.read_csv(DATA_DIR / 'force_momentum_highres.csv')
df_torque = pd.read_csv(DATA_DIR / 'torque_decomposition_highres.csv')

# Graphical Abstract Dimensions (Standard Elsevier 16:9 ratio, ~1800x1012 px at 300 dpi; 3600x2025 at 600 dpi)
fig = plt.figure(figsize=(14.0, 7.875), dpi=300)
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, 100)
ax.set_ylim(0, 100)
ax.axis('off')

# Clean subtle modern background
ax.add_patch(Rectangle((0, 0), 100, 100, color='#f8fafc', zorder=0))

# Color palette (Curated, high-contrast, professional)
C_GOLD       = '#d4af37'
C_GOLD_DARK  = '#997a15'
C_GOLD_LIGHT = '#fef08a'
C_LCP        = '#0284c7'  # Sky/petrol blue
C_RCP        = '#e11d48'  # Rose/crimson
C_MD         = '#dc2626'  # Vivid red
C_ED         = '#1e3a8a'  # Navy blue
C_EQ         = '#0d9488'  # Teal
C_CD         = '#7c3aed'  # Violet
C_TEXT_MAIN  = '#0f172a'  # Slate 900
C_TEXT_MUTED = '#475569'  # Slate 600
C_CARD_BG    = '#ffffff'
C_CARD_BORDER= '#cbd5e1'

# -------------------------------------------------------------
# 1. Title Banner (Top)
# -------------------------------------------------------------
ax.add_patch(FancyBboxPatch((2, 91.5), 96, 7.2, boxstyle="round,pad=0.4,rounding_size=1.2",
                           facecolor='#ffffff', edgecolor='#cbd5e1', lw=1.2, zorder=1))
ax.text(50, 95.8, "Helicity-Dependent Chiroptical and Optomechanical Response of Chiral Au Nanorod Rings",
        ha='center', va='center', fontsize=13.5, weight='bold', color=C_TEXT_MAIN,
        fontfamily='sans-serif')
ax.text(50, 93.0, r"Structural Chirality $\rightarrow$ MD Activation $\rightarrow$ Partial Kerker Forward Scattering $\rightarrow$ Radiation-Pressure Suppression & Helicity-Locked Torque",
        ha='center', va='center', fontsize=9.2, style='italic', color='#334155',
        fontfamily='sans-serif')

# -------------------------------------------------------------
# 2. Panel 1: Incident Light (Left, x: 2 to 18.5)
# -------------------------------------------------------------
box_light = FancyBboxPatch((2, 47), 16.5, 43, boxstyle="round,pad=0.6,rounding_size=1.5",
                           facecolor='#ffffff', edgecolor=C_CARD_BORDER, lw=1.2, zorder=1)
ax.add_patch(box_light)
ax.text(10.25, 87.5, "INCIDENT LIGHT", ha='center', va='center', fontsize=10, weight='bold', color=C_TEXT_MAIN)
ax.text(10.25, 84.8, r"$\mathbf{k} \parallel +\hat{\mathbf{z}}$ in Water ($n_m = 1.33$)",
        ha='center', va='center', fontsize=7.8, color=C_TEXT_MUTED)

# LCP Beam Icon
ax.add_patch(Circle((6.5, 76), 3.2, fill=False, edgecolor=C_LCP, lw=2.4))
ax.annotate('', xy=(6.5, 79.2), xytext=(6.2, 79.2),
            arrowprops=dict(arrowstyle="->", lw=2.2, color=C_LCP, mutation_scale=14))
ax.text(12.0, 76, "LCP\n" + r"$\sigma = +1$", ha='left', va='center', fontsize=8.8, weight='bold', color=C_LCP)

# RCP Beam Icon
ax.add_patch(Circle((6.5, 63), 3.2, fill=False, edgecolor=C_RCP, lw=2.4, linestyle='--'))
ax.annotate('', xy=(6.2, 66.2), xytext=(6.5, 66.2),
            arrowprops=dict(arrowstyle="->", lw=2.2, color=C_RCP, mutation_scale=14))
ax.text(12.0, 63, "RCP\n" + r"$\sigma = -1$", ha='left', va='center', fontsize=8.8, weight='bold', color=C_RCP)

# Power & Field parameters card
ax.add_patch(FancyBboxPatch((3.2, 49), 14.1, 8.5, boxstyle="round,pad=0.3,rounding_size=1.0",
                           facecolor='#f1f5f9', edgecolor='#cbd5e1', lw=0.9))
ax.text(10.25, 54.8, r"$I_0 = 1.33\,$mW/$\mu$m$^2$", ha='center', va='center', fontsize=8.0, weight='bold', color='#1e293b')
ax.text(10.25, 51.5, r"$E_0 = 8.68\times 10^5\,$V/m", ha='center', va='center', fontsize=7.6, color='#334155')

# Directional arrows pointing to nanostructure
ax.annotate('', xy=(20.2, 76), xytext=(17.5, 76),
            arrowprops=dict(arrowstyle="-|>", lw=2.5, color=C_LCP, mutation_scale=16))
ax.annotate('', xy=(20.2, 63), xytext=(17.5, 63),
            arrowprops=dict(arrowstyle="-|>", lw=2.5, color=C_RCP, mutation_scale=16))

# -------------------------------------------------------------
# 3. Panel 2: Chiral Nanorod Cluster (x: 20.5 to 47.5)
# -------------------------------------------------------------
box_geom = FancyBboxPatch((20.5, 47), 27, 43, boxstyle="round,pad=0.6,rounding_size=1.5",
                          facecolor='#ffffff', edgecolor=C_CARD_BORDER, lw=1.2, zorder=1)
ax.add_patch(box_geom)
ax.text(34.0, 87.5, "CHIRAL PLASMONIC RING", ha='center', va='center', fontsize=10, weight='bold', color=C_TEXT_MAIN)
ax.text(34.0, 84.8, r"6 Au Nanorods ($l=100\,$nm, $d=35\,$nm, $R_c=120\,$nm)",
        ha='center', va='center', fontsize=7.8, color=C_TEXT_MUTED)

# Draw 6 nanorods in twisted ring
cx0, cy0 = 34.0, 67.0
R_ring = 9.8
circ_ring = plt.Circle((cx0, cy0), R_ring, fill=False, edgecolor='#e2e8f0', linestyle=':', lw=1.2)
ax.add_patch(circ_ring)

phi_twist = 30.0  # degrees
for i in range(6):
    th = i * np.pi / 3.0
    px = cx0 + R_ring * np.cos(th)
    py = cy0 + R_ring * np.sin(th)
    ang = th + np.pi/2.0 + np.deg2rad(phi_twist)
    dx = 3.9 * np.cos(ang)
    dy = 3.9 * np.sin(ang)
    
    # Rod with metallic gold shading
    ax.plot([px - dx, px + dx], [py - dy, py + dy], color=C_GOLD, lw=7.0, solid_capstyle='round', zorder=3)
    ax.plot([px - dx, px + dx], [py - dy, py + dy], color=C_GOLD_LIGHT, lw=2.2, solid_capstyle='round', zorder=4)
    ax.plot([px - dx, px + dx], [py - dy, py + dy], color=C_GOLD_DARK, lw=0.8, solid_capstyle='round', zorder=5)

# Circulating displacement current (Magnetic Dipole)
arc_md = Arc((cx0, cy0), 13.5, 13.5, angle=0, theta1=25, theta2=335, color=C_MD, lw=2.2, linestyle='--', zorder=6)
ax.add_patch(arc_md)
ax.annotate('', xy=(cx0 + 6.75 * np.cos(np.deg2rad(335)), cy0 + 6.75 * np.sin(np.deg2rad(335))),
            xytext=(cx0 + 6.75 * np.cos(np.deg2rad(318)), cy0 + 6.75 * np.sin(np.deg2rad(318))),
            arrowprops=dict(arrowstyle="->", lw=2.4, color=C_MD, mutation_scale=13), zorder=7)

ax.text(cx0, cy0, "Circulating\nCurrents\n" + r"$\mathbf{m}_z \ne 0$",
        ha='center', va='center', fontsize=8.2, weight='bold', color=C_MD, zorder=8)

# Chiral twist annotation badge
ax.add_patch(FancyBboxPatch((22.5, 49.0), 23.0, 5.0, boxstyle="round,pad=0.25,rounding_size=0.8",
                           facecolor='#eff6ff', edgecolor='#93c5fd', lw=0.9))
ax.text(34.0, 51.5, r"Twist Angle $\phi = +30^\circ$ (Left-Handed Enantiomer)",
        ha='center', va='center', fontsize=8.0, weight='bold', color='#1e40af')

# Connector arrow to multipoles
ax.annotate('', xy=(49.5, 68.5), xytext=(47.2, 68.5),
            arrowprops=dict(arrowstyle="-|>", lw=2.5, color='#475569', mutation_scale=15))

# -------------------------------------------------------------
# 4. Panel 3: Multipolar & Kerker Interference (x: 49.5 to 73.0)
# -------------------------------------------------------------
box_multi = FancyBboxPatch((49.5, 47), 23.5, 43, boxstyle="round,pad=0.6,rounding_size=1.5",
                           facecolor='#ffffff', edgecolor=C_CARD_BORDER, lw=1.2, zorder=1)
ax.add_patch(box_multi)
ax.text(61.25, 87.5, "MULTIPOLAR HYBRIDIZATION", ha='center', va='center', fontsize=10, weight='bold', color=C_TEXT_MAIN)
ax.text(61.25, 84.8, r"Co-Resonance at $\lambda = 800\,$nm", ha='center', va='center', fontsize=7.8, color=C_TEXT_MUTED)

# Multipolar bar chart
ax.text(51.5, 80.5, r"ED: $58.5\%$", fontsize=8.2, weight='bold', color=C_ED)
ax.add_patch(Rectangle((61.5, 79.5), 9.5, 2.2, color=C_ED))

ax.text(51.5, 75.5, r"MD: $27.8\%$", fontsize=8.2, weight='bold', color=C_MD)
ax.add_patch(Rectangle((61.5, 74.5), 4.5, 2.2, color=C_MD))

ax.text(51.5, 70.5, r"EQ: $11.2\%$", fontsize=8.2, weight='bold', color=C_EQ)
ax.add_patch(Rectangle((61.5, 69.5), 1.8, 2.2, color=C_EQ))

ax.text(61.25, 65.5, r"$\mathbf{P_{\rm MD} / P_{\rm ED} \approx 0.47} \quad \Delta\theta_{\rm ED-MD} \approx 14^\circ$",
        ha='center', va='center', fontsize=8.2, weight='bold', color='#991b1b')

# Partial Kerker Box
ax.add_patch(FancyBboxPatch((51.0, 49.0), 20.5, 13.5, boxstyle="round,pad=0.4,rounding_size=1.2",
                           facecolor='#f0fdf4', edgecolor='#86efac', lw=1.0))
ax.text(61.25, 59.8, "PARTIAL KERKER INTERFERENCE", ha='center', va='center', fontsize=8.2, weight='bold', color='#166534')
ax.text(61.25, 56.5, r"Forward Ratio $\mathbf{\eta_{\rm fwd} \approx 0.73}$", ha='center', va='center', fontsize=8.0, color='#15803d', weight='bold')
ax.text(61.25, 53.5, r"Scattering Asymmetry $\mathbf{g_{\rm eff} \approx 0.46}$", ha='center', va='center', fontsize=7.8, color='#15803d')
ax.text(61.25, 50.8, r"Suppressed Backscatter $\rightarrow$ Forward Recoil", ha='center', va='center', fontsize=7.2, style='italic', color='#166534')

# Connector arrow to optomechanics
ax.annotate('', xy=(75.0, 68.5), xytext=(72.7, 68.5),
            arrowprops=dict(arrowstyle="-|>", lw=2.5, color='#475569', mutation_scale=15))

# -------------------------------------------------------------
# 5. Panel 4: Optomechanical Response (Right, x: 75.0 to 98.0)
# -------------------------------------------------------------
box_out = FancyBboxPatch((75.0, 47), 23.0, 43, boxstyle="round,pad=0.6,rounding_size=1.5",
                         facecolor='#ffffff', edgecolor=C_CARD_BORDER, lw=1.2, zorder=1)
ax.add_patch(box_out)
ax.text(86.5, 87.5, "OPTOMECHANICS", ha='center', va='center', fontsize=10, weight='bold', color=C_TEXT_MAIN)
ax.text(86.5, 84.8, r"At $\lambda = 800\,$nm ($I_0 = 1.33\,$mW/$\mu$m$^2$)", ha='center', va='center', fontsize=7.8, color=C_TEXT_MUTED)

# Card A: Radiation Pressure Suppression
ax.add_patch(FancyBboxPatch((76.5, 66.8), 20.0, 16.0, boxstyle="round,pad=0.4,rounding_size=1.2",
                           facecolor='#eff6ff', edgecolor='#93c5fd', lw=1.0))
ax.text(86.5, 80.2, "RADIATION PRESSURE", ha='center', va='center', fontsize=8.2, weight='bold', color='#1e40af')
ax.text(86.5, 77.2, "Forward Recoil Suppression Dip:", ha='center', va='center', fontsize=7.6, color='#1e3a8a')
ax.text(86.5, 74.0, r"$\mathbf{F_z = +58.3\,fN}$ (FDTD 0.5 nm)", ha='center', va='center', fontsize=8.5, weight='bold', color='#1d4ed8')
ax.text(86.5, 71.2, r"$F_z = +56.9\,$fN (CDA) $\;\bullet\;$ $57.8\,$fN (Mom.)", ha='center', va='center', fontsize=7.2, color='#3b82f6')
ax.text(86.5, 68.5, r"$\mathbf{\Delta F_z = 58.5\,fN}$ (Dichroism vs RCP)", ha='center', va='center', fontsize=7.5, weight='bold', color='#1e40af')

# Card B: Helicity-Locked Optical Torque
ax.add_patch(FancyBboxPatch((76.5, 48.8), 20.0, 16.5, boxstyle="round,pad=0.4,rounding_size=1.2",
                           facecolor='#fff1f2', edgecolor='#fda4af', lw=1.0))
ax.text(86.5, 62.8, "HELICITY-LOCKED TORQUE", ha='center', va='center', fontsize=8.2, weight='bold', color='#9f1239')
ax.text(86.5, 59.5, r"LCP: $\mathbf{\tau_z = +36.2\,zN\cdot m}$", ha='center', va='center', fontsize=8.4, weight='bold', color=C_LCP)
ax.text(86.5, 56.2, r"RCP: $\mathbf{\tau_z = -25.0\,zN\cdot m}$", ha='center', va='center', fontsize=8.4, weight='bold', color=C_RCP)
ax.text(86.5, 53.0, r"Spin Absorption: $\tau_{\rm abs} \approx \pm 1.86\,$zN$\cdot$m", ha='center', va='center', fontsize=7.2, color='#475569')
ax.text(86.5, 50.2, r"$\mathbf{\approx 19\times}$ Chiral Torque Amplification", ha='center', va='center', fontsize=7.8, weight='bold', color='#be123c')

# -------------------------------------------------------------
# 6. Bottom Banner: Chiroptics & Multi-Model Validation Matrix
# -------------------------------------------------------------
# Left Box: Chiroptics & Real Mini-Spectrum (x: 2 to 47.5)
box_cd = FancyBboxPatch((2, 4.5), 45.5, 39.5, boxstyle="round,pad=0.6,rounding_size=1.5",
                        facecolor='#ffffff', edgecolor=C_CARD_BORDER, lw=1.2, zorder=1)
ax.add_patch(box_cd)
ax.text(24.75, 41.5, "FAR-FIELD & NEAR-FIELD CHIROPTICS", ha='center', va='center', fontsize=10, weight='bold', color=C_TEXT_MAIN)

# Chiroptical stats
ax.text(8.5, 36.8, r"$\mathbf{CD = +3.30\times 10^3\,nm^2}$", fontsize=8.8, weight='bold', color=C_CD)
ax.text(8.5, 33.2, r"Dissymmetry: $\mathbf{g = +0.28}$", fontsize=8.2, weight='bold', color='#4c1d95')
ax.text(8.5, 29.8, r"Peak $|E|^2/|E_0|^2 \approx 155$", fontsize=7.8, color='#334155')

ax.text(32.5, 36.8, r"$\mathbf{C / C_0 \approx 68}$ (Vacuum-ref.)", fontsize=8.5, weight='bold', color='#b45309')
ax.text(32.5, 33.2, r"$\mathbf{C / C_{\rm inc,water} \approx 51.1}$ (Water-ref.)", fontsize=8.5, weight='bold', color='#92400e')
ax.text(32.5, 29.8, r"Hotspot gap: $g \approx 18.2\,$nm", fontsize=7.8, color='#334155')

# Right Box: Multi-Model Cross-Validation & Monte Carlo (x: 49.5 to 98)
box_val = FancyBboxPatch((49.5, 4.5), 48.5, 39.5, boxstyle="round,pad=0.6,rounding_size=1.5",
                         facecolor='#ffffff', edgecolor=C_CARD_BORDER, lw=1.2, zorder=1)
ax.add_patch(box_val)
ax.text(73.75, 41.5, "RIGOROUS MULTI-MODEL NUMERICAL VALIDATION", ha='center', va='center', fontsize=10, weight='bold', color=C_TEXT_MAIN)

# Four validation pillars
pillars = [
    ("CDA Sweeps", "Dipole electrodynamics\nParametric sweeps"),
    ("FDTD (0.5 nm)", "Conformal Yee mesh\n<0.8% convergence"),
    ("BEM Solver", "Boundary integral\n<2.84% CDA error"),
    ("Momentum Budget", "Far-field recoil flux\n0.85% MST closure")
]

for idx, (p_title, p_desc) in enumerate(pillars):
    bx = 51.5 + idx * 11.5
    ax.add_patch(FancyBboxPatch((bx, 22.0), 10.5, 16.5, boxstyle="round,pad=0.3,rounding_size=1.0",
                                facecolor='#f8fafc', edgecolor='#cbd5e1', lw=0.9))
    ax.text(bx + 5.25, 35.5, p_title, ha='center', va='center', fontsize=8.0, weight='bold', color='#0f172a')
    ax.text(bx + 5.25, 28.5, p_desc, ha='center', va='center', fontsize=7.0, color='#475569', multialignment='center')

# Bottom summary banner inside right box
ax.add_patch(FancyBboxPatch((51.5, 7.5), 44.5, 12.0, boxstyle="round,pad=0.4,rounding_size=1.0",
                           facecolor='#ecfdf5', edgecolor='#6ee7b7', lw=1.0))
ax.text(73.75, 16.0, r"0.85% MST--Momentum Conservation Agreement   $\bullet$   $\leq$ 3.5% CDA--FDTD Force Agreement",
        ha='center', va='center', fontsize=8.2, weight='bold', color='#065f46')
ax.text(73.75, 11.5, r"Monte Carlo Disorder Robustness ($N=100$): 100% positive torque preserved under LCP" + "\n" +
                     r"$\tau_z = 35.8 \pm 2.6\,$zN$\cdot$m (Mean $\pm$ Std. Dev.)",
        ha='center', va='center', fontsize=7.8, color='#047857', multialignment='center')

# -------------------------------------------------------------
# 7. Embed Inset Real Plots in Left Box
# -------------------------------------------------------------
# Inset Axis: Extinction & CD Spectra (Normalized Coordinates: left, bottom, width, height)
# Inside Left Box: x in [4.5, 45.0], y in [7.5, 27.5] -> [0.045, 0.075, 0.405, 0.20]
ax_in = fig.add_axes([0.045, 0.075, 0.405, 0.195])
ax_in.set_facecolor('#ffffff')
l1, = ax_in.plot(df_chiro['wavelength_nm'], df_chiro['sigma_ext_LCP_103nm2'], color=C_LCP, lw=1.8, label=r'$\sigma_{\rm ext}^{\rm LCP}$')
l2, = ax_in.plot(df_chiro['wavelength_nm'], df_chiro['sigma_ext_RCP_103nm2'], color=C_RCP, lw=1.8, linestyle='--', label=r'$\sigma_{\rm ext}^{\rm RCP}$')
ax_in.set_xlim(500, 1100)
ax_in.set_ylim(0, 110)
ax_in.set_xlabel('Wavelength (nm)', fontsize=7.5, labelpad=2)
ax_in.set_ylabel(r'$\sigma_{\rm ext}$ ($10^3\,$nm$^2$)', fontsize=7.5, labelpad=2)
ax_in.tick_params(axis='both', which='major', labelsize=6.8, pad=2)
ax_in.grid(True, linestyle=':', alpha=0.5)

# Secondary twin axis for CD
ax_in_cd = ax_in.twinx()
cd_data = (df_chiro['sigma_ext_LCP_103nm2'] - df_chiro['sigma_ext_RCP_103nm2']) * 1000.0  # in nm^2
l3, = ax_in_cd.plot(df_chiro['wavelength_nm'], cd_data, color=C_CD, lw=2.0, label='CD Spectrum')
ax_in_cd.set_ylabel('CD (nm$^2$)', fontsize=7.5, color=C_CD, labelpad=2)
ax_in_cd.tick_params(axis='y', which='major', labelsize=6.8, colors=C_CD, pad=2)
ax_in_cd.set_ylim(-500, 4000)

# Resonance marker at 800 nm
ax_in.axvline(800, color='#64748b', linestyle=':', lw=1.0)
ax_in.text(805, 95, r'$\lambda = 800\,$nm', fontsize=7.0, weight='bold', color='#1e293b')

# Compact combined legend
lines = [l1, l2, l3]
labels = [l.get_label() for l in lines]
ax_in.legend(lines, labels, loc='upper left', fontsize=6.8, frameon=True, framealpha=0.9,
             borderpad=0.3, handlelength=1.2)

# Save high-resolution PNG (600 dpi) and vector PDF
fig.savefig(FINAL_DIR / 'graphical_abstract.png', dpi=600)
fig.savefig(FINAL_DIR / 'graphical_abstract.pdf', format='pdf', dpi=600)
fig.savefig(SUB_DIR / 'graphical_abstract.png', dpi=600)
fig.savefig(SUB_DIR / 'graphical_abstract.pdf', format='pdf', dpi=600)
plt.close(fig)

print("  [OK] Saved Graphical Abstract (600 dpi PNG + Vector PDF) to final/ and final/submission_package/")

# Formal Caption File
caption_txt = """GRAPHICAL ABSTRACT CAPTION:
Title: Helicity-Dependent Chiroptical and Optomechanical Response of Structurally Chiral Gold Nanorod Ring Assemblies
Author: Priyanka
Target Journal: Photonics and Nanostructures – Fundamentals and Applications (PNFA), Elsevier

Abstract Summary:
Under circularly polarized plane-wave illumination (I0 = 1.33 mW/μm², E0 = 8.68 × 10^5 V/m in water, nm = 1.33), a structurally chiral assembly of six gold nanorods (l = 100 nm, d = 35 nm, Rc = 120 nm, twist angle φ = +30°) undergoes collective plasmonic hybridization, activating a strong magnetic-dipole mode (scattered-power ratio P_MD/P_ED ≈ 0.47) co-resonant with the electric dipole at 800 nm. Destructive backward and constructive forward interference via partial Kerker-like scattering (η_fwd ≈ 0.73, geff ≈ 0.46) channels scattered momentum into the forward hemisphere, sharply suppressing axial radiation pressure down to Fz ≈ +58.3 fN (FDTD 0.5-nm local override) and +56.9 fN (CDA), verified within 0.85% against closed far-field momentum conservation (Fz_mom ≈ 57.8 fN). Simultaneously, helicity-selective angular momentum transfer produces an intense, helicity-locked optical torque (τz = +36.2 zN·m for LCP vs -25.0 zN·m for RCP), representing an approximately 19-fold amplification over the baseline spin-absorption torque of the planar achiral control (τ_abs ≈ ±1.86 zN·m), accompanied by superchiral near-field enhancement (C/C_inc,water ≈ 51.1) and complete Monte Carlo disorder stability across 100 perturbed configurations.
"""

with open(FINAL_DIR / 'graphical_abstract_caption.txt', 'w', encoding='utf-8') as f:
    f.write(caption_txt)
with open(SUB_DIR / 'graphical_abstract_caption.txt', 'w', encoding='utf-8') as f:
    f.write(caption_txt)

print("  [OK] Saved graphical abstract caption.")
