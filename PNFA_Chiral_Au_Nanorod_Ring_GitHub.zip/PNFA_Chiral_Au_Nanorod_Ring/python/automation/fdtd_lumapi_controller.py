﻿"""
fdtd_lumapi_controller.py  -  PNFA Chiral Au Nanorod Ring
==========================================================
Python lumapi controller for Ansys Lumerical FDTD.
Automates:
  - Geometry creation
  - Material assignment (Au Johnson-Christy, water medium)
  - LCP/RCP excitation
  - 0.5 nm mesh (PRIMARY FINAL MESH)
  - MST force monitor (15 nm gap, 6-face closed box)
  - Near-field and far-field monitors
  - Batch sweeps over config.yaml parameters
  - Raw data export (CSV)
  - Mesh convergence study (0.25/0.5/0.75/1.0 nm)

Requirements:
  - Ansys Lumerical FDTD Solutions installed
  - lumapi Python package (bundled with Lumerical)
  - config.yaml in ../config/

Usage:
  python fdtd_lumapi_controller.py --mode baseline
  python fdtd_lumapi_controller.py --mode convergence
  python fdtd_lumapi_controller.py --mode sweep_twist
  python fdtd_lumapi_controller.py --mode all
"""

import argparse
import csv
import json
import logging
import os
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

SCRIPT_DIR = Path(__file__).parent
ROOT_DIR   = SCRIPT_DIR.parent.parent

# ============================================================
# Try to import lumapi — graceful failure if Lumerical not installed
# ============================================================
try:
    sys.path.append(r"C:\Program Files\Lumerical\v232\api\python")
    import lumapi
    LUMAPI_AVAILABLE = True
    logging.info("lumapi imported successfully.")
except ImportError:
    LUMAPI_AVAILABLE = False
    logging.warning(
        "lumapi not found. Lumerical FDTD automation requires Ansys Lumerical "
        "to be installed. Scripts will run in DRY-RUN mode."
    )


def load_config(path: Path) -> dict:
    with open(path) as f:
        return yaml.safe_load(f)


class FDTDController:
    """
    Encapsulates all Lumerical FDTD interactions.
    """
    def __init__(self, cfg: dict, root: Path, dry_run: bool = False):
        self.cfg     = cfg
        self.root    = root
        self.dry_run = dry_run or not LUMAPI_AVAILABLE
        self.fdtd    = None
        self.log     = logging.getLogger('FDTDController')

    def open_lumerical(self):
        if self.dry_run:
            self.log.warning("DRY-RUN: Lumerical not launched.")
            return
        self.fdtd = lumapi.FDTD(hide=False)
        self.log.info("Lumerical FDTD opened.")

    def close_lumerical(self):
        if self.fdtd is not None:
            self.fdtd.close()
            self.fdtd = None

    def _set(self, name, val):
        if not self.dry_run:
            self.fdtd.setnamed(name, 'z', val)  # example — real sets use appropriate method

    def build_geometry(self, n_rods: int, ring_r_nm: float, twist_deg: float,
                        rod_l_nm: float, rod_d_nm: float):
        """Build N-rod ring in Lumerical workspace."""
        if self.dry_run:
            self.log.info(f"  [DRY-RUN] Would build: N={n_rods}, R={ring_r_nm}nm, phi={twist_deg}deg")
            return

        self.fdtd.switchtolayout()
        self.fdtd.deleteall()

        # FDTD solver
        self.fdtd.addfdtd()
        ds = self.cfg['fdtd']['domain_nm']
        self.fdtd.set("x span", ds[0]*1e-9)
        self.fdtd.set("y span", ds[1]*1e-9)
        self.fdtd.set("z span", ds[2]*1e-9)
        self.fdtd.set("simulation time", 1000e-15)
        self.fdtd.set("auto shutoff min", self.cfg['fdtd']['convergence_threshold'])
        self.fdtd.set("pml layers", self.cfg['fdtd']['pml']['n_layers'])

        # Build rods
        mat = "Au (Gold) - Johnson and Christy"
        for i in range(n_rods):
            theta_i = 2 * np.pi * i / n_rods
            x_i = ring_r_nm * 1e-9 * np.cos(theta_i)
            y_i = ring_r_nm * 1e-9 * np.sin(theta_i)
            self.fdtd.addrect()
            self.fdtd.set("name", f"rod_{i}")
            self.fdtd.set("x", x_i)
            self.fdtd.set("y", y_i)
            self.fdtd.set("z", 0)
            self.fdtd.set("x span", rod_d_nm * 1e-9)
            self.fdtd.set("y span", rod_d_nm * 1e-9)
            self.fdtd.set("z span", rod_l_nm * 1e-9)
            self.fdtd.set("material", mat)
            # Rotation: align rod with ring tangent + apply twist
            tang_deg = theta_i * 180 / np.pi + 90
            self.fdtd.set("first axis", "z")
            self.fdtd.set("rotation 1", tang_deg)
            self.fdtd.set("second axis", "x")
            self.fdtd.set("rotation 2", twist_deg)

        self.log.info(f"  Geometry built: N={n_rods}, phi={twist_deg}deg")

    def set_mesh(self, mesh_nm: float, ring_r_nm: float, rod_l_nm: float):
        """Set fine mesh override around assembly."""
        if self.dry_run:
            self.log.info(f"  [DRY-RUN] Would set mesh: {mesh_nm} nm")
            return
        self.fdtd.addmesh()
        self.fdtd.set("name", "fine_mesh")
        span = (2 * ring_r_nm + rod_l_nm + 20) * 1e-9
        self.fdtd.set("x span", span)
        self.fdtd.set("y span", span)
        self.fdtd.set("z span", (rod_l_nm + 20) * 1e-9)
        self.fdtd.set("dx", mesh_nm * 1e-9)
        self.fdtd.set("dy", mesh_nm * 1e-9)
        self.fdtd.set("dz", mesh_nm * 1e-9)
        self.log.info(f"  Mesh set: {mesh_nm} nm")

    def add_source(self, polarization: str, lam_min_nm: float, lam_max_nm: float,
                    domain_nm: float):
        """Add TFSF source with LCP or RCP polarization."""
        if self.dry_run:
            self.log.info(f"  [DRY-RUN] Source: {polarization}")
            return
        self.fdtd.addtfsf()
        self.fdtd.set("name", f"TFSF_{polarization}")
        self.fdtd.set("injection axis", "z")
        self.fdtd.set("direction", "forward")
        gap = 80e-9
        hs = domain_nm * 1e-9 / 2
        self.fdtd.set("x min", -hs + gap)
        self.fdtd.set("x max",  hs - gap)
        self.fdtd.set("y min", -hs + gap)
        self.fdtd.set("y max",  hs - gap)
        self.fdtd.set("wavelength start", lam_min_nm * 1e-9)
        self.fdtd.set("wavelength stop",  lam_max_nm * 1e-9)
        # LCP: ellipticity = +45 deg; RCP: ellipticity = -45 deg
        ell = 45.0 if polarization.upper() == 'LCP' else -45.0
        self.fdtd.set("ellipticity", ell)

    def add_mst_monitors(self, ring_r_nm: float, rod_l_nm: float,
                          gap_nm: float, n_lambda: int,
                          lam_min_nm: float, lam_max_nm: float):
        """Add 6-face closed MST force monitor box."""
        if self.dry_run:
            self.log.info(f"  [DRY-RUN] MST monitors: gap={gap_nm}nm")
            return
        half = (ring_r_nm + rod_l_nm / 2 + gap_nm) * 1e-9
        faces = [('Xm', 'x', -half), ('Xp', 'x', half),
                 ('Ym', 'y', -half), ('Yp', 'y', half),
                 ('Zm', 'z', -half), ('Zp', 'z', half)]
        norms = {'Xm':'x','Xp':'x','Ym':'y','Yp':'y','Zm':'z','Zp':'z'}
        for name, ax, pos in faces:
            self.fdtd.addpower()
            self.fdtd.set("name", f"MST_{name}")
            self.fdtd.set("monitor type", f"2D {ax.upper()}-normal")
            self.fdtd.set(ax, pos)
            for sp_ax in ['x', 'y', 'z']:
                if sp_ax != ax:
                    self.fdtd.set(f"{sp_ax} span", 2 * half)
            self.fdtd.set("wavelength start", lam_min_nm * 1e-9)
            self.fdtd.set("wavelength stop",  lam_max_nm * 1e-9)
            self.fdtd.set("frequency points", n_lambda)

    def run_simulation(self) -> bool:
        if self.dry_run:
            self.log.info("  [DRY-RUN] Simulation would run here.")
            return True
        try:
            self.fdtd.run()
            return True
        except Exception as e:
            self.log.error(f"  FDTD run failed: {e}")
            return False

    def extract_and_save(self, out_path: Path, polarization: str,
                          twist_deg: float, mesh_nm: float):
        if self.dry_run:
            self.log.info(f"  [DRY-RUN] Would save: {out_path}")
            return
        # Extract transmission data
        T_fwd = self.fdtd.transmission("T_forward")
        T_bwd = self.fdtd.transmission("T_backward")
        lam   = self.fdtd.getresult("T_forward", "lambda")

        out_path.parent.mkdir(parents=True, exist_ok=True)
        df = pd.DataFrame({
            'lambda_nm': lam.flatten() * 1e9,
            'T_forward': T_fwd.flatten(),
            'T_backward': T_bwd.flatten(),
            'polarization': polarization,
            'twist_deg': twist_deg,
            'mesh_nm': mesh_nm,
        })
        df.to_csv(out_path, index=False)
        self.log.info(f"  Raw data saved: {out_path}")

    def run_case(self, geom_params: dict, polarization: str, mesh_nm: float,
                  out_path: Path) -> bool:
        """Run a single FDTD case end-to-end."""
        cfg = self.cfg
        sp  = cfg['spectral']
        try:
            self.build_geometry(
                geom_params['n_rods'],
                geom_params['ring_r_nm'],
                geom_params['twist_deg'],
                geom_params['rod_l_nm'],
                geom_params['rod_d_nm']
            )
            self.set_mesh(mesh_nm,
                          geom_params['ring_r_nm'],
                          geom_params['rod_l_nm'])
            self.add_source(polarization, sp['lambda_min_nm'],
                            sp['lambda_max_nm'], cfg['fdtd']['domain_nm'][0])
            self.add_mst_monitors(
                geom_params['ring_r_nm'],
                geom_params['rod_l_nm'],
                cfg['fdtd']['monitors']['mst_force']['gap_nm'],
                sp['n_points'],
                sp['lambda_min_nm'], sp['lambda_max_nm']
            )
            ok = self.run_simulation()
            if ok:
                self.extract_and_save(out_path, polarization,
                                       geom_params['twist_deg'], mesh_nm)
            return ok
        except Exception as e:
            self.log.error(f"  run_case failed: {e}\n{traceback.format_exc()}")
            return False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', default='baseline',
                        choices=['baseline', 'convergence', 'sweep_twist', 'all'])
    parser.add_argument('--dry_run', action='store_true')
    args = parser.parse_args()

    cfg_path = ROOT_DIR / 'config' / 'config.yaml'
    cfg = load_config(cfg_path)

    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s [%(levelname)s] %(message)s')
    log = logging.getLogger()

    ctrl = FDTDController(cfg, ROOT_DIR, dry_run=args.dry_run)
    if not args.dry_run:
        ctrl.open_lumerical()

    baseline_geom = {
        'n_rods':    cfg['geometry']['n_rods'],
        'ring_r_nm': cfg['geometry']['ring_radius_nm'],
        'twist_deg': cfg['geometry']['twist_LH_deg'],
        'rod_l_nm':  cfg['geometry']['rod_length_nm'],
        'rod_d_nm':  cfg['geometry']['rod_diameter_nm'],
    }

    if args.mode in ['baseline', 'all']:
        for pol in ['LCP', 'RCP']:
            for twist, name in [(0, 'achiral'), (30, 'LH'), (-30, 'RH')]:
                geom = dict(baseline_geom, twist_deg=twist)
                out = ROOT_DIR / 'data' / 'raw' / f'FDTD_{pol}_{name}_0.5nm.csv'
                ok = ctrl.run_case(geom, pol, 0.5, out)
                log.info(f"  {pol} {name}: {'OK' if ok else 'FAILED'}")

    if args.mode in ['convergence', 'all']:
        for mesh in cfg['fdtd']['mesh_convergence_nm']:
            out = ROOT_DIR / 'data' / 'validation' / f'FDTD_LCP_LH_{mesh}nm.csv'
            ok = ctrl.run_case(baseline_geom, 'LCP', mesh, out)
            log.info(f"  Mesh {mesh} nm: {'OK' if ok else 'FAILED'}")

    if args.mode in ['sweep_twist', 'all']:
        for twist in cfg['sweeps']['twist_angle_deg']:
            geom = dict(baseline_geom, twist_deg=float(twist))
            out = ROOT_DIR / 'data' / 'raw' / f'FDTD_LCP_twist{twist:.0f}.csv'
            ok = ctrl.run_case(geom, 'LCP', 0.5, out)
            log.info(f"  Twist {twist}deg: {'OK' if ok else 'FAILED'}")

    ctrl.close_lumerical()
    log.info("FDTD controller finished.")


if __name__ == '__main__':
    main()
